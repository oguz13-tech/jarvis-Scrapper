"""Opt-in network validation with diagnosis and resumable summary.
Run from project root: python scripts/live_test.py --file urls.txt --output live_42
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from jarvis_scraper.diagnostics import analyze_run, classify_failure, build_retry_plan
from jarvis_scraper.engine import Engine
from jarvis_scraper.logging_config import configure
from jarvis_scraper.models import ScrapeRequest

PRIMARY = [
    'https://www.iamfy.co/collections/maximalist-art-prints',
    'https://wallhaven.cc/search?q=nature',
    'https://www.reddit.com/r/wallpaper/',
    'https://tr.pinterest.com/berin6580/3d-duvar-ka%C4%9F%C4%B1d%C4%B1/',
    'https://wallpaperflare.com/search?wallpaper=nature',
]


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def _load_urls(path: str | None) -> list[str]:
    raw = Path(path).read_text(encoding='utf-8').splitlines() if path else PRIMARY
    return list(dict.fromkeys(x.strip() for x in raw if x.strip() and not x.lstrip().startswith('#')))


def _row_from_result(url, result, elapsed):
    row = {
        'url': url,
        'status': result.status.value,
        'strategy': result.strategy_used,
        'stats': result.stats,
        'errors': result.errors,
        'warnings': result.warnings,
        'attempted_strategies': [a.__dict__ for a in result.attempted_strategies],
        'elapsed_seconds_outer': round(elapsed, 3),
    }
    row['diagnosis'] = classify_failure(row)
    row['retry_plan'] = build_retry_plan(row)
    return row


def main():
    parser = argparse.ArgumentParser(description='JARVIS live corpus validator')
    parser.add_argument('--file')
    parser.add_argument('--output', default='final_live_test')
    parser.add_argument('--dry-run', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--max-items', type=int, default=3)
    parser.add_argument('--max-pages', type=int, default=3)
    parser.add_argument('--max-scrolls', type=int, default=8)
    parser.add_argument('--delay', type=float, default=0.75)
    parser.add_argument('--start-at', type=int, default=1, help='1-based corpus index')
    parser.add_argument('--limit', type=int, help='only run N URLs from start-at')
    parser.add_argument('--no-group-products', action='store_true')
    parser.add_argument('--respect-robots', action=argparse.BooleanOptionalAction, default=True)
    args = parser.parse_args()

    configure(True)
    output = Path(args.output)
    output.mkdir(exist_ok=True, parents=True)
    urls = _load_urls(args.file)
    urls = urls[max(args.start_at - 1, 0):]
    if args.limit:
        urls = urls[:args.limit]

    rows = []
    summary_path = output / 'summary.json'
    if args.resume and summary_path.exists():
        try:
            rows = json.loads(summary_path.read_text(encoding='utf-8'))
        except Exception:
            rows = []
    completed = {row.get('url') for row in rows if row.get('url')}

    for idx, url in enumerate(urls, start=1):
        if args.resume and url in completed:
            print(f'[SKIP {idx}/{len(urls)}] {url}', flush=True)
            continue
        print(f'\n=== [{idx}/{len(urls)}] {url} ===', flush=True)
        started = time.monotonic()
        try:
            result = Engine().run(ScrapeRequest(
                url, output=str(output), max_items=args.max_items,
                max_pages=args.max_pages, max_scrolls=args.max_scrolls,
                delay=args.delay, dry_run=args.dry_run, resume=args.resume,
                group_products=not args.no_group_products,
                respect_robots=args.respect_robots,
            ))
            row = _row_from_result(url, result, time.monotonic() - started)
        except Exception as exc:
            row = {
                'url': url, 'status': 'PARSER_ERROR', 'strategy': None,
                'stats': {}, 'errors': [f'{type(exc).__name__}: {exc}'], 'warnings': [],
                'attempted_strategies': [], 'elapsed_seconds_outer': round(time.monotonic() - started, 3),
            }
            row['diagnosis'] = classify_failure(row)
            row['retry_plan'] = build_retry_plan(row)
        rows.append(row)
        print(json.dumps({
            'url': row['url'], 'status': row['status'], 'strategy': row['strategy'],
            'diagnosis': row['diagnosis'], 'retry_plan': row['retry_plan'],
            'downloaded': (row.get('stats') or {}).get('downloaded'),
            'products': (row.get('stats') or {}).get('products_detected'),
        }, ensure_ascii=False), flush=True)
        _write_json(summary_path, rows)
        _write_json(output / 'diagnostics.json', analyze_run(rows))

    diagnosis = analyze_run(rows)
    _write_json(output / 'summary.json', rows)
    _write_json(output / 'diagnostics.json', diagnosis)

    lines = [
        '# JARVIS Live Validation Report', '',
        f'- Total: {diagnosis["total"]}',
        f'- Status counts: `{json.dumps(diagnosis["status_counts"], ensure_ascii=False)}`',
        f'- Failure categories: `{json.dumps(diagnosis["failure_categories"], ensure_ascii=False)}`',
        f'- Platforms: `{json.dumps(diagnosis["platform_counts"], ensure_ascii=False)}`', '',
        '## High priority failures',
    ]
    if diagnosis['high_priority']:
        for item in diagnosis['high_priority']:
            lines.append(f'- `{item["status"]}` / `{item["platform"]}` / `{item["action"]}` — {item["url"]}')
    else:
        lines.append('- None')
    (output / 'REPORT.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')

    print('\n=== DONE ===')
    print(f'Summary: {summary_path.resolve()}')
    print(f'Diagnostics: {(output / "diagnostics.json").resolve()}')
    print(f'Report: {(output / "REPORT.md").resolve()}')


if __name__ == '__main__':
    main()
