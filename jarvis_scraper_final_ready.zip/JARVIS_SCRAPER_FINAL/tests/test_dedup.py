from io import BytesIO
from PIL import Image
from jarvis_scraper.download.deduplicator import Deduplicator

def img_bytes():
    b=BytesIO(); Image.new('RGB',(32,32),'white').save(b,'PNG'); return b.getvalue()

def test_url_and_content_dedup():
    d=Deduplicator()
    assert d.url_seen('https://x/a.jpg') is False
    assert d.url_seen('https://x/a.jpg#x') is True
    sha,ph=d.hashes(img_bytes())
    assert d.content_seen(sha,ph) is False
    assert d.content_seen(sha,ph) is True
