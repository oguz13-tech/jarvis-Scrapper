import hashlib
import json
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock

import pytest
from PIL import Image, ImageDraw
from jarvis_scraper.models import ImageAsset, Product, ScrapeRequest, ScrapeResult, Status
from jarvis_scraper.paths import safe_name, job_name
from jarvis_scraper.download.downloader import Downloader
from jarvis_scraper.download.deduplicator import Deduplicator
from jarvis_scraper.download.normalizers import normalize_url
from jarvis_scraper.download.validator import validate_image
from jarvis_scraper.extractors.html_images import extract_images
from jarvis_scraper.extractors.json_ld import extract_jsonld_products
from jarvis_scraper.extractors.srcset import best_srcset
from jarvis_scraper.fetchers.http_fetcher import HttpFetcher, validate_url
from jarvis_scraper.exceptions import ScrapeError
from jarvis_scraper.storage.manifest import Manifest
from jarvis_scraper.detector import Detector
from jarvis_scraper.adapters.shopify import ShopifyAdapter
from jarvis_scraper.engine import Engine


def image_bytes(size=(640, 480), color='blue', fmt='PNG'):
    image = Image.new('RGB', size, color)
    ImageDraw.Draw(image).rectangle((20, 30, 150, 170), fill='red')
    stream = BytesIO()
    image.save(stream, fmt)
    return stream.getvalue()


class Response:
    def __init__(self, content=b'', text='', status=200, url='https://test.invalid/', data=None, mime='image/png'):
        self.content, self.text, self.status_code, self.url = content, text, status, url
        self.headers, self.is_redirect, self.data = {'Content-Type': mime}, False, data

    def json(self):
        return self.data


@pytest.mark.parametrize('name', ['CON', 'prn.txt', 'AUX', 'NUL', 'COM1', 'LPT1', '../../../a', '<>:"/\\|?*', '..'])
def test_filename_sanitization(name):
    value = safe_name(name)
    assert value not in {'', '.', '..', 'CON', 'AUX', 'NUL', 'COM1', 'LPT1', 'prn.txt'}
    assert not any(c in value for c in '<>:"/\\|?*')


def test_job_query_collision():
    assert job_name('https://site/search?q=a') != job_name('https://site/search?q=b')


@pytest.mark.parametrize('url', ['file:///etc/passwd', 'javascript:alert(1)', 'https://a:b@site.test/', 'no-url'])
def test_invalid_url(url):
    with pytest.raises(ScrapeError):
        validate_url(url)


def test_relative_protocol_and_prefer_srcset():
    assets = extract_images('<img src="/small.jpg" srcset="//cdn.test/a.jpg 2x, /b.jpg 1x"><img data-src="../c.jpg">', 'https://site.test/dir/page')
    assert {a.image_url for a in assets} == {'https://cdn.test/a.jpg', 'https://site.test/c.jpg'}


def test_srcset_malformed():
    assert best_srcset('a.jpg banana, b.jpg 2x, c.jpg -3w, d.jpg 0w,') == 'b.jpg'
    assert best_srcset('garbage 4bad') is None


@pytest.mark.parametrize('data', [
    {'@type': 'Product', 'name': 'X', 'image': {'url': '/x.png'}},
    {'@graph': [{'@type': ['Thing', 'Product'], 'name': 'X', 'image': ['/x.png']}]},
    [{'@type': 'Product', 'name': 'X', 'image': '/x.png'}],
])
def test_jsonld_variants(data):
    products = extract_jsonld_products('<script type="application/ld+json">'+json.dumps(data)+'</script>', 'https://x.test/')
    assert len(products) == 1
    assert products[0].images[0].image_url == 'https://x.test/x.png'


def test_malformed_jsonld():
    assert extract_jsonld_products('<script type="application/ld+json">{broken</script>', 'https://x.test') == []


def test_inline_json_image():
    assets = extract_images('<script type="application/json">{"image":{"url":"/x.png"}}</script>', 'https://x.test/')
    assert assets[0].image_url == 'https://x.test/x.png'


def test_actual_format_priority():
    ok, info = validate_image(image_bytes(), 'image/jpeg')
    assert ok and info['ext'] == '.png' and info['mime'] == 'image/png'


def test_html_with_image_mime_rejected():
    assert not validate_image(b'<html>blocked</html>', 'image/jpeg')[0]


def test_svg_validation():
    assert validate_image(b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500"/>', 'image/svg+xml')[0]
    assert not validate_image(b'<html><svg/></html>', 'image/svg+xml')[0]
    assert not validate_image(b'<svg width="500" height="500"><script/></svg>', 'image/svg+xml')[0]


def test_sha_duplicate(tmp_path):
    fetcher = Mock()
    fetcher.get.return_value = Response(content=image_bytes())
    dl = Downloader(fetcher=fetcher)
    a = dl.download(ImageAsset('https://p', 'https://i/a'), tmp_path)
    b = dl.download(ImageAsset('https://p', 'https://i/b'), tmp_path)
    assert a.download_status == 'downloaded'
    assert b.download_status == 'duplicate_content' and b.duplicate_of == a.local_path
    assert len(list(tmp_path.rglob('*.png'))) == 1


def test_perceptual_reencode():
    d = Deduplicator()
    sha, ph = d.hashes(image_bytes())
    sha2, ph2 = d.hashes(image_bytes(fmt='BMP'))
    assert sha != sha2 and ph and ph == ph2
    assert not d.content_seen(sha, ph)
    assert d.content_seen(sha2, ph2)


def test_uniform_colors_not_perceptual_duplicates():
    d = Deduplicator()
    values = []
    for color in ('red', 'blue'):
        stream = BytesIO()
        Image.new('RGB', (400, 400), color).save(stream, 'PNG')
        values.append(d.hashes(stream.getvalue()))
    assert not d.content_seen(*values[0])
    assert not d.content_seen(*values[1])


@pytest.mark.parametrize('size,orientation', [((640, 480), 'Yatay'), ((480, 640), 'Dikey'), ((400, 400), 'Kare')])
def test_orientation(tmp_path, size, orientation):
    fetcher = Mock()
    fetcher.get.return_value = Response(content=image_bytes(size))
    asset = Downloader(fetcher=fetcher).download(ImageAsset('https://p', 'https://i'), tmp_path, product_folder='product')
    assert Path(asset.local_path).parent == tmp_path / orientation / 'product'


def test_manifest_and_corrupt_tail(tmp_path):
    manifest = Manifest(tmp_path / 'manifest.jsonl')
    manifest.append({'image_url': 'first'})
    with manifest.path.open('ab') as stream:
        stream.write(b'{interrupted')
    manifest.append({'image_url': 'second'})
    assert [r['image_url'] for r in manifest.records()] == ['first', 'second']


def test_resume_skip_and_missing_file(tmp_path):
    request = ScrapeRequest('https://site.test', output=str(tmp_path), resume=True)
    root = tmp_path
    manifest = Manifest(root / 'manifest.jsonl')
    fetcher = Mock()
    fetcher.get.return_value = Response(content=image_bytes())
    def result():
        return ScrapeResult(request.url, 'site.test', images=[ImageAsset(request.url, 'https://i.test/a')])
    Engine().save_images(request, result(), root, manifest, fetcher)
    fetcher.get.reset_mock()
    resumed = result()
    Engine().save_images(request, resumed, root, manifest, fetcher)
    fetcher.get.assert_not_called()
    assert resumed.images[0].download_status == 'resume_skipped'
    Path(resumed.images[0].local_path).unlink()
    Engine().save_images(request, result(), root, manifest, fetcher)
    fetcher.get.assert_called_once()


def test_shopify_collection_pagination_and_gallery():
    adapter = ShopifyAdapter()
    urls = []
    def get(url):
        urls.append(url)
        if 'products.json' in url:
            count = 250 if 'page=1' in url else 1
            offset = 0 if 'page=1' in url else 250
            return Response(data={'products': [{'id': offset+i, 'handle': f'p{offset+i}', 'title': 'X', 'images': [{'src': f'https://i.test/{offset+i}.jpg'}]} for i in range(count)]})
        return Response(text='<media-gallery><img src="/extra.jpg"></media-gallery>')
    adapter.fetcher = SimpleNamespace(get=get)
    result = ScrapeResult('https://shop.test/collections/c', 'shop.test')
    assert adapter.scrape(ScrapeRequest(result.source_url, max_items=251), result)
    assert len(result.products) == 251
    assert urls[0] == 'https://shop.test/collections/c/products.json?limit=250&page=1'
    assert any('page=2' in u for u in urls)
    assert len(result.products[0].images) == 2


def test_runtime_overrides_registry():
    assert Detector().rank('https://iamfy.co', '<html>not shopify</html>')[0][0] == 'static'
    assert Detector().rank('https://unknown.test', 'Shopify.theme = {}')[0][0] == 'shopify'


def test_safe_url_normalization():
    url = 'https://cdn.shopify.com/a_300x300.jpg?token=x&width=300'
    assert normalize_url(url + '#fragment') == url


def test_robots_wildcards_allow_and_stop():
    fetcher = HttpFetcher(delay=0)
    fetcher._raw = Mock(return_value=Response(text='User-agent: *\nDisallow: /private*\nAllow: /private/public\n'))
    fetcher.check_robots('https://x.test/private/public')
    with pytest.raises(ScrapeError) as error:
        fetcher.get('https://x.test/private/data')
    assert error.value.status == Status.ROBOTS_DISALLOWED
    assert fetcher._raw.call_count == 1


def test_403_not_retried():
    fetcher = HttpFetcher(delay=0, respect_robots=False)
    response = Mock(status_code=403, headers={}, url='https://x.test/', is_redirect=False)
    response.iter_content.return_value = [b'blocked']
    fetcher.session.get = Mock(return_value=response)
    with pytest.raises(ScrapeError) as error:
        fetcher.get('https://x.test/')
    assert error.value.status == Status.BLOCKED
    assert fetcher.session.get.call_count == 1


def test_429_long_retry_after():
    fetcher = HttpFetcher(delay=0, respect_robots=False)
    response = Mock(status_code=429, headers={'Retry-After': '120'}, url='https://x.test/', is_redirect=False)
    response.iter_content.return_value = [b'limited']
    fetcher.session.get = Mock(return_value=response)
    with pytest.raises(ScrapeError) as error:
        fetcher.get('https://x.test/')
    assert error.value.status == Status.RATE_LIMITED
    assert fetcher.session.get.call_count == 1


def test_fallback_and_dry_run(tmp_path, monkeypatch):
    import jarvis_scraper.engine as module
    monkeypatch.setattr(HttpFetcher, 'check_robots', lambda self, url: None)
    monkeypatch.setattr(HttpFetcher, 'get', lambda self, url, **kw: Response(text='<html/>', url=url))
    class Empty:
        def __init__(self, *args): pass
        def scrape(self, request, result): return False
    class Working(Empty):
        def scrape(self, request, result):
            result.images.append(ImageAsset(request.url, 'https://image.test/a'))
            return True
    monkeypatch.setitem(module.ADAPTERS, 'static', Empty)
    monkeypatch.setitem(module.ADAPTERS, 'dynamic', Working)
    download = Mock(side_effect=AssertionError('dry run downloaded'))
    monkeypatch.setattr(Downloader, 'download', download)
    result = Engine().run(ScrapeRequest('https://site.test', output=str(tmp_path), dry_run=True))
    assert result.status == Status.SUCCESS and result.strategy_used == 'dynamic'
    assert [a.success for a in result.attempted_strategies] == [False, True]
    assert all(a.started_at and a.finished_at for a in result.attempted_strategies)
    assert list(tmp_path.rglob('manifest.jsonl')) and list(tmp_path.rglob('scrape_report.json'))
    download.assert_not_called()


def test_access_error_stops_fallback(tmp_path, monkeypatch):
    import jarvis_scraper.engine as module
    monkeypatch.setattr(HttpFetcher, 'check_robots', lambda self, url: None)
    monkeypatch.setattr(HttpFetcher, 'get', lambda self, url, **kw: Response(text='<html/>', url=url))
    class Blocked:
        def __init__(self, *args): pass
        def scrape(self, request, result):
            raise ScrapeError(Status.BLOCKED, '403')
    monkeypatch.setitem(module.ADAPTERS, 'static', Blocked)
    result = Engine().run(ScrapeRequest('https://site.test', output=str(tmp_path), dry_run=True))
    assert result.status == Status.BLOCKED and len(result.attempted_strategies) == 1


def test_product_relationship_and_optional_folders(tmp_path):
    fetcher = Mock()
    fetcher.get.side_effect = [Response(content=image_bytes(color='blue')), Response(content=image_bytes(color='green'))]
    products = [Product('same', f'https://site/{i}', id=str(i), images=[ImageAsset(f'https://site/{i}', f'https://image/{i}')]) for i in range(2)]
    result = ScrapeResult('https://site', 'site', products=products, images=[x for p in products for x in p.images])
    request = ScrapeRequest('https://site', group_products=True)
    Engine().save_images(request, result, tmp_path, Manifest(tmp_path / 'manifest.jsonl'), fetcher)
    assert len(list((tmp_path / 'Yatay').iterdir())) == 2
    assert len(list((tmp_path / 'metadata').rglob('metadata.json'))) == 2
    rows = list(Manifest(tmp_path / 'manifest.jsonl').records())
    assert {r['product_id'] for r in rows} == {'0', '1'}


def test_composed_gallery_background_excluded():
    from jarvis_scraper.extractors.product_detector import gallery_images
    html = '''<media-gallery><div class="mock-image__frame-container" style="background-image:url('/empty.png')"><img class="mock-image__artwork" src="/art.jpg"></div><img class="mock-image__static" src="/marketing.png"><img src="/room.jpg"></media-gallery>'''
    urls = {x.image_url for x in gallery_images(html, 'https://site.test/product')}
    assert urls == {'https://site.test/art.jpg', 'https://site.test/room.jpg'}


def test_woocommerce_body_not_product_card():
    from jarvis_scraper.extractors.product_detector import product_links
    html = '<body class="woocommerce"><nav><a href="/login">Login</a></nav><a href="/about">About</a><div class="product-grid-item"><a href="/dl/art">Art</a></div></body>'
    assert product_links(html, 'https://site.test/') == ['https://site.test/dl/art']


def test_published_full_image_link():
    from jarvis_scraper.extractors.gallery import detail_links, full_image_links
    html = '<a href="/art/one-12.html"><img src="/thumb.jpg"></a>'
    assert detail_links(html, 'https://site.test') == ['https://site.test/art/one-12.html']
    full = '<a href="/small.jpg">800x600</a><a href="/large.jpg">3840x2160</a>'
    assert full_image_links(full, 'https://site.test/a')[0].image_url == 'https://site.test/large.jpg'


def test_stock_gallery_is_not_product():
    from jarvis_scraper.adapters.generic_static import GenericStaticAdapter
    html = '<h1>Wallpapers</h1><div itemprop="associatedMedia"><img src="/photo.jpg"></div>'
    assert GenericStaticAdapter().product_page(html, 'https://site.test/gallery') == []


def test_api_key_redacted():
    from jarvis_scraper.fetchers.http_fetcher import public_url
    assert 'secretvalue' not in public_url('https://api.test/?key=secretvalue&q=cat')


def test_pixabay_api_cache(tmp_path, monkeypatch):
    from jarvis_scraper.adapters.pixabay import PixabayAdapter
    monkeypatch.setenv('PIXABAY_API_KEY', 'fixture-key')
    fetcher = Mock()
    fetcher.get.return_value = Response(data={'hits': [{'pageURL': 'https://pixabay.com/p/1', 'largeImageURL': 'https://cdn.test/full.jpg'}]})
    adapter = PixabayAdapter(fetcher)
    req = ScrapeRequest('https://pixabay.com/images/search/flowers/', output=str(tmp_path), max_items=1, dry_run=True)
    result = ScrapeResult(req.url, 'pixabay.com')
    assert adapter.scrape(req, result)
    assert 'q=flowers' in fetcher.get.call_args.args[0]
    fetcher.get.reset_mock()
    assert adapter.scrape(req, ScrapeResult(req.url, 'pixabay.com'))
    fetcher.get.assert_not_called()


def test_api_missing_key_fallback(monkeypatch):
    monkeypatch.delenv('PEXELS_API_KEY', raising=False)
    # Dedicated provider adapter owns the public browser/detail fallback when no key exists.
    assert Detector().rank('https://www.pexels.com/')[0][0] == 'pexels'


def test_robots_error_cached():
    fetcher = HttpFetcher(delay=0)
    fetcher._raw = Mock(return_value=Response(status=403))
    for url in ('https://x.test/a.jpg', 'https://x.test/b.jpg'):
        with pytest.raises(ScrapeError):
            fetcher.get(url)
    assert fetcher._raw.call_count == 1


def test_redirect_respects_destination_robots():
    fetcher = HttpFetcher(delay=0)
    redirect = Response(url='https://first.test/')
    redirect.is_redirect = True
    redirect.headers['Location'] = 'https://second.test/private'
    fetcher._raw = Mock(side_effect=[Response(text='User-agent: *\nAllow: /'), redirect,
                                    Response(text='User-agent: *\nDisallow: /private')])
    with pytest.raises(ScrapeError) as error:
        fetcher.get('https://first.test/')
    assert error.value.status == Status.ROBOTS_DISALLOWED
    assert fetcher._raw.call_count == 3


def test_browser_reuse_and_discovery_blocks_images(monkeypatch):
    import playwright.sync_api
    from jarvis_scraper.fetchers.browser_fetcher import BrowserFetcher
    mock_playwright, browser, context, page = Mock(), Mock(), Mock(), Mock()
    mock_playwright.chromium.launch.return_value = browser
    browser.new_context.return_value = context
    context.new_page.return_value = page
    page.goto.return_value = SimpleNamespace(status=200)
    page.content.return_value = '<html><img src="https://i.test/a.jpg"></html>'
    page.url = 'https://site.test/'
    api = Mock()
    api.start.return_value = mock_playwright
    monkeypatch.setattr(playwright.sync_api, 'sync_playwright', lambda: api)
    fetcher = BrowserFetcher(http=Mock())
    fetcher.fetch(page.url, max_scrolls=0)
    fetcher.fetch(page.url, max_scrolls=0)
    assert mock_playwright.chromium.launch.call_count == 1
    route = Mock()
    route.request.resource_type, route.request.method = 'image', 'GET'
    page.route.call_args.args[1](route)
    route.abort.assert_called_once()
    route.continue_.assert_not_called()
    fetcher.close()
    browser.close.assert_called_once()


def test_optional_scrapling_absent(monkeypatch):
    import sys
    from jarvis_scraper.fetchers.scrapling_fetcher import ScraplingFetcher
    monkeypatch.setitem(sys.modules, 'scrapling.fetchers', None)
    with pytest.raises(RuntimeError, match='Install with'):
        ScraplingFetcher().fetch('https://site.test')


def test_related_product_not_assigned_to_current_product():
    from jarvis_scraper.adapters.generic_static import GenericStaticAdapter
    data = [{'@type': 'Product', 'name': 'Accessory', 'url': '/accessory', 'image': '/wrong.jpg'},
            {'@type': 'Product', 'name': 'Selected', 'url': '/selected', 'image': '/right.jpg'}]
    html = '<script type="application/ld+json">'+json.dumps(data)+'</script>'
    products = GenericStaticAdapter().product_page(html, 'https://shop.test/selected')
    assert len(products) == 1 and products[0].name == 'Selected'


def test_social_icons_and_tracking_pixels_excluded():
    html = '<img src="https://facebook.com/tr?id=1"><img src="/fontawesome/star.svg"><img width="1" height="1" src="/track.gif"><img src="/art.jpg">'
    assert [a.image_url for a in extract_images(html, 'https://site.test')] == ['https://site.test/art.jpg']


def test_browser_dom_timeout_keeps_public_document(monkeypatch):
    import playwright.sync_api
    from jarvis_scraper.fetchers.browser_fetcher import BrowserFetcher
    api, runtime, browser, context, page = [Mock() for _ in range(5)]
    api.start.return_value = runtime
    runtime.chromium.launch.return_value = browser
    browser.new_context.return_value = context
    context.new_page.return_value = page
    page.goto.return_value = SimpleNamespace(status=200)
    page.url = 'https://site.test/'
    page.content.return_value = '<html><title>Public gallery</title><img src="/art.jpg"></html>'
    page.wait_for_load_state.side_effect = playwright.sync_api.TimeoutError('late analytics')
    monkeypatch.setattr(playwright.sync_api, 'sync_playwright', lambda: api)
    fetcher = BrowserFetcher()
    assert 'art.jpg' in fetcher.fetch(page.url, max_scrolls=0)
    assert fetcher.last_warning
    fetcher.close()
