from jarvis_scraper.adapters.shopify import ShopifyAdapter
from jarvis_scraper.models import ScrapeRequest, ScrapeResult

class R:
    def json(self):
        return {'products':[{'title':'A','handle':'a','id':1,'vendor':'V','product_type':'Art','tags':['x'],'variants':[],'images':[{'src':'https://cdn.test/a.jpg'}]}]}
class F:
    def get(self,*a,**k): return R()

def test_shopify_mapping():
    a=ShopifyAdapter(); a.fetcher=F(); r=ScrapeResult('https://shop.test/collections/c','shop.test')
    assert a.scrape(ScrapeRequest('https://shop.test/collections/c',max_items=10),r)
    assert r.products[0].url=='https://shop.test/products/a'
    assert r.images[0].image_url=='https://cdn.test/a.jpg'
