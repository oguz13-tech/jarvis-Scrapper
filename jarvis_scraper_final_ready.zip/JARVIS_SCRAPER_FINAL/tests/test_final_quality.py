from io import BytesIO
from unittest.mock import Mock

from PIL import Image

from jarvis_scraper.download.downloader import Downloader
from jarvis_scraper.download.highres import provider_highres_candidates
from jarvis_scraper.extractors.gallery import detail_links, full_image_links
from jarvis_scraper.extractors.product_detector import product_links
from jarvis_scraper.extractors.svg import extract_svg_assets
from jarvis_scraper.models import ImageAsset


def _jpg(size=(800, 600)):
    stream = BytesIO()
    Image.new('RGB', size, 'blue').save(stream, 'JPEG')
    return stream.getvalue()


def test_pixabay_provider_prefers_1920_and_1280():
    url = 'https://cdn.pixabay.com/photo/2020/01/01/a_640.jpg'
    out = provider_highres_candidates(url)
    assert out[0].endswith('a_1920.jpg')
    assert out[1].endswith('a_1280.jpg')


def test_etsy_public_cdn_fullxfull_candidate():
    url = 'https://i.etsystatic.com/123/il_340x270.abc.jpg'
    assert provider_highres_candidates(url)[0] == 'https://i.etsystatic.com/123/il_fullxfull.abc.jpg'


def test_trendyol_resize_wrapper_candidate():
    url = 'https://cdn.dsmcdn.com/mnresize/300/450/ty1/product/media/images/a.jpg'
    assert provider_highres_candidates(url)[0] == 'https://cdn.dsmcdn.com/ty1/product/media/images/a.jpg'


def test_deviantart_wix_transform_candidate_keeps_token():
    url = 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/x/y.jpg/v1/fill/w_525,h_350,q_70,strp/name.jpg?token=abc'
    assert provider_highres_candidates(url)[0] == 'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/x/y.jpg?token=abc'


def test_text_only_pattern_card_is_detail_link():
    html = '<div class="pattern-card"><a href="/chevron-1">Chevron - 1</a></div>'
    assert detail_links(html, 'https://pattern.monster/collections') == ['https://pattern.monster/chevron-1']


def test_detail_page_prefers_download_original_over_thumbnail():
    html = '''<main><img src="/thumb.jpg"><a href="/full-3840x2160.jpg" download>Download original 3840x2160</a></main>'''
    asset = full_image_links(html, 'https://x.test/photo/1')[0]
    assert asset.image_url == 'https://x.test/full-3840x2160.jpg'


def test_inline_pattern_svg_can_be_saved_without_network(tmp_path):
    html = '<main class="pattern-preview"><svg viewBox="0 0 200 200"><rect width="200" height="200"/></svg></main>'
    assets = extract_svg_assets(html, 'https://pattern.monster/chevron-1')
    assert assets and assets[0].image_url.startswith('data:image/svg+xml;base64,')
    fetcher = Mock()
    asset = Downloader(fetcher=fetcher).download(assets[0], tmp_path)
    assert asset.download_status == 'downloaded'
    assert asset.local_path.endswith('.svg')
    fetcher.get.assert_not_called()


def test_known_preview_not_saved_as_final(tmp_path):
    response = Mock(content=_jpg((800, 600)), headers={'Content-Type': 'image/jpeg'})
    fetcher = Mock(); fetcher.get.return_value = response
    asset = ImageAsset('https://x.test/page', 'https://x.test/images/thumbnail/photo.jpg')
    Downloader(fetcher=fetcher).download(asset, tmp_path)
    assert asset.download_status == 'rejected'
    assert asset.rejection_reason == 'preview_only'


def test_etsy_and_trendyol_product_routes_are_discoverable():
    etsy = '<div data-listing-id="1"><a href="/listing/12345/sample"><img src="/a.jpg"></a></div>'
    trendyol = '<div class="p-card-wrppr"><a href="/brand/name-p-987654"><img src="/b.jpg"></a></div>'
    assert product_links(etsy, 'https://www.etsy.com/shop/x') == ['https://www.etsy.com/listing/12345/sample']
    assert product_links(trendyol, 'https://www.trendyol.com/sr?q=x') == ['https://www.trendyol.com/brand/name-p-987654']


def test_shopify_cdn_only_does_not_force_shopify_store_adapter():
    from jarvis_scraper.detector import Detector
    html = '<html><img src="https://cdn.shopify.com/s/files/a.jpg"></html>'
    ranked = Detector().rank('https://www.shopify.com/stock-photos/pattern', html)
    assert ranked[0][0] == 'static'


def test_engine_quality_gate_falls_through_to_dynamic(tmp_path, monkeypatch):
    import jarvis_scraper.engine as module
    from jarvis_scraper.engine import Engine
    from jarvis_scraper.fetchers.http_fetcher import HttpFetcher
    from jarvis_scraper.models import ScrapeRequest

    class Response:
        text = '<html><body>gallery</body></html>'
        url = 'https://site.test/'

    monkeypatch.setattr(HttpFetcher, 'check_robots', lambda self, url: None)
    monkeypatch.setattr(HttpFetcher, 'get', lambda self, url, **kw: Response())

    class Static:
        def __init__(self, *args): pass
        def scrape(self, request, result):
            result.images.append(ImageAsset(request.url, 'https://img.test/thumbnail/a.jpg', source_strategy='static'))
            return True

    class Dynamic:
        def __init__(self, *args): pass
        def scrape(self, request, result):
            result.images.append(ImageAsset(request.url, 'https://img.test/original/a.jpg', source_strategy='dynamic'))
            return True

    def fake_save(self, request, trial, root, manifest, http):
        for image in trial.images:
            if image.source_strategy == 'static':
                image.download_status = 'rejected'
                image.rejection_reason = 'preview_only'
            else:
                image.download_status = 'downloaded'
                image.width, image.height = 1920, 1080

    monkeypatch.setitem(module.ADAPTERS, 'static', Static)
    monkeypatch.setitem(module.ADAPTERS, 'dynamic', Dynamic)
    monkeypatch.setattr(Engine, 'save_images', fake_save)
    result = Engine().run(ScrapeRequest('https://site.test/', output=str(tmp_path), delay=0))
    assert result.strategy_used == 'dynamic'
    assert result.status.value == 'SUCCESS'
    assert [a.success for a in result.attempted_strategies[:2]] == [False, True]
    assert result.attempted_strategies[0].reason == 'original_not_found'


def test_engine_plain_http_403_can_try_normal_browser_strategy(tmp_path, monkeypatch):
    import jarvis_scraper.engine as module
    from jarvis_scraper.engine import Engine
    from jarvis_scraper.exceptions import ScrapeError
    from jarvis_scraper.fetchers.http_fetcher import HttpFetcher
    from jarvis_scraper.models import ScrapeRequest, Status

    monkeypatch.setattr(HttpFetcher, 'check_robots', lambda self, url: None)
    monkeypatch.setattr(HttpFetcher, 'get', lambda self, url, **kw: (_ for _ in ()).throw(ScrapeError(Status.BLOCKED, f'HTTP 403: {url}')))

    class Dynamic:
        def __init__(self, *args): pass
        def scrape(self, request, result):
            result.images.append(ImageAsset(request.url, 'https://img.test/original.jpg', source_strategy='dynamic'))
            return True

    def fake_save(self, request, trial, root, manifest, http):
        for image in trial.images:
            image.download_status = 'downloaded'
            image.width, image.height = 2000, 1200

    monkeypatch.setitem(module.ADAPTERS, 'dynamic', Dynamic)
    monkeypatch.setattr(Engine, 'save_images', fake_save)
    result = Engine().run(ScrapeRequest('https://site.test/', output=str(tmp_path), delay=0))
    assert result.status == Status.SUCCESS
    assert result.strategy_used == 'dynamic'
    assert result.stats['presentation_http_403'] is True


def test_adawall_250_thumbnail_expands_to_public_800():
    url = 'https://www.adawall.com.tr/resimler/250/12458/1411-1pattern.jpg'
    assert provider_highres_candidates(url)[0] == 'https://www.adawall.com.tr/resimler/800/12458/1411-1pattern.jpg'


def test_3dduvarkagitlari_medium_expands_to_large_sibling():
    url = 'https://3dduvarkagitlari.com/Content/images/2026/9/15/m/a.jpg'
    assert provider_highres_candidates(url)[0] == 'https://3dduvarkagitlari.com/Content/images/2026/9/15/l/a.jpg'


def test_download_page_link_detects_original_html_hop():
    from jarvis_scraper.extractors.gallery import download_page_links
    html = '<main><a href="/download/5120x2880/geometric-pattern">Download Original</a></main>'
    assert download_page_links(html, 'https://hdqwalls.com/wallpaper/5120x2880/geometric-pattern') == [
        'https://hdqwalls.com/download/5120x2880/geometric-pattern'
    ]


def test_language_flags_and_default_placeholders_are_ui_noise():
    from jarvis_scraper.extractors.quality import is_probable_ui_asset
    assert is_probable_ui_asset('https://x.test/assets/img/languages/en.svg')
    assert is_probable_ui_asset('https://x.test/assets/img/default.jpg')


def test_official_api_asset_uses_authorized_asset_fetch_path(tmp_path):
    response = Mock(content=_jpg((1200, 800)), headers={'Content-Type': 'image/jpeg'})
    fetcher = Mock()
    fetcher.get_asset.return_value = response
    asset = ImageAsset('https://pixabay.com/photo', 'https://cdn.pixabay.com/photo/a_1280.jpg', source_strategy='pixabay')
    Downloader(fetcher=fetcher).download(asset, tmp_path)
    assert asset.download_status == 'downloaded'
    fetcher.get_asset.assert_called_once()
    fetcher.get.assert_not_called()


def test_marketplace_detectors_prioritize_dedicated_adapters():
    from jarvis_scraper.detector import Detector
    assert Detector().rank('https://www.etsy.com/search?q=wall+art')[0][0] == 'etsy'
    assert Detector().rank('https://www.trendyol.com/sr?q=tablo')[0][0] == 'trendyol'


def test_trendyol_named_mnresize_segments_are_removed():
    url = 'https://cdn.dsmcdn.com/mnresize/ty1000_prod/product/media/images/abc.jpg'
    assert provider_highres_candidates(url)[0] == 'https://cdn.dsmcdn.com/product/media/images/abc.jpg'


def test_pexels_query_geometry_is_removed():
    url = 'https://images.pexels.com/photos/123/a.jpeg?auto=compress&cs=tinysrgb&w=640&h=480&fit=crop'
    out = provider_highres_candidates(url)
    assert out and 'w=' not in out[0] and 'h=' not in out[0] and 'fit=' not in out[0]
    assert 'auto=compress' in out[0]


def test_unsplash_query_geometry_is_removed():
    url = 'https://images.unsplash.com/photo-abc?ixlib=rb-4.1.0&w=1080&h=720&fit=crop&q=80'
    out = provider_highres_candidates(url)
    assert out and 'w=' not in out[0] and 'h=' not in out[0] and 'fit=' not in out[0]
    assert 'q=80' in out[0]


def test_generic_svg_chrome_is_rejected_even_when_valid(tmp_path):
    svg = b'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800"><rect width="800" height="800"/></svg>'
    response = Mock(content=svg, headers={'Content-Type': 'image/svg+xml'})
    fetcher = Mock(); fetcher.get.return_value = response
    asset = ImageAsset('https://x.test/page', 'https://x.test/assets/decor.svg', source_strategy='static')
    Downloader(fetcher=fetcher).download(asset, tmp_path)
    assert asset.download_status == 'rejected'
    assert asset.rejection_reason == 'ui_svg'
