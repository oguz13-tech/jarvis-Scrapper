from jarvis_scraper.extractors.srcset import best_srcset

def test_width_srcset():
    assert best_srcset('a.jpg 400w, b.jpg 1600w, c.jpg 800w') == 'b.jpg'

def test_density_srcset():
    assert best_srcset('a.jpg 1x, b.jpg 3x, c.jpg 2x') == 'b.jpg'


def test_srcset_keeps_literal_commas_inside_cdn_url():
    value = 'https://cdn.test/a.jpg/v1/fill/w_1050,h_700,q_70,strp/a.jpg 2x, https://cdn.test/a-small.jpg 1x'
    assert best_srcset(value) == 'https://cdn.test/a.jpg/v1/fill/w_1050,h_700,q_70,strp/a.jpg'
