from jarvis_scraper.diagnostics import analyze_run, classify_failure, build_retry_plan


def test_access_control_not_retried():
    row = {'status': 'ROBOTS_DISALLOWED', 'stats': {'platform': 'unknown'}, 'errors': [], 'warnings': []}
    assert classify_failure(row)['category'] == 'ACCESS_CONTROL'
    assert build_retry_plan(row) == []


def test_dynamic_no_results_gets_actionable_diagnosis():
    row = {'status': 'NO_RESULTS', 'stats': {'platform': 'nextjs', 'detected_site_type': 'js_app'}, 'errors': [], 'warnings': [], 'attempted_strategies': [{'strategy': 'static'}]}
    d = classify_failure(row)
    assert d['category'] == 'DYNAMIC_EXTRACTION_GAP'
    assert any(p.get('strategy') == 'dynamic' for p in build_retry_plan(row))


def test_analyze_run_groups_failures():
    rows = [
        {'url': 'https://a.test', 'status': 'SUCCESS', 'stats': {'platform': 'shopify'}, 'errors': [], 'warnings': []},
        {'url': 'https://b.test', 'status': 'NO_RESULTS', 'stats': {'platform': 'nextjs'}, 'errors': [], 'warnings': [], 'attempted_strategies': []},
    ]
    report = analyze_run(rows)
    assert report['total'] == 2
    assert report['status_counts']['SUCCESS'] == 1
    assert report['failure_categories']['DYNAMIC_EXTRACTION_GAP'] == 1


def test_no_results_with_incidental_timeout_stays_extraction_gap():
    row = {
        'status': 'NO_RESULTS', 'stats': {'platform': 'unknown', 'detected_site_type': 'gallery_or_unknown'},
        'errors': [], 'warnings': ['browser networkidle timeout but DOM returned'],
        'attempted_strategies': [{'strategy': 'static'}, {'strategy': 'dynamic'}],
    }
    assert classify_failure(row)['category'] == 'DYNAMIC_EXTRACTION_GAP'


def test_download_403_is_asset_access_control():
    row = {
        'status': 'DOWNLOAD_ERROR', 'stats': {'platform': 'woocommerce'},
        'errors': [], 'warnings': ['asset failed HTTP 403'], 'attempted_strategies': []
    }
    assert classify_failure(row)['category'] == 'ASSET_ACCESS_CONTROL'


def test_original_not_found_retry_plan_is_a_list():
    plan = build_retry_plan({'status': 'ORIGINAL_NOT_FOUND', 'stats': {}, 'attempted_strategies': []})
    assert isinstance(plan, list)
    assert plan and plan[0]['kind'] == 'reextract'
