from jarvis_scraper.detector import Detector

def test_registry_shopify_hint():
    ranked=Detector().rank('https://www.iamfy.co/collections/x')
    assert ranked[0][0]=='shopify'
