import json
from io import BytesIO
from unittest.mock import Mock
from PIL import Image

from jarvis_scraper.platforms import detect_platform
from jarvis_scraper.detector import Detector
from jarvis_scraper.extractors.embedded_state import extract_embedded_products
from jarvis_scraper.extractors.pagination import next_page, increment_page_url
from jarvis_scraper.download.validator import validate_image
from jarvis_scraper.adapters.woocommerce import WooCommerceAdapter
from jarvis_scraper.models import ScrapeRequest, ScrapeResult


def test_platform_fingerprints_common_commerce_stacks():
    assert detect_platform('https://x.test', '<link href="/wp-content/plugins/woocommerce/a.css">').platform == 'woocommerce'
    assert detect_platform('https://x.test', '<script type="text/x-magento-init">{}</script>').platform == 'magento'
    assert detect_platform('https://x.test', '<script id="__NEXT_DATA__" type="application/json">{}</script>').platform == 'nextjs'
    assert detect_platform('https://x.test', '<script>window.prestashop={}</script>').platform == 'prestashop'


def test_detector_prefers_woocommerce_public_api_then_html_fallback():
    ranked = Detector().rank('https://shop.test/product-category/art', '<html class="woocommerce"><div class="wc-block-grid"></div></html>')
    assert ranked[0][0] == 'woocommerce'
    assert 'static' in [x[0] for x in ranked]


def test_embedded_next_product_and_gallery():
    data = {
        'props': {'pageProps': {'product': {
            'id': 12, 'name': 'Poster', 'price': 100,
            'images': [{'url': 'https://cdn.test/a.jpg'}, {'url': 'https://cdn.test/b.jpg'}]
        }}}
    }
    html = '<script id="__NEXT_DATA__" type="application/json">' + json.dumps(data) + '</script>'
    products = extract_embedded_products(html, 'https://shop.test/products/poster')
    assert len(products) == 1
    assert products[0].name == 'Poster'
    assert [x.image_url for x in products[0].images] == ['https://cdn.test/a.jpg', 'https://cdn.test/b.jpg']


def test_pagination_common_patterns():
    assert next_page('<a rel="next" href="?page=3">Next</a>', 'https://x.test/c?page=2') == 'https://x.test/c?page=3'
    assert increment_page_url('https://x.test/c?page=4&q=a', 5) == 'https://x.test/c?page=5&q=a'
    assert increment_page_url('https://x.test/c/page/4/', 5) == 'https://x.test/c/page/5/'


def test_validator_accepts_real_image_with_octet_stream():
    out = BytesIO(); Image.new('RGB', (640, 480), 'blue').save(out, format='JPEG')
    ok, info = validate_image(out.getvalue(), 'application/octet-stream', 300, 300)
    assert ok and info['mime'] == 'image/jpeg' and info['ext'] == '.jpg'


def test_woocommerce_store_api_products():
    fetcher = Mock()
    response = Mock()
    response.json.return_value = [{
        'id': 7, 'name': 'Wall Art', 'slug': 'wall-art', 'permalink': 'https://shop.test/product/wall-art',
        'sku': 'WA-7', 'images': [{'src': 'https://cdn.test/full.jpg', 'alt': 'art'}]
    }]
    fetcher.get.return_value = response
    req = ScrapeRequest('https://shop.test/product/wall-art', max_items=3, dry_run=True)
    result = ScrapeResult(req.url, 'shop.test')
    assert WooCommerceAdapter(fetcher).scrape(req, result)
    assert result.products[0].sku == 'WA-7'
    assert result.images[0].image_url == 'https://cdn.test/full.jpg'


def test_downloader_tries_published_alternative_after_small_candidate(tmp_path):
    from jarvis_scraper.download.downloader import Downloader
    from jarvis_scraper.models import ImageAsset
    small = BytesIO(); Image.new('RGB', (100, 100), 'red').save(small, format='JPEG')
    large = BytesIO(); Image.new('RGB', (800, 600), 'green').save(large, format='JPEG')
    responses = []
    for content in (small.getvalue(), large.getvalue()):
        r = Mock(); r.content = content; r.headers = {'Content-Type': 'image/jpeg'}; responses.append(r)
    fetcher = Mock(); fetcher.get.side_effect = responses
    asset = ImageAsset('https://shop.test/p', 'https://cdn.test/small.jpg', candidate_urls=['https://cdn.test/large.jpg'])
    Downloader(300, 300, fetcher=fetcher).download(asset, tmp_path)
    assert asset.download_status == 'downloaded'
    assert asset.image_url == 'https://cdn.test/large.jpg'
    assert fetcher.get.call_count == 2


def test_strategy_memory_roundtrip(tmp_path):
    from jarvis_scraper.storage.strategy_memory import StrategyMemory
    path = tmp_path / 'memory.json'
    memory = StrategyMemory(path)
    memory.remember('shop.test', 'static', 'woocommerce', 'ecommerce')
    loaded = StrategyMemory(path).get('shop.test')
    assert loaded['strategy'] == 'static'
    assert loaded['platform'] == 'woocommerce'


def test_shopify_cdn_only_is_weak_not_storefront_proof():
    fp = detect_platform('https://www.shopify.com/stock-photos/pattern', '<img src="https://cdn.shopify.com/example.jpg">')
    assert fp.scores.get('shopify') == 0.60


def test_provider_highres_candidates_known_cdns():
    from jarvis_scraper.download.highres import provider_highres_candidates
    burst = provider_highres_candidates('https://burst.shopifycdn.com/photos/a.jpg?width=150&height=150&exif=0')
    assert burst[0] == 'https://burst.shopifycdn.com/photos/a.jpg?exif=0'
    hdq = provider_highres_candidates('https://images.hdqwalls.com/wallpapers/thumb/a.jpg')
    assert hdq[0] == 'https://images.hdqwalls.com/wallpapers/a.jpg'
    craft = provider_highres_candidates('https://images.wallpaperscraft.com/image/single/a_300x168.jpg')
    assert craft[0].endswith('_3840x2160.jpg')
