from io import BytesIO
from PIL import Image
from jarvis_scraper.download.validator import validate_image

def png_bytes(size=(400,400)):
    b=BytesIO(); Image.new('RGB',size).save(b,'PNG'); return b.getvalue()

def test_valid_png():
    ok,info=validate_image(png_bytes(),'image/png',300,300)
    assert ok and info['width']==400

def test_reject_html():
    ok,info=validate_image(b'<html>blocked</html>','text/html',1,1)
    assert not ok and info['reason']=='invalid_mime'

def test_low_resolution():
    ok,info=validate_image(png_bytes((100,100)),'image/png',300,300)
    assert not ok and info['reason']=='low_resolution'
