from jarvis_scraper.extractors.json_ld import extract_jsonld_products

def test_jsonld_product():
    html='''<script type="application/ld+json">{"@type":"Product","name":"Poster","url":"/p/poster","sku":"S1","image":["/a.jpg"]}</script>'''
    p=extract_jsonld_products(html,'https://x.test/cat')[0]
    assert p.name=='Poster'
    assert p.url=='https://x.test/p/poster'
    assert p.images[0].image_url=='https://x.test/a.jpg'
