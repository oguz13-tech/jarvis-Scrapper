from jarvis_scraper.extractors.html_images import extract_images

def test_relative_and_og_and_css():
    html='''<meta property="og:image" content="/og.jpg"><img src="/small.jpg" srcset="/a.jpg 400w, /b.jpg 1200w"><div style="background-image:url('/bg.jpg')"></div>'''
    urls={x.image_url for x in extract_images(html,'https://x.test/page')}
    assert 'https://x.test/b.jpg' in urls
    assert 'https://x.test/og.jpg' in urls
    assert 'https://x.test/bg.jpg' in urls


def test_ui_icons_are_not_gallery_images():
    html='''<img src="/icons/app-logo.svg"><img src="/gallery/art.jpg">'''
    urls={x.image_url for x in extract_images(html,'https://x.test/page')}
    assert 'https://x.test/icons/app-logo.svg' not in urls
    assert 'https://x.test/gallery/art.jpg' in urls
