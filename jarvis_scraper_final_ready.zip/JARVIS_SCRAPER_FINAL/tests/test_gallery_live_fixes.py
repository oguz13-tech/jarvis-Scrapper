from jarvis_scraper.extractors.gallery import detail_links
from jarvis_scraper.extractors.svg import extract_svg_assets


def test_generic_image_card_can_discover_slug_detail_page():
    html = '<div class="gallery-card"><a href="/beautiful-autumn-scene"><img src="/thumb.jpg"></a></div>'
    assert detail_links(html, 'https://x.test/search') == ['https://x.test/beautiful-autumn-scene']


def test_svg_gallery_filters_navigation_icon_noise():
    html = '<img src="/icons/app-logo.svg"><a href="/patterns/floral.svg">x</a>'
    urls = [x.image_url for x in extract_svg_assets(html, 'https://x.test')]
    assert urls == ['https://x.test/patterns/floral.svg']
