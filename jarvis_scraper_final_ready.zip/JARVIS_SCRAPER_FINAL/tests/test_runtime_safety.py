from pathlib import Path
from unittest.mock import Mock

import pytest

from jarvis_scraper.download.downloader import check_free_space, DiskSpaceError
from jarvis_scraper.fetchers.http_fetcher import HttpFetcher
from jarvis_scraper.fetchers.browser_fetcher import BrowserFetcher
from jarvis_scraper.models import Status


def test_disk_space_guard_raises(monkeypatch, tmp_path):
    monkeypatch.setattr('jarvis_scraper.download.downloader.shutil.disk_usage', lambda _p: (10, 9, 512 * 1024 * 1024))
    with pytest.raises(DiskSpaceError) as error:
        check_free_space(tmp_path, min_gb=2)
    assert error.value.status == Status.DOWNLOAD_ERROR
    assert 'Disk alanı kritik' in str(error.value)


def test_disk_space_guard_passes(monkeypatch, tmp_path):
    monkeypatch.setattr('jarvis_scraper.download.downloader.shutil.disk_usage', lambda _p: (10, 1, 5 * (2 ** 30)))
    assert check_free_space(tmp_path, min_gb=2) == 5 * (2 ** 30)


def test_adaptive_backoff_429_and_recovery():
    fetcher = HttpFetcher(delay=0.5, respect_robots=False)
    url = 'https://site.test/a'
    fetcher._note_response(url, 429, {'Retry-After': '3'})
    assert fetcher.domain_delay['site.test'] >= 3
    for _ in range(10):
        fetcher._note_response(url, 200, {})
    assert 0.5 <= fetcher.domain_delay['site.test'] < 3


def test_403_slows_but_does_not_imply_retry():
    fetcher = HttpFetcher(delay=0.5, respect_robots=False)
    url = 'https://site.test/a'
    fetcher._note_response(url, 403, {})
    assert fetcher.domain_delay['site.test'] >= 1.0


class _Keyboard:
    def __init__(self):
        self.pressed = []
    def press(self, key):
        self.pressed.append(key)


class _Locator:
    def __init__(self, visible=False):
        self.visible = visible
        self.clicked = False
        self.first = self
    def count(self):
        return 1 if self.visible else 0
    def is_visible(self):
        return self.visible
    def click(self, timeout=0):
        self.clicked = True


class _Page:
    def __init__(self, visible_selector=None):
        self.visible_selector = visible_selector
        self.locators = {}
        self.keyboard = _Keyboard()
    def locator(self, selector):
        loc = self.locators.setdefault(selector, _Locator(selector == self.visible_selector))
        return loc
    def wait_for_timeout(self, _ms):
        pass


def test_dismiss_public_modal_uses_visible_close_control():
    selector = 'button[aria-label="Close"]'
    page = _Page(visible_selector=selector)
    assert BrowserFetcher._dismiss_public_modal(page) is True
    assert page.locators[selector].clicked is True


def test_dismiss_public_modal_falls_back_to_escape_only():
    page = _Page()
    assert BrowserFetcher._dismiss_public_modal(page) is False
    assert page.keyboard.pressed == ['Escape']
