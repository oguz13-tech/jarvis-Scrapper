import json
import threading
from pathlib import Path

import pytest

from jarvis_scraper.engine import _limit_reached
from jarvis_scraper.exceptions import ScrapeError
from jarvis_scraper.models import ImageAsset, Product, ScrapeRequest, ScrapeResult, Status
from jarvis_scraper.storage.state import State
from jarvis_scraper.download.downloader import Downloader


def test_separate_limits_and_unlimited_semantics():
    r = ScrapeRequest('https://example.com', max_items=0, max_products=25, max_images=500)
    assert r.product_limit == 25
    assert r.image_limit == 500
    r = ScrapeRequest('https://example.com', max_items=0, max_products=None, max_images=None)
    assert r.product_limit is None
    assert r.image_limit is None


def test_target_reached_gallery_ignores_extra_rejections():
    req = ScrapeRequest('https://example.com', max_items=0, max_images=13)
    result = ScrapeResult(req.url, 'example.com')
    counts = {'images_downloaded': 13, 'images_duplicate': 0, 'resume_skipped': 0}
    assert _limit_reached(result, req, counts)


def test_target_reached_products_by_saved_product_count():
    req = ScrapeRequest('https://example.com', max_items=0, max_products=2)
    ok1 = ImageAsset(req.url, 'https://img/1.jpg', download_status='downloaded')
    ok2 = ImageAsset(req.url, 'https://img/2.jpg', download_status='resume_skipped')
    bad = ImageAsset(req.url, 'https://img/3.jpg', download_status='rejected')
    result = ScrapeResult(req.url, 'example.com', products=[
        Product('a', 'https://p/1', images=[ok1, bad]),
        Product('b', 'https://p/2', images=[ok2]),
    ])
    assert _limit_reached(result, req, {'images_downloaded': 1, 'images_duplicate': 0, 'resume_skipped': 1})


def test_state_is_atomic_and_tolerates_corruption(tmp_path: Path):
    path = tmp_path / 'state.json'
    state = State(path)
    state.save({'status': 'running', 'next_index': 3})
    assert state.load()['next_index'] == 3
    path.write_text('{broken', encoding='utf-8')
    assert state.load() == {}


def test_downloader_honors_cancel_before_network(tmp_path: Path):
    event = threading.Event(); event.set()
    downloader = Downloader(cancel_event=event)
    asset = ImageAsset('https://example.com', 'https://example.com/a.jpg')
    with pytest.raises(ScrapeError) as exc:
        downloader.download(asset, tmp_path)
    assert exc.value.status == Status.STOPPED
