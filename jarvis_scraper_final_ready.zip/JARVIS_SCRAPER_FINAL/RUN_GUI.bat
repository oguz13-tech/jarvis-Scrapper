@echo off
setlocal
cd /d "%~dp0"
title JARVIS SCRAPER

set "PY=.venv\Scripts\python.exe"
set "PYW=.venv\Scripts\pythonw.exe"

if not exist "%PY%" (
  echo [JARVIS] Ilk kurulum baslatiliyor...
  py -3 -m venv .venv 2>nul || python -m venv .venv
  if errorlevel 1 goto :error
  "%PY%" -m pip install --upgrade pip setuptools wheel
  if errorlevel 1 goto :error
  "%PY%" -m pip install -e ".[browser]"
  if errorlevel 1 goto :error
) else (
  "%PY%" -c "import jarvis_scraper, playwright" >nul 2>&1
  if errorlevel 1 (
    echo [JARVIS] Proje baglantisi/bağımliliklari yenileniyor...
    "%PY%" -m pip install -e ".[browser]"
    if errorlevel 1 goto :error
  )
)

rem Chromium binary mevcut mu? Yoksa otomatik kur.
"%PY%" -c "from playwright.sync_api import sync_playwright; p=sync_playwright().start(); b=p.chromium.launch(headless=True); b.close(); p.stop()" >nul 2>&1
if errorlevel 1 (
  echo [JARVIS] Playwright Chromium kuruluyor/onariliyor...
  "%PY%" -m playwright install chromium
  if errorlevel 1 goto :error
)

if not exist "%PYW%" set "PYW=%PY%"
start "JARVIS SCRAPER" "%PYW%" -m jarvis_scraper.gui
exit /b 0

:error
echo.
echo [HATA] JARVIS kurulumu veya baslatmasi tamamlanamadi.
echo Bu pencerenin ekran goruntusunu ChatGPT'ye gonderebilirsin.
pause
exit /b 1
