# JARVIS SCRAPER — FINAL CHECKLIST

- [x] Tek/multi URL GUI
- [x] URL başına bağımsız job ve hata izolasyonu
- [x] Runtime platform detector
- [x] Shopify adapter
- [x] WooCommerce adapter
- [x] Etsy adapter
- [x] Trendyol adapter
- [x] Wallhaven / Reddit / Pinterest yolları
- [x] Pixabay / Pexels / Unsplash API + public fallback
- [x] Generic static + dynamic fallback
- [x] Next.js / Nuxt / React hydration/embedded JSON
- [x] JSON-LD / OpenGraph / srcset / lazy attributes
- [x] Detail-page discovery
- [x] Download/original-page bounded hop
- [x] Provider high-resolution resolver
- [x] Thumbnail/preview quality gate
- [x] Logo/icon/placeholder filtering
- [x] Generic SVG chrome filtering
- [x] Binary MIME/Pillow/SVG validation
- [x] Yatay / Dikey / Kare
- [x] Product → all gallery image relationship
- [x] Optional product folders
- [x] URL/SHA256/perceptual dedup
- [x] Resume + manifest
- [x] Strategy memory
- [x] Session CSV/JSON summary
- [x] 42 URL validation corpus
- [x] Live diagnostics script
- [x] 107 deterministic tests
- [x] compileall PASS
- [x] CLI help PASS

Final canlı kabul: kullanıcının Windows ağında `RUN_LIVE_42.bat` çalıştırılarak ölçülür. Gerçek login/CAPTCHA/paywall/HTTP erişim kontrolleri başarı olarak taklit edilmez.
