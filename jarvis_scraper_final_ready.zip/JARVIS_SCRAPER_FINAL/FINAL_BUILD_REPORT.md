# JARVIS SCRAPER — FINAL BUILD REPORT

## Final hedef

Tek kullanıcı arayüzü: URL/URL'leri yapıştır → Kazımayı Başlat. 42 URL sabit kullanım listesi değil, motor doğrulama corpus'udur.

## Bu final birleşimde tamamlanan ana maddeler

- Etsy dedicated adapter motorun gerçek strategy tablosuna bağlandı.
- Trendyol dedicated adapter motorun gerçek strategy tablosuna bağlandı.
- Etsy/Trendyol registry + detector + CLI entegrasyonu tamamlandı.
- Kullanıcının eski çalışan Etsy mantığı: listing → detail → gallery korundu.
- Kullanıcının eski çalışan Trendyol mantığı: `pi` pagination → detail → gallery → `mnresize` resolver korundu.
- Pixabay eski çalışan yaklaşımından detail-page/high-res fikri generic ve provider resolver katmanına taşındı.
- Pixabay/Pexels/Unsplash: API varsa resmi API, yoksa public dynamic/detail fallback.
- Static aday yalnız thumbnail/invalid ise strateji SUCCESS sayılmıyor; dynamic fallback devam ediyor.
- Public sayfada yayımlanmış exact asset binary URL'si için asset-CDN robots false-negative problemi giderildi.
- Browser lazy-load image request URL'leri, currentSrc/srcset/data-* değerleri, OG image, image preload ve CSS background adayları yakalanıyor.
- Browser public session cookie'leri subsequent HTTP asset download session'ına aktarılıyor.
- Pexels/Unsplash query-size high-res resolver eklendi.
- Trendyol named/numeric `mnresize` resolver sağlamlaştırıldı.
- Generic SVG UI/chrome dosyalarının yanlış içerik olarak kaydedilmesi engellendi.
- Etsy gallery filtresi yalnız Etsy image CDN ürün medyasına daraltıldı.
- Etsy/Trendyol srcset fallback genişletildi.
- `ORIGINAL_NOT_FOUND` diagnostics retry-plan tip hatası düzeltildi.
- GUI'ye `robots.txt politikasına uy` seçeneği eklendi; varsayılan açık.
- Eski V1/V1.2/V1.3/V1.4 teslim adı kaldırıldı; tek release klasörü `JARVIS_SCRAPER_FINAL`.


## Son güvenlik/stabilite sertleştirmesi

- `RUN_SELF_TEST.bat` artık yalnız compile/CLI kontrolü yapmıyor; gerçek `pytest tests -v` test takımını ve Playwright Chromium açılışını da doğruluyor.
- İndirme öncesi ve dosyaya yazmadan hemen önce disk boş alanı kontrol ediliyor. Varsayılan eşik 2 GB; `.env` içinde `MIN_FREE_GB` ile değiştirilebilir.
- HTTP pacing artık domain bazlı adaptif backoff kullanıyor: 429/5xx sunucu baskı sinyallerinde gecikme artıyor, başarılı seri sonrasında taban gecikmeye kontrollü geri dönüyor. 403 otomatik yeniden denenmiyor.
- Pinterest browser fallback yalnız görünür/kapatılabilir public modalı normal UI eylemiyle kapatmayı dener; DOM silme veya login duvarı aşma yoktur. Gerçek login zorunluluğu `LOGIN_REQUIRED` olarak kalır.

## Operatör güvenliği / final GUI

- E-ticaret için ayrı **ürün limiti**, galeri/stock için ayrı **görsel limiti** eklendi. Alan boşsa kullanıcı limiti yoktur; crawler yeni içerik kalmayana kadar devam eder (yüksek güvenlik tavanları yine sonsuz döngüyü önler).
- **KAZIMAYI BAŞLAT + DURDUR** akışı eklendi. Durdurma güvenli noktada `STOPPED` durumuna geçer.
- Açılıp kapanabilen **Canlı Teknik Log** paneli, log kopyalama ve log dosyasını açma butonları eklendi.
- Heartbeat: geçen süre ve “son hareket kaç saniye önce” bilgisi görünür; dondu mu/çalışıyor mu belirsizliği giderildi.
- Her oturum `output/_session_logs/...log` dosyasına teknik log yazar.
- `JARVIS_SESSION_STATE.json` atomik checkpoint ile güncellenir; X ile kapanma/elektrik kesintisi sonrası uygulama yarım kalan işi algılar ve devam etmeyi önerir.
- Manifest her başarılı görsel sonrası fsync ile kalıcıdır. Yarım `.part` dosyaları resume öncesi temizlenir; tamamlanmış dosyalar tekrar indirilmez.
- Tkinter değişkenlerinin worker thread içinden okunması kaldırıldı; tüm GUI ayarları ana thread'de snapshot alınarak worker'a aktarılır.
- Kullanıcı hedefi örn. 13/13 tamamlandıysa, reddedilmiş ekstra adaylar sonucu yanlışlıkla PARTIAL_SUCCESS'a düşürmez.
- State JSON ve oturum özetleri atomic replace ile yazılır.
- Mevcut venv'de Chromium eksikse `RUN_GUI.bat` otomatik kontrol/onarım yapar.

## Deterministic doğrulama

- Unit/regression tests: **118 passed**
- Compile: **PASS**
- CLI help/import: **PASS**

## Canlı kanıtın durumu

Önceki 42-site canlı koşu gerçek kullanıcı Windows ortamında tamamlanmıştı ve ana hata sınıflarını ortaya çıkardı. Bu final build o koşudan sonra değişti. Mevcut çalışma konteynerinde dış internetli 42-site Python koşusu tekrar yapılamadığı için yeni build için 42/42 canlı başarı iddiası yapılmaz.

`RUN_LIVE_42.bat` final motoru kullanıcının gerçek ağında tekrar ölçmek için hazırdır.
