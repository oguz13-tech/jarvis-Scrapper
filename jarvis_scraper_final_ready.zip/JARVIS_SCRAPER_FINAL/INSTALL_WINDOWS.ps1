$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
if (-not (Test-Path -LiteralPath '.venv\Scripts\python.exe')) {
    python -m venv .venv
    if ($LASTEXITCODE -ne 0) { throw 'Python 3.10+ is required.' }
}
& .venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
if ($LASTEXITCODE -ne 0) { throw 'Dependency bootstrap failed.' }
& .venv\Scripts\python.exe -m pip install -e '.[browser,dev]'
if ($LASTEXITCODE -ne 0) { throw 'Dependency installation failed.' }
& .venv\Scripts\python.exe -m playwright install chromium
if ($LASTEXITCODE -ne 0) { Write-Warning 'Chromium setup failed. Static and API strategies remain available.' }
& .venv\Scripts\python.exe -m jarvis_scraper --help
