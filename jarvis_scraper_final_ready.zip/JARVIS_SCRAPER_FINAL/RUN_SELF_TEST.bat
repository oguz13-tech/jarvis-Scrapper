@echo off
setlocal
cd /d "%~dp0"
title JARVIS SCRAPER SELF TEST
set "PY=.venv\Scripts\python.exe"

if not exist "%PY%" (
  echo Once RUN_GUI.bat dosyasini calistirarak kurulumu tamamla.
  pause
  exit /b 1
)

echo [1/5] Python kaynaklari derleniyor...
"%PY%" -m compileall -q jarvis_scraper
if errorlevel 1 goto :error

echo [2/5] CLI acilis testi...
"%PY%" -m jarvis_scraper --help >nul
if errorlevel 1 goto :error

echo [3/5] Pytest hazirlaniyor...
"%PY%" -c "import pytest" >nul 2>&1
if errorlevel 1 (
  "%PY%" -m pip install -e ".[dev]"
  if errorlevel 1 goto :error
)

echo [4/5] Birim testleri calisiyor...
"%PY%" -m pytest tests -v
if errorlevel 1 goto :error

echo [5/5] Playwright Chromium acilis testi...
"%PY%" -c "from playwright.sync_api import sync_playwright; p=sync_playwright().start(); b=p.chromium.launch(headless=True); b.close(); p.stop()"
if errorlevel 1 goto :error

echo.
echo JARVIS SELF TEST BASARILI.
pause
exit /b 0

:error
echo.
echo JARVIS SELF TEST BASARISIZ.
echo Yukaridaki FAIL/ERROR satirlarini ChatGPT'ye gonderebilirsin.
pause
exit /b 1
