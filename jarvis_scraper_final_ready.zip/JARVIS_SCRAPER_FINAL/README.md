# JARVIS SCRAPER — FINAL

JARVIS Scraper, tek bir URL veya alt alta birden fazla URL alıp site yapısını çalışma anında analiz eden, ürün/galeri detay sayfalarını takip eden ve mümkün olan en büyük yayımlanmış görsel adayını indiren genel amaçlı görsel/ürün kazıma motorudur.

## Kullanıcı akışı

Windows'ta `RUN_GUI.bat` dosyasına çift tıklayın. Açılan ekrana tek URL veya alt alta istediğiniz kadar URL yapıştırın ve **KAZIMAYI BAŞLAT** düğmesine basın. Sistem yalnızca verdiğiniz URL'leri işler.

Arayüzde:
- maksimum ürün/görsel sayısını,
- minimum görsel boyutunu,
- ürün başına klasör kullanımını,
- `robots.txt` politikasına uyulup uyulmayacağını
seçebilirsiniz.

Varsayılan davranış güvenli taraftadır: `robots.txt` açıktır. Login/CAPTCHA/paywall veya gerçek yetkilendirme bariyerlerini aşan kod yoktur. Public sayfalarda normal HTTP, normal Chromium render, resmi API ve yayımlanmış sayfa/JSON/CDN bağlantıları kullanılır.

## Motorun ana mantığı

```text
URL
 ↓
site/platform tespiti
 ↓
özel adapter varsa onu dene
 ↓
static / dynamic / API fallback
 ↓
liste-kategori-arama sayfasından içerik/ürün detay linklerini bul
 ↓
detay sayfasına gir
 ↓
galeri + srcset + data-full + data-zoom + JSON-LD + hydration/XHR + OG
 ↓
provider-specific high-res resolver
 ↓
gerçek binary doğrulama
 ↓
thumbnail / logo / ikon / placeholder filtreleme
 ↓
dedup + resume
 ↓
Yatay / Dikey / Kare
```

Bir strateji yalnızca URL bulduğu için başarılı sayılmaz. En az bir adayın gerçek görsel bytes'ı olarak doğrulanması, minimum çözünürlüğü geçmesi ve UI/thumbnail filtresinden kurtulması gerekir. Aksi halde motor sonraki fallback stratejisine geçer.

## Özel adapter ve çözümleyiciler

- Shopify
- WooCommerce
- Etsy
- Trendyol
- Wallhaven public API
- Reddit public JSON
- Pinterest public sayfalar
- Pixabay (API varsa API, yoksa public browser/detail fallback)
- Pexels (API varsa API, yoksa public browser/detail fallback)
- Unsplash (API varsa API, yoksa public browser/detail fallback)
- Generic static HTML
- Generic dynamic / Playwright

Runtime fingerprinting ayrıca WordPress, Magento, PrestaShop, OpenCart, BigCommerce, Salesforce Commerce, Next.js, Nuxt ve React yapılarında generic motoru yönlendirir.

### Yüksek çözünürlük kuralları

Final resolver yalnız bilinen/published transform kalıplarında URL yükseltmesi yapar. Şu anda özellikle:
- Pixabay `_1920` / `_1280`
- Etsy `il_fullxfull`
- Trendyol/DSM `mnresize`
- Shopify/Burst width-height query temizleme
- Pexels geometry query temizleme
- Unsplash geometry query temizleme
- HDQWalls thumb → büyük sibling
- WallpapersCraft çözünürlük varyantları
- DeviantArt/Wix transform temizleme
- AdaWall 250 → 800
- 3dduvarkagitlari medium → large sibling
kuralları bulunur.

Bilinmeyen hostlarda agresif URL tahmini yapılmaz; yayımlanmış `srcset`, JSON, download/original linkleri ve detay sayfası adayları tercih edilir.

## Etsy ve Trendyol

Bu iki adapter kullanıcının daha önce çalışan eski scraper mantığından taşındı ve mevcut motorla birleştirildi.

**Etsy:** listing/shop/search → listing detail → carousel/gallery → Etsy CDN → `il_fullxfull` doğrulaması.

**Trendyol:** `pi=` pagination → product-card/detail → carousel/gallery/app-state → DSM CDN → `mnresize` temizleme → gerçek binary doğrulaması.

Ürün başına sabit 10/15 foto limiti yoktur; bulunan public ürün galerisi görüntülerinin tamamı işlenir.

## Thumbnail/logo/ikon koruması

- Bilinen thumbnail/preview URL'leri nihai sonuç sayılmaz.
- Logo, favicon, sosyal medya ikonu, avatar, badge, payment icon, language flag, loader, placeholder, QR vb. elenir.
- Generic SVG dosyaları varsayılan olarak UI/chrome kabul edilir; yalnız explicit SVG/vector-gallery çıkarımı gerçek vector içerik olarak kaydedilir.
- MIME başlığına kör güvenilmez; Pillow/bytes ile gerçek format doğrulanır.
- CDN `application/octet-stream` döndürse bile bytes gerçek görselse kabul edilebilir.

## Direct asset davranışı

Sayfa keşfi/navigation `robots.txt` tercihine göre yürür. İzin verilen bir sayfa veya resmi API açıkça bir görsel binary URL'si yayımladıktan sonra, o **exact URL** doğrudan indirilir; asset CDN'in ayrı robots dosyasının okunamaması ürün galerisini yanlışlıkla `DOWNLOAD_ERROR` yapmaz. HTTP 401/403/429 ve gerçek erişim kontrolleri yine hata olarak kalır.

## Çıktı

```text
output/
  domain/
    job-urlhash/
      manifest.jsonl
      scrape_report.json
      products.csv               # ürün varsa
      metadata/.../metadata.json # ürün varsa
      Yatay/
      Dikey/
      Kare/
```

`Ürün başına klasör oluştur` açık olduğunda yön klasörlerinin altında ürün klasörleri oluşur. Kapalı olsa bile ürün→görsel ilişkisi manifest ve metadata içinde korunur.

Aynı görsel URL/SHA256/perceptual-hash ile yeniden kaydedilmez. `resume` açık olduğunda disk SHA256 doğrulanır; eksik/bozuk dosya yeniden indirilir.

## Kurulum

Python 3.10+ gereklidir. Önerilen: Python 3.11/3.12.

En kolay Windows kullanımı: ZIP'i kısa bir klasöre çıkarın ve `RUN_GUI.bat` dosyasına çift tıklayın. İlk çalıştırmada proje `.venv` ortamını ve Playwright Chromium'u kurar.

Elle kurulum:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools wheel
.\.venv\Scripts\python.exe -m pip install -e ".[browser,dev]"
.\.venv\Scripts\python.exe -m playwright install chromium
```

## Resmi stock API anahtarları

Arayüzde **API Ayarları** bölümünden veya `.env` ile eklenebilir:

```dotenv
PIXABAY_API_KEY=
PEXELS_API_KEY=
UNSPLASH_ACCESS_KEY=
WALLHAVEN_API_KEY=
REQUEST_DELAY=0.75
MAX_RETRIES=3
MIN_FREE_GB=2
```

Anahtar yoksa Pixabay/Pexels/Unsplash dedicated adapter'ı public browser/detail fallback kullanır. Anahtar varsa resmi API yolu önceliklidir.

## CLI

```powershell
.\.venv\Scripts\python.exe -m jarvis_scraper "URL" --output output --max-items 100 --resume
.\.venv\Scripts\python.exe -m jarvis_scraper --file urls.txt --output output --resume
```

Stratejiler:

```text
auto, shopify, woocommerce, static, dynamic, official_api,
reddit, pinterest, pixabay, pexels, unsplash, etsy, trendyol
```

CLI'da `--respect-robots` varsayılandır; kullanıcı açıkça isterse `--no-respect-robots` kullanılabilir. Bu seçenek login/CAPTCHA/paywall/HTTP authorization bariyerlerini aşmaz.


## Self-test ve runtime güvenliği

`RUN_SELF_TEST.bat` gerçek birim/regression testlerini (`pytest tests -v`) çalıştırır, CLI/compile kontrolü yapar ve Playwright Chromium'un gerçekten açılabildiğini doğrular.

İndirme motoru destination diskinde varsayılan en az **2 GB** boş alan ister. Eşik `.env` içindeki `MIN_FREE_GB` ile ayarlanabilir. Yazma işlemleri `.part` geçici dosyası üzerinden atomik rename ile tamamlanır; yarım dosya nihai dosya adıyla bırakılmaz.

HTTP katmanı sabit taban gecikmesini korurken 429/5xx gibi açık sunucu baskı sinyallerine domain bazında adaptif backoff uygular ve `Retry-After` değerine uyar. 403 otomatik olarak tekrar tekrar denenmez.

Pinterest'te yalnız kullanıcı tarafından normal şekilde kapatılabilen public modal için close/Escape denenir. Login zorunluluğu devam ediyorsa scraper bunu aşmaya çalışmaz ve `LOGIN_REQUIRED` raporlar.

## 42-site doğrulama havuzu

`urls.txt`, projenin 42 URL'lik gerçek saha test corpus'udur. Bu liste final kullanıcının sabit site listesi değildir; motorun altyapı ailelerini sınamak için kullanılır. Kullanıcı arayüzde o anda hangi URL'yi verirse motor onu işler.

Tek tık canlı corpus testi:

```text
RUN_LIVE_42.bat
```

veya:

```powershell
.\.venv\Scripts\python.exe scripts\live_test.py --file urls.txt --max-items 3 --output live_42 --resume
```

Bu koşu `summary.json`, `diagnostics.json` ve `REPORT.md` üretir.

## Test durumu

Paketlenmeden önce:
- `113 passed`
- `python -m compileall -q jarvis_scraper` başarılı
- `python -m jarvis_scraper --help` başarılı

Bu final değişikliklerden sonra 42 sitelik dış internet koşusu bu çalışma ortamından yeniden çalıştırılamadı; bu nedenle erişim engeli olan siteler için sahte “42/42 başarı” iddiası yoktur. `RUN_LIVE_42.bat` gerçek Windows/ağ ortamında aynı motorun son durumunu ölçmek için pakette bırakılmıştır.

## Önemli sınırlar

Public erişim, görseli kullanma/lisans hakkı anlamına gelmez. Bazı siteler 403/429, login, CAPTCHA, paywall veya başka gerçek erişim kontrolleri uygulayabilir. Bu durumlar içerik/parser hatası gibi gösterilmez; raporda ayrı status olarak tutulur.
