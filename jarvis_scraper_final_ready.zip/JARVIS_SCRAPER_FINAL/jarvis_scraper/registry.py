from .models import SiteProfile

# Registry entries are only hints. Runtime fingerprints in platforms.py/detector.py
# are allowed to override them when a site changes its stack.
REGISTRY = {
    "iamfy.co": SiteProfile("iamfy.co", "shopify", "shopify", notes="Shopify art store"),
    "tendaexclusive.com.tr": SiteProfile("tendaexclusive.com.tr", "shopify", "shopify", notes="Shopify storefront"),
    "wallhaven.cc": SiteProfile("wallhaven.cc", "official_api", "wallhaven", official_api=True),
    "reddit.com": SiteProfile("reddit.com", "reddit", "reddit"),
    "pinterest.com": SiteProfile("pinterest.com", "dynamic", "pinterest", notes="Public pages only"),
    "wallpaperflare.com": SiteProfile("wallpaperflare.com", "static", "generic_static"),
    "pixabay.com": SiteProfile("pixabay.com", "pixabay", "pixabay", official_api=True),
    "pexels.com": SiteProfile("pexels.com", "pexels", "pexels", official_api=True),
    "unsplash.com": SiteProfile("unsplash.com", "unsplash", "unsplash", official_api=True),
    # Broad infrastructure hints for the user's validation corpus. These do not mean "supported".
    "magicdecor.in": SiteProfile("magicdecor.in", "static", "generic_static"),
    "posterstore.nz": SiteProfile("posterstore.nz", "static", "generic_static"),
    "canva.com": SiteProfile("canva.com", "dynamic", "generic_dynamic", requires_auth=False),
    "rawpixel.com": SiteProfile("rawpixel.com", "dynamic", "generic_dynamic"),
    "kaboompics.com": SiteProfile("kaboompics.com", "dynamic", "generic_dynamic"),
    "vecteezy.com": SiteProfile("vecteezy.com", "dynamic", "generic_dynamic"),
    "deviantart.com": SiteProfile("deviantart.com", "dynamic", "generic_dynamic"),
    "trendyol.com": SiteProfile("trendyol.com", "trendyol", "trendyol", notes="Marketplace product/listing adapter"),
    "etsy.com": SiteProfile("etsy.com", "etsy", "etsy", notes="Marketplace listing/detail adapter"),
    "magnific.com": SiteProfile("magnific.com", "dynamic", "generic_dynamic"),
    "dreampix.ai": SiteProfile("dreampix.ai", "dynamic", "generic_dynamic"),
    "pattern.monster": SiteProfile("pattern.monster", "static", "generic_static", notes="SVG/gallery"),
    "cleanpng.com": SiteProfile("cleanpng.com", "static", "generic_static"),
    "pngwing.com": SiteProfile("pngwing.com", "static", "generic_static"),
    "alphacoders.com": SiteProfile("alphacoders.com", "static", "generic_static"),
    "4kwallpapers.com": SiteProfile("4kwallpapers.com", "static", "generic_static"),
    "getwallpapers.com": SiteProfile("getwallpapers.com", "static", "generic_static"),
    "wallpaperscraft.com": SiteProfile("wallpaperscraft.com", "static", "generic_static"),
    "hdqwalls.com": SiteProfile("hdqwalls.com", "static", "generic_static"),
    "pickpik.com": SiteProfile("pickpik.com", "static", "generic_static"),
    "stocksnap.io": SiteProfile("stocksnap.io", "static", "generic_static"),
    "foodiesfeed.com": SiteProfile("foodiesfeed.com", "static", "generic_static"),
    "artvee.com": SiteProfile("artvee.com", "static", "generic_static"),
    "adawall.com.tr": SiteProfile("adawall.com.tr", "static", "generic_static"),
    "3dduvarkagitlari.com": SiteProfile("3dduvarkagitlari.com", "static", "generic_static"),
    "3boyutluduvarkagitlari.com": SiteProfile("3boyutluduvarkagitlari.com", "static", "generic_static"),
}


def normalize_domain(domain: str) -> str:
    d = domain.lower().split(":")[0].rstrip('.')
    if d.startswith("www."):
        d = d[4:]
    aliases = {
        "tr.pinterest.com": "pinterest.com",
        "m.pinterest.com": "pinterest.com",
        "old.reddit.com": "reddit.com",
        "new.reddit.com": "reddit.com",
    }
    return aliases.get(d, d)


def get_profile(domain: str) -> SiteProfile:
    d = normalize_domain(domain)
    return REGISTRY.get(d, SiteProfile(d))
