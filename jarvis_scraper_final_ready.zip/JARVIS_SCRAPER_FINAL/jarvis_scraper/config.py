import os
from dotenv import load_dotenv
load_dotenv()

USER_AGENT = os.getenv("USER_AGENT", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36")
REQUEST_DELAY = float(os.getenv("REQUEST_DELAY", "0.75"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))

MIN_FREE_GB = float(os.getenv("MIN_FREE_GB", "2"))
