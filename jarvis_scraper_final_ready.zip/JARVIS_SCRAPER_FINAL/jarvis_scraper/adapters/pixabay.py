import os

from .stock_api import StockAPIAdapter, KEYS
from .generic_dynamic import GenericDynamicAdapter


class PixabayAdapter(StockAPIAdapter):
    """Pixabay: official API when configured, otherwise public browser/detail fallback."""
    provider = 'pixabay'

    def scrape(self, request, result) -> bool:
        if os.getenv(KEYS[self.provider]):
            return super().scrape(request, result)
        result.warnings.append('PIXABAY_API_KEY yok; public browser/detail-page fallback kullanılıyor')
        return GenericDynamicAdapter(self.fetcher, self.browser).scrape(request, result)
