from __future__ import annotations

from html import unescape
import re
from urllib.parse import urljoin, urlsplit, urlencode

from .base import BaseAdapter
from ..models import Product, ImageAsset
from ..exceptions import ScrapeError


class WooCommerceAdapter(BaseAdapter):
    """Use WooCommerce's public Store API when the storefront exposes it.

    No credentials or private WC REST API keys are used. Failure is soft so the
    engine can fall back to normal public HTML/browser extraction.
    """

    def _get_json(self, url: str, result):
        try:
            return self.fetcher.get(url).json()
        except (ScrapeError, ValueError, TypeError) as e:
            result.warnings.append(f'WooCommerce Store API unavailable: {type(e).__name__}: {e}')
            return None

    @staticmethod
    def _clean(text):
        if not isinstance(text, str):
            return text
        return re.sub(r'<[^>]+>', ' ', unescape(text)).strip()

    def _product(self, raw: dict, base: str) -> Product | None:
        url = raw.get('permalink') or raw.get('url') or base
        p = Product(
            name=raw.get('name') or 'Product', url=urljoin(base, url), id=str(raw.get('id') or url),
            sku=raw.get('sku') or None, description=self._clean(raw.get('description') or raw.get('short_description')),
            slug=raw.get('slug'), metadata={
                'prices': raw.get('prices'), 'categories': raw.get('categories'),
                'type': raw.get('type'), 'average_rating': raw.get('average_rating'),
            },
        )
        seen = set()
        for image in raw.get('images') or []:
            if not isinstance(image, dict):
                continue
            # src is the published full image. srcset may expose an even larger variant.
            src = image.get('src')
            srcset = image.get('srcset') or ''
            if srcset:
                from ..extractors.srcset import best_srcset
                src = best_srcset(srcset) or src
            if src:
                src = urljoin(base, src)
                if src not in seen:
                    seen.add(src)
                    p.images.append(ImageAsset(p.url, src, original_url=src, alt_text=image.get('alt'),
                                               source_strategy='woocommerce_store_api'))
        return p if p.images else None

    def scrape(self, request, result) -> bool:
        limit = request.product_limit
        fetch_cap = limit or 100000
        parsed = urlsplit(request.url)
        base = f'{parsed.scheme}://{parsed.netloc}'
        api = base + '/wp-json/wc/store/v1'
        path_parts = [x for x in parsed.path.split('/') if x]

        # Product detail URL.
        if 'product' in path_parts:
            idx = path_parts.index('product')
            if idx + 1 < len(path_parts):
                slug = path_parts[idx + 1]
                data = self._get_json(api + '/products?' + urlencode({'slug': slug, 'per_page': 100}), result)
                if isinstance(data, list):
                    products = [self._product(x, base) for x in data[:fetch_cap]]
                    products = [x for x in products if x]
                    result.products.extend(products)
                    result.images.extend(i for p in products for i in p.images)
                    return bool(result.images)

        category_id = None
        # Common category URL: /product-category/<slug>/
        for marker in ('product-category', 'product_cat'):
            if marker in path_parts:
                idx = path_parts.index(marker)
                if idx + 1 < len(path_parts):
                    slug = path_parts[idx + 1]
                    cats = self._get_json(api + '/products/categories?' + urlencode({'slug': slug, 'per_page': 100}), result)
                    if isinstance(cats, list) and cats:
                        category_id = cats[0].get('id')
                break

        products = []
        for page in range(1, request.max_pages + 1):
            params = {'per_page': min(100, max(1, limit or 100)), 'page': page}
            if category_id:
                params['category'] = category_id
            data = self._get_json(api + '/products?' + urlencode(params), result)
            if not isinstance(data, list) or not data:
                break
            for raw in data:
                p = self._product(raw, base)
                if p:
                    products.append(p)
                if limit is not None and len(products) >= limit:
                    break
            if (limit is not None and len(products) >= limit) or len(data) < params['per_page']:
                break

        result.products.extend(products if limit is None else products[:limit])
        result.images.extend(i for p in result.products for i in p.images)
        result.stats['woocommerce_store_api'] = bool(result.images)
        return bool(result.images)
