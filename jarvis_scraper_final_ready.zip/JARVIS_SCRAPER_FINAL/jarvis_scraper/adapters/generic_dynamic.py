from .generic_static import GenericStaticAdapter
from ..fetchers.browser_fetcher import BrowserFetcher


class GenericDynamicAdapter(GenericStaticAdapter):
    def browser_fetch_kwargs(self, request):
        return {}

    def fetch_detail(self, url, request):
        """Render public detail pages with the same browser/context used by the job."""
        browser = self.browser or BrowserFetcher(http=self.fetcher)
        html = browser.fetch(url, request.max_scrolls, int(request.delay * 1000), cancel_event=request.cancel_event, **self.browser_fetch_kwargs(request))
        if browser.last_json_payloads:
            import json
            payload_scripts = ''.join(
                '<script type="application/json">' + json.dumps(payload, ensure_ascii=False).replace('</script>', '<\\/script>') + '</script>'
                for payload in browser.last_json_payloads
            )
            html += payload_scripts
        if browser.last_image_candidates:
            import json
            html += '<script id="__JARVIS_BROWSER_MEDIA__" type="application/json">' + json.dumps(
                {'images': browser.last_image_candidates}, ensure_ascii=False
            ).replace('</script>', '<\\/script>') + '</script>'
        return html, browser.last_url or url

    def scrape(self, request, result) -> bool:
        own = self.browser is None
        browser = self.browser or BrowserFetcher(http=self.fetcher)
        # Ensure nested detail fetches reuse the same live browser instance.
        previous = self.browser
        self.browser = browser
        try:
            html = browser.fetch(request.url, request.max_scrolls, int(request.delay * 1000), cancel_event=request.cancel_event, **self.browser_fetch_kwargs(request))
            if browser.last_json_payloads:
                import json
                payload_scripts = ''.join(
                    '<script type="application/json">' + json.dumps(payload, ensure_ascii=False).replace('</script>', '<\\/script>') + '</script>'
                    for payload in browser.last_json_payloads
                )
                html = html + payload_scripts
            if browser.last_image_candidates:
                import json
                html += '<script id="__JARVIS_BROWSER_MEDIA__" type="application/json">' + json.dumps(
                    {'images': browser.last_image_candidates}, ensure_ascii=False
                ).replace('</script>', '<\\/script>') + '</script>'
            ok = self.parse(html, browser.last_url or request.url, request, result)
            result.stats['browser_json_payloads'] = len(browser.last_json_payloads)
            result.stats['browser_image_candidates'] = len(browser.last_image_candidates)
            if browser.last_warning:
                result.warnings.append(browser.last_warning)
            for image in result.images:
                image.source_strategy = 'dynamic'
            return ok
        finally:
            self.browser = previous
            if own:
                browser.close()
