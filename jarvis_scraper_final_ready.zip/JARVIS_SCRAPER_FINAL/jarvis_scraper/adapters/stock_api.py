"""Official stock-photo APIs. Credentials are read from the environment only."""
import json
import os
import time
from hashlib import sha256
from pathlib import Path
from urllib.parse import urlsplit, unquote, parse_qs, urlencode

from .base import BaseAdapter
from ..exceptions import ScrapeError
from ..models import ImageAsset, Status

KEYS = {'pixabay': 'PIXABAY_API_KEY', 'pexels': 'PEXELS_API_KEY', 'unsplash': 'UNSPLASH_ACCESS_KEY'}


class StockAPIAdapter(BaseAdapter):
    provider = ''

    def scrape(self, request, result) -> bool:
        key_name = KEYS[self.provider]
        key = os.getenv(key_name)
        if not key:
            raise ScrapeError(Status.UNSUPPORTED, f'{key_name} is missing; public HTML fallback is available')
        parsed = urlsplit(request.url)
        parts = unquote(parsed.path).strip('/').split('/')
        query = parse_qs(parsed.query).get('q', [''])[0]
        if not query and 'search' in parts and parts.index('search') + 1 < len(parts):
            query = parts[parts.index('search') + 1]
        if not query and 's' in parts and len(parts) > parts.index('s') + 2:
            query = parts[parts.index('s') + 2]
        seen = set()
        limit = request.image_limit
        for page in range(1, request.max_pages + 1):
            headers = {}
            if self.provider == 'pixabay':
                params = {'key': key, 'q': query, 'page': page, 'per_page': min(200, max(3, limit or 200)), 'min_width': request.min_width, 'min_height': request.min_height}
                url = 'https://pixabay.com/api/?' + urlencode(params)
            elif self.provider == 'pexels':
                params = {'page': page, 'per_page': min(80, limit or 80)}
                if query:
                    params['query'] = query
                url = 'https://api.pexels.com/v1/' + ('search' if query else 'curated') + '?' + urlencode(params)
                headers['Authorization'] = key
            else:
                params = {'page': page, 'per_page': min(30, limit or 30)}
                if query:
                    params['query'] = query
                url = 'https://api.unsplash.com/' + ('search/photos' if query else 'photos') + '?' + urlencode(params)
                headers.update(Authorization='Client-ID ' + key, **{'Accept-Version': 'v1'})
            # Pixabay requires 24-hour response caching, scoped to the current output directory.
            cache = Path(request.output) / '.api_cache' / (sha256(url.encode()).hexdigest() + '.json')
            if self.provider == 'pixabay' and cache.exists() and time.time() - cache.stat().st_mtime < 86400:
                data = json.loads(cache.read_text(encoding='utf-8'))
            else:
                data = self.fetcher.get(url, headers=headers).json()
                if self.provider == 'pixabay':
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    cache.write_text(json.dumps(data), encoding='utf-8')
            if self.provider == 'pixabay':
                batch = data.get('hits', [])
            elif self.provider == 'pexels':
                batch = data.get('photos', [])
            else:
                batch = data.get('results', []) if isinstance(data, dict) else data
            for item in batch:
                if self.provider == 'pixabay':
                    image_url = item.get('imageURL') or item.get('fullHDURL') or item.get('largeImageURL')
                    page_url, title = item.get('pageURL'), item.get('tags')
                elif self.provider == 'pexels':
                    image_url = item.get('src', {}).get('original')
                    page_url, title = item.get('url'), item.get('alt')
                else:
                    image_url = item.get('urls', {}).get('full')
                    page_url, title = item.get('links', {}).get('html'), item.get('alt_description')
                    # Provider download tracking is performed only for an actual download request.
                    if not request.dry_run and image_url and image_url not in seen:
                        location = item.get('links', {}).get('download_location')
                        if location:
                            self.fetcher.get(location, headers=headers)
                if image_url and image_url not in seen:
                    seen.add(image_url)
                    result.images.append(ImageAsset(page_url or request.url, image_url,
                        original_url=image_url, title=title, source_strategy=self.provider))
                if limit is not None and len(result.images) >= limit:
                    return True
            if not batch:
                break
        return bool(result.images)
