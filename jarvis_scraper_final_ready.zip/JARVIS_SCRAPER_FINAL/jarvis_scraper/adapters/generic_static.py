from urllib.parse import urlsplit, urljoin
from bs4 import BeautifulSoup
from .base import BaseAdapter
from ..models import Product
from ..extractors.json_ld import extract_jsonld_products
from ..extractors.opengraph import extract_og
from ..extractors.embedded_state import extract_embedded_products, extract_embedded_images
from ..extractors.html_images import extract_images
from ..extractors.product_detector import product_links, gallery_images, product_region_images
from ..extractors.gallery import detail_links, full_image_links, download_page_links
from ..extractors.pagination import next_page, increment_page_url
from ..extractors.svg import extract_svg_assets
from ..extractors.sitemap import parse_sitemap, product_urls as sitemap_product_urls, choose_child_sitemaps
from ..exceptions import check_access, ScrapeError
from ..models import Status


class GenericStaticAdapter(BaseAdapter):
    """Platform-agnostic HTML/structured-data scraper.

    The adapter deliberately discovers product detail pages before falling back to
    a flat gallery. This keeps product/gallery relationships intact across many CMSes.
    """

    def product_page(self, html, url):
        products = extract_jsonld_products(html, url)
        products.extend(extract_embedded_products(html, url))
        gallery = gallery_images(html, url)
        soup = BeautifulSoup(html, 'lxml')
        canonical = soup.select_one('link[rel="canonical"]')
        page_url = urljoin(url, canonical.get('href', url)) if canonical else url

        def identity(value):
            parsed = urlsplit(value)
            return (parsed.hostname, parsed.path.rstrip('/'))

        # De-duplicate structured product representations and keep only the current detail page.
        unique = []
        seen = set()
        for product in products:
            key = str(product.id or product.url or product.name)
            if key in seen:
                continue
            if identity(product.url) not in {identity(url), identity(page_url)} and product.url != url:
                continue
            seen.add(key); unique.append(product)
        products = unique

        commerce = soup.select_one(
            '[itemprop="price"], form[action*="cart"], form[action*="checkout"], button[name="add"], '
            '.single_add_to_cart_button, [data-product-id], [data-price], meta[property="product:price:amount"], '
            '[class*="add-to-cart"], [id*="add-to-cart"]'
        )
        if not products and commerce:
            if not gallery:
                gallery = product_region_images(html, url)
            og = extract_og(html)
            og_image = og.get('og:image') or og.get('twitter:image')
            if og_image:
                from ..models import ImageAsset
                absolute = urljoin(url, og_image)
                if absolute not in {x.image_url for x in gallery}:
                    gallery.append(ImageAsset(page_url, absolute, original_url=absolute, source_strategy='opengraph'))
            if gallery:
                heading = soup.find('h1')
                name = heading.get_text(' ', strip=True) if heading else (og.get('og:title') or 'Product')
                products = [Product(name, page_url, id=page_url)]

        if len(products) == 1:
            if not gallery:
                gallery = product_region_images(html, url)
            seen_images = {image.image_url for image in products[0].images}
            for image in gallery:
                if image.image_url not in seen_images:
                    seen_images.add(image.image_url)
                    products[0].images.append(image)
        return products



    def fetch_detail(self, url, request):
        """Fetch one public detail page. Dynamic adapter overrides this with a browser."""
        response = self.fetcher.get(url, cached=True)
        check_access(response.text, response.url)
        return response.text, response.url

    def _sitemap_product_links(self, base_url, request, result):
        """Bounded fallback when a JS category exposes no product anchors."""
        origin = f"{urlsplit(base_url).scheme}://{urlsplit(base_url).netloc}"
        roots = list(getattr(self.fetcher, 'robots_sitemaps', {}).get(origin, []))
        if not roots:
            roots = [origin + '/sitemap.xml']
        candidates = []
        fetched = 0
        for sitemap_url in roots[:3]:
            try:
                response = self.fetcher.get(sitemap_url, cached=True)
            except ScrapeError:
                continue
            locations, is_index = parse_sitemap(response.content)
            fetched += 1
            if is_index:
                for child in choose_child_sitemaps(locations, limit=3):
                    if fetched >= 4:
                        break
                    try:
                        child_response = self.fetcher.get(child, cached=True)
                    except ScrapeError:
                        continue
                    child_locations, _ = parse_sitemap(child_response.content)
                    fetched += 1
                    candidates.extend(sitemap_product_urls(child_locations, base_url, max(20, request.product_limit * 8) if request.product_limit is not None else 100000))
            else:
                candidates.extend(sitemap_product_urls(locations, base_url, max(20, request.product_limit * 8) if request.product_limit is not None else 100000))
            if candidates or fetched >= 4:
                break
        if candidates:
            result.stats['sitemap_product_candidates'] = len(candidates)
            result.warnings.append('Product links recovered from bounded public sitemap discovery')
        return candidates[:max(20, request.product_limit * 8) if request.product_limit is not None else 100000]

    def _discover_products(self, html, url, request, result):
        products = []
        seen_products = set()
        pages = 0
        current_html, current_url = html, url
        product_limit = request.product_limit
        discovery_budget = max(20, product_limit * 8) if product_limit is not None else 100000

        while pages < request.max_pages and (product_limit is None or len(products) < product_limit) and len(seen_products) < discovery_budget:
            links = product_links(current_html, current_url)
            if not links and pages == 0:
                links = self._sitemap_product_links(current_url, request, result)
            for link in links:
                if link in seen_products:
                    continue
                if len(seen_products) >= discovery_budget or (product_limit is not None and len(products) >= product_limit):
                    break
                seen_products.add(link)
                try:
                    detail_html, detail_url = self.fetch_detail(link, request)
                    found = self.product_page(detail_html, detail_url)
                    if found:
                        products.extend(found)
                except ScrapeError as e:
                    if e.status in {Status.BLOCKED, Status.LOGIN_REQUIRED, Status.RATE_LIMITED, Status.ROBOTS_DISALLOWED}:
                        result.warnings.append(f'Product page skipped: {e.status.value}: {link}')
                        continue
                    raise
            pages += 1
            if product_limit is not None and len(products) >= product_limit:
                break
            nxt = next_page(current_html, current_url)
            if not nxt:
                nxt = increment_page_url(current_url, pages + 1)
            if not nxt or nxt == current_url:
                break
            try:
                response = self.fetcher.get(nxt, cached=True)
                check_access(response.text, response.url)
            except ScrapeError:
                break
            # Avoid endless pagination where the server returns the same document.
            if response.text == current_html:
                break
            current_html, current_url = response.text, response.url

        # Stable de-duplication by id/url.
        out, seen = [], set()
        for p in products:
            key = str(p.id or p.url)
            if p.images and key not in seen:
                seen.add(key); out.append(p)
        if len(seen_products) >= discovery_budget:
            result.warnings.append('Product discovery budget reached')
        result.stats['product_links_visited'] = len(seen_products)
        result.stats['category_pages_visited'] = pages
        return out if product_limit is None else out[:product_limit]

    def parse(self, html, url, request, result) -> bool:
        check_access(html, url)
        direct_products = self.product_page(html, url)
        links = product_links(html, url)

        # A category page may expose JSON-LD cards; still visit detail pages for full galleries.
        is_direct_detail = len(direct_products) == 1 and urlsplit(direct_products[0].url).path.rstrip('/') == urlsplit(url).path.rstrip('/')
        if links and not is_direct_detail:
            products = self._discover_products(html, url, request, result)
        else:
            products_all = [p for p in direct_products if p.images]
            products = products_all if request.product_limit is None else products_all[:request.product_limit]

        if products:
            result.products.extend(products)
            result.images.extend(image for product in products for image in product.images)
            return True

        # Flat gallery mode: first follow published detail/full-image links, then structured JSON, SVG and DOM.
        detailed = []
        for link in detail_links(html, url)[:min(max((request.image_limit or 250) * 2, 10), request.max_pages * 10)]:
            try:
                detail_html, detail_url = self.fetch_detail(link, request)
                # Some catalogues expose the real image one public HTML hop behind
                # a Download Original / resolution link. Prefer that bounded hop.
                nested_assets = []
                for download_page in download_page_links(detail_html, detail_url)[:2]:
                    try:
                        download_html, download_url = self.fetch_detail(download_page, request)
                        nested_assets.extend(full_image_links(download_html, download_url))
                        if nested_assets:
                            break
                    except ScrapeError:
                        continue
                detailed.extend(nested_assets or full_image_links(detail_html, detail_url))
                if request.image_limit is not None and len(detailed) >= request.image_limit:
                    break
            except ScrapeError:
                continue

        soup = BeautifulSoup(html, 'lxml')
        for node in soup.select('nav, header, footer, [role="navigation"], script[type="application/ld+json"]'):
            # JSON-LD has already been handled and often contains social/logo noise in generic gallery mode.
            node.decompose()
        main = soup.select_one('main') or soup
        candidates = extract_embedded_images(html, url)
        # Generic pages are dominated by SVG UI chrome. Enable SVG gallery extraction
        # only for explicitly vector/pattern-oriented sources.
        host = (urlsplit(url).hostname or '').lower()
        if host.endswith('pattern.monster') or '/svg' in urlsplit(url).path.lower():
            candidates.extend(extract_svg_assets(html, url))
        candidates.extend(extract_images(str(main), url, 'static'))
        if not main.select('img, picture, [style*="url("], svg, object[data$=".svg"]') and not candidates:
            candidates = []

        # Detail-page assets are strongest; generic page candidates remain fallback.
        chosen = detailed + candidates
        seen = set()
        for image in chosen:
            if image.image_url not in seen:
                seen.add(image.image_url)
                result.images.append(image)
            if request.image_limit is not None and len(result.images) >= request.image_limit * 10:
                break
        if result.images:
            result.warnings.append('Generic gallery candidates; original resolution and completeness are not guaranteed')
        return bool(result.images)

    def scrape(self, request, result) -> bool:
        response = self.fetcher.get(request.url, cached=True)
        return self.parse(response.text, response.url, request, result)
