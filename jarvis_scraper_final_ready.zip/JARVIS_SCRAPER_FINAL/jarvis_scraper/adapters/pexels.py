import os

from .stock_api import StockAPIAdapter, KEYS
from .generic_dynamic import GenericDynamicAdapter


class PexelsAdapter(StockAPIAdapter):
    """Pexels: official API when configured, otherwise public browser/detail fallback."""
    provider = 'pexels'

    def scrape(self, request, result) -> bool:
        if os.getenv(KEYS[self.provider]):
            return super().scrape(request, result)
        result.warnings.append('PEXELS_API_KEY yok; public browser/detail-page fallback kullanılıyor')
        return GenericDynamicAdapter(self.fetcher, self.browser).scrape(request, result)
