from html import unescape
from urllib.parse import urlsplit, urlencode
from .base import BaseAdapter
from ..models import ImageAsset

class RedditAdapter(BaseAdapter):
    def scrape(self, request, result) -> bool:
        p = urlsplit(request.url)
        endpoint = f'{p.scheme}://{p.netloc}{p.path.rstrip("/")}.json'
        after, seen = None, set()
        for _ in range(request.max_pages):
            limit = request.image_limit
            query = {'limit': min(100, limit or 100), 'raw_json': 1}
            if after:
                query['after'] = after
            data = self.fetcher.get(endpoint + '?' + urlencode(query)).json()['data']
            for entry in data.get('children', []):
                post = entry['data']
                result.stats['posts'] = result.stats.get('posts', 0) + 1
                urls = []
                for item in post.get('gallery_data', {}).get('items', []):
                    media = post.get('media_metadata', {}).get(item['media_id'], {})
                    urls.append(media.get('s', {}).get('u'))
                direct = post.get('url_overridden_by_dest', '')
                if urlsplit(direct).hostname == 'i.redd.it':
                    urls.append(direct)
                for candidate in urls:
                    if not candidate:
                        continue
                    url = unescape(candidate)
                    if url in seen:
                        continue
                    seen.add(url)
                    result.images.append(ImageAsset('https://www.reddit.com' + post['permalink'], url,
                        original_url=url, title=post.get('title'), source_strategy='reddit'))
                    if limit is not None and len(result.images) >= limit:
                        return True
            new_after = data.get('after')
            if not new_after or new_after == after:
                break
            after = new_after
        return bool(result.images)
