from __future__ import annotations

import json
import re
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

from bs4 import BeautifulSoup

from .base import BaseAdapter
from ..exceptions import ScrapeError, check_access
from ..extractors.embedded_state import extract_embedded_images
from ..extractors.html_images import extract_images
from ..models import ImageAsset, Product, Status

_PRODUCT_RE = re.compile(r"-p-(\d+)(?:[/?#]|$)", re.I)


class TrendyolAdapter(BaseAdapter):
    """Trendyol public-page adapter derived from the user's working scraper.

    It keeps the proven ``pi`` pagination, product-card/detail flow and DSM CDN
    ``/mnresize/...`` high-resolution recovery while relying only on the normal
    browser and public page state (no webdriver hiding / anti-bot bypass code).
    """

    @staticmethod
    def _page_url(url: str, page: int) -> str:
        if page <= 1:
            return url
        p = urlsplit(url)
        pairs = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k.lower() != "pi"]
        pairs.append(("pi", str(page)))
        return urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), ""))

    def _browser_html(self, url: str, request) -> tuple[str, str]:
        if not self.browser:
            raise ScrapeError(Status.UNSUPPORTED, "Trendyol adapter requires the normal Playwright browser fallback")
        html = self.browser.fetch(url, request.max_scrolls, int(request.delay * 1000), cancel_event=request.cancel_event)
        if self.browser.last_json_payloads:
            html += "".join(
                '<script type="application/json">' + json.dumps(payload, ensure_ascii=False).replace("</script>", "<\\/script>") + "</script>"
                for payload in self.browser.last_json_payloads
            )
        if self.browser.last_image_candidates:
            html += '<script id="__JARVIS_BROWSER_MEDIA__" type="application/json">' + json.dumps(
                {"images": self.browser.last_image_candidates}, ensure_ascii=False
            ).replace("</script>", "<\\/script>") + "</script>"
        final_url = self.browser.last_url or url
        check_access(html, final_url)
        return html, final_url

    @staticmethod
    def _product_links(html: str, base_url: str) -> list[tuple[str, str | None, str | None]]:
        soup = BeautifulSoup(html, "lxml")
        out: list[tuple[str, str | None, str | None]] = []
        seen: set[str] = set()
        selectors = (
            "a.product-card[href]", "a[data-testid='product-card'][href]", ".p-card-wrppr a[href]",
            ".prdct-cntnr-wrppr a[href]", "a[href*='-p-']"
        )
        for selector in selectors:
            for anchor in soup.select(selector):
                href = anchor.get("href") or ""
                url = urljoin(base_url, href).split("#", 1)[0]
                m = _PRODUCT_RE.search(url)
                if not m or url in seen:
                    continue
                seen.add(url)
                brand = anchor.select_one(".product-brand")
                name = anchor.select_one(".product-name")
                title = " ".join(x for x in [brand.get_text(" ", strip=True) if brand else "", name.get_text(" ", strip=True) if name else ""] if x).strip()
                if not title:
                    title = anchor.get("title") or anchor.get("aria-label") or anchor.get_text(" ", strip=True) or None
                out.append((url, title, m.group(1)))
        return out

    @staticmethod
    def _detail_product(html: str, url: str, hinted_name: str | None = None, product_id: str | None = None) -> Product | None:
        soup = BeautifulSoup(html, "lxml")
        m = _PRODUCT_RE.search(url)
        product_id = product_id or (m.group(1) if m else None)
        h1 = soup.find("h1")
        title = hinted_name or (h1.get_text(" ", strip=True) if h1 else None)
        if not title:
            og = soup.select_one('meta[property="og:title"]')
            title = og.get("content") if og else None
        title = title or f"Trendyol Product {product_id or ''}".strip()

        description_parts = [p.get_text(" ", strip=True) for p in soup.select("p.product-description-content") if p.get_text(" ", strip=True)]
        description = " | ".join(description_parts) or None

        regions = soup.select(
            "[class*='carousel'], [class*='_carouselImage_'], [class*='carouselThumb'], "
            "[data-testid*='carousel'], [data-testid*='gallery'], [class*='gallery'], "
            ".product-detail-image-container, .product-images, .product-image-gallery"
        )
        assets: list[ImageAsset] = []
        seen: set[str] = set()
        for region in regions:
            for image in extract_images(str(region), url, "trendyol"):
                host = (urlsplit(image.image_url).hostname or "").lower()
                low = image.image_url.lower()
                if host.endswith("dsmcdn.com") or ("product" in low and "media" in low):
                    if image.image_url not in seen:
                        seen.add(image.image_url)
                        image.source_strategy = "trendyol"
                        assets.append(image)

        for image in extract_embedded_images(html, url):
            host = (urlsplit(image.image_url).hostname or "").lower()
            low = image.image_url.lower()
            if (host.endswith("dsmcdn.com") or ("product" in low and "media" in low)) and image.image_url not in seen:
                seen.add(image.image_url)
                image.source_strategy = "trendyol"
                assets.append(image)

        # Exact old-scraper fallback: if the carousel was not recognized, keep DSM
        # product/media images but never generic page chrome.
        if not assets:
            for img in soup.find_all(["img", "source"]):
                raw = " ".join(str(img.get(k) or "") for k in ("src", "data-src", "srcset", "data-srcset"))
                if not raw:
                    continue
                low = raw.lower()
                if "dsmcdn.com" not in low and not ("product" in low and "media" in low):
                    continue
                for image in extract_images(str(img), url, "trendyol"):
                    if image.image_url not in seen:
                        seen.add(image.image_url); assets.append(image)

        if not assets:
            return None
        return Product(
            name=title,
            url=url,
            id=product_id or url,
            slug=(urlsplit(url).path.rstrip("/").split("/")[-1] or product_id),
            description=description,
            images=assets,
            metadata={"marketplace": "trendyol", "product_id": product_id},
        )

    def scrape(self, request, result) -> bool:
        if _PRODUCT_RE.search(request.url):
            candidates = [(request.url, None, None)]
        else:
            candidates: list[tuple[str, str | None, str | None]] = []
            seen: set[str] = set()
            limit = request.product_limit
            for page in range(1, request.max_pages + 1):
                html, final_url = self._browser_html(self._page_url(request.url, page), request)
                batch = self._product_links(html, final_url)
                new = 0
                for row in batch:
                    if row[0] not in seen:
                        seen.add(row[0]); candidates.append(row); new += 1
                        if limit is not None and len(candidates) >= limit:
                            break
                if (limit is not None and len(candidates) >= limit) or not batch or new == 0:
                    break

        result.stats["trendyol_product_candidates"] = len(candidates)
        selected_candidates = candidates if request.product_limit is None else candidates[:request.product_limit]
        for detail_url, title, product_id in selected_candidates:
            try:
                html, final_url = self._browser_html(detail_url, request)
                product = self._detail_product(html, final_url, title, product_id)
                if product:
                    result.products.append(product)
                    result.images.extend(product.images)
            except ScrapeError as exc:
                if exc.status in {Status.BLOCKED, Status.LOGIN_REQUIRED, Status.RATE_LIMITED, Status.ROBOTS_DISALLOWED}:
                    result.warnings.append(f"Trendyol product skipped: {exc.status.value}: {detail_url}")
                    continue
                raise
        return bool(result.images)
