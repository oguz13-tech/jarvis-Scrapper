from urllib.parse import urlsplit
from .generic_dynamic import GenericDynamicAdapter
from ..extractors.html_images import extract_images
from ..exceptions import check_access, ScrapeError
from ..models import Status

class PinterestAdapter(GenericDynamicAdapter):
    def browser_fetch_kwargs(self, request):
        # Close only user-dismissible public-page dialogs. A real login wall is
        # still reported as LOGIN_REQUIRED by the browser/access checks.
        return {'dismiss_public_modals': True}

    def scrape(self, request, result) -> bool:
        response = self.fetcher.get(request.url, cached=True)
        check_access(response.text, response.url)
        images = [x for x in extract_images(response.text, response.url, 'pinterest')
                  if (urlsplit(x.image_url).hostname or '').endswith('.pinimg.com')]
        if images:
            result.images.extend(images if request.image_limit is None else images[:request.image_limit])
            result.warnings.append('Pinterest: only public candidates, board completeness is not guaranteed')
            return True
        if 'login' in response.text.lower() and 'password' in response.text.lower():
            raise ScrapeError(Status.LOGIN_REQUIRED, 'Pinterest login wall has no public image candidates')
        return super().scrape(request, result)
