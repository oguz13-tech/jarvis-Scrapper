import os
from urllib.parse import urlsplit, parse_qs, urlencode
from .base import BaseAdapter
from ..models import ImageAsset

class WallhavenAdapter(BaseAdapter):
    def scrape(self, request, result) -> bool:
        query = {k: v[0] for k, v in parse_qs(urlsplit(request.url).query).items()
                 if k in {'q', 'categories', 'purity', 'sorting', 'order', 'atleast', 'ratios', 'colors', 'seed'}}
        query.setdefault('purity', '100')
        if os.getenv('WALLHAVEN_API_KEY'):
            query['apikey'] = os.environ['WALLHAVEN_API_KEY']
        seen = set()
        for page in range(1, request.max_pages + 1):
            query['page'] = page
            data = self.fetcher.get('https://wallhaven.cc/api/v1/search?' + urlencode(query)).json()
            batch = data.get('data', [])
            for item in batch:
                if item.get('path') and item['path'] not in seen:
                    seen.add(item['path'])
                    result.images.append(ImageAsset(item['url'], item['path'], original_url=item['path'],
                        title=item.get('id'), width=item.get('dimension_x'), height=item.get('dimension_y'),
                        source_strategy='official_api'))
                    result.stats.setdefault('wallpapers', []).append({k: item.get(k) for k in
                        ('id', 'url', 'path', 'resolution', 'category', 'purity')})
                if request.image_limit is not None and len(result.images) >= request.image_limit:
                    return True
            if not batch or page >= data.get('meta', {}).get('last_page', page):
                break
        return bool(result.images)
