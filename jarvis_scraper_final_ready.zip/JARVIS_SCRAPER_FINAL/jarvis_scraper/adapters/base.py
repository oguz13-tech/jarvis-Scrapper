from abc import ABC, abstractmethod
from ..fetchers.http_fetcher import HttpFetcher

class BaseAdapter(ABC):
    def __init__(self, fetcher=None, browser=None):
        self.fetcher = fetcher or HttpFetcher()
        self.browser = browser

    @abstractmethod
    def scrape(self, request, result) -> bool:
        ...
