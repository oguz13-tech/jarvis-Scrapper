from urllib.parse import urlsplit, urljoin
from .base import BaseAdapter
from ..models import Product, ImageAsset
from ..exceptions import ScrapeError
from ..models import Status
from ..extractors.product_detector import gallery_images
from ..exceptions import check_access

class ShopifyAdapter(BaseAdapter):
    def scrape(self, request, result) -> bool:
        p = urlsplit(request.url)
        base = f'{p.scheme}://{p.netloc}'
        parts = p.path.strip('/').split('/')
        endpoint = base + '/products.json'
        if 'collections' in parts:
            i = parts.index('collections')
            if i + 1 < len(parts):
                handle = parts[i + 1]
                endpoint = f'{base}/collections/{handle}/products.json'
                result.stats['collection'] = handle
        single = 'products' in parts
        if single:
            endpoint = base + p.path.rstrip('/') + '.json'
        seen, products = set(), []
        limit = request.product_limit
        for page in range(1, request.max_pages + 1):
            url = endpoint if single else f'{endpoint}?limit=250&page={page}'
            try:
                data = self.fetcher.get(url).json()
            except ScrapeError as e:
                result.warnings.append(f'Shopify JSON endpoint unavailable: {e.status.value}: {url}')
                return False
            except ValueError as e:
                result.warnings.append(f'Invalid Shopify JSON endpoint; falling back to storefront HTML: {url}')
                return False
            if not isinstance(data, dict) or ('products' not in data and 'product' not in data):
                raise ScrapeError(Status.PARSER_ERROR, f'Not a Shopify product response: {url}')
            batch = [data['product']] if single else data['products']
            added = 0
            for x in batch:
                key = str(x.get('id') or x.get('handle'))
                if key in seen:
                    continue
                seen.add(key)
                added += 1
                prod = Product(name=x.get('title') or 'Unnamed',
                    url=f"{base}/products/{x.get('handle', '')}", id=key,
                    slug=x.get('handle'), vendor=x.get('vendor'), product_type=x.get('product_type'),
                    sku=next((v.get('sku') for v in x.get('variants', []) if v.get('sku')), None),
                    description=x.get('body_html'), metadata=x)
                for im in x.get('images', []):
                    if im.get('src'):
                        src = urljoin(base, im['src'])
                        prod.images.append(ImageAsset(prod.url, src, original_url=src,
                            width=im.get('width'), height=im.get('height'), source_strategy='shopify'))
                if prod.images:
                    products.append(prod)
                if limit is not None and len(products) >= limit:
                    break
            result.stats['pages_fetched'] = page
            if single or (limit is not None and len(products) >= limit) or not added or len(batch) < 250:
                break
        selected_products = products if limit is None else products[:limit]
        for product in selected_products:
            try:
                response = self.fetcher.get(product.url)
            except ScrapeError as e:
                result.warnings.append(f'Shopify product gallery page skipped: {e.status.value}: {product.url}')
                continue
            if hasattr(response, 'text'):
                check_access(response.text, product.url)
                extra = gallery_images(response.text, product.url)
                known = {image.image_url for image in product.images}
                original_files = {urlsplit(image.image_url).path.rsplit('/', 1)[-1]
                                  for image in product.images}
                for image in extra:
                    parsed = urlsplit(image.image_url)
                    if ('/cdn/shop/files/' in parsed.path or parsed.hostname == 'cdn.shopify.com') and parsed.path.rsplit('/', 1)[-1] in original_files:
                        continue
                    if image.image_url not in known:
                        known.add(image.image_url)
                        product.images.append(image)
        result.products.extend(selected_products)
        result.images.extend(im for product in selected_products for im in product.images)
        return bool(result.images)
