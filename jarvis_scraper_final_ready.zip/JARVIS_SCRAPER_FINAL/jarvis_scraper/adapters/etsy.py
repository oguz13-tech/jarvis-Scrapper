from __future__ import annotations

import json
import re
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit

from bs4 import BeautifulSoup

from .base import BaseAdapter
from ..exceptions import ScrapeError, check_access
from ..extractors.embedded_state import extract_embedded_images
from ..extractors.html_images import extract_images
from ..models import ImageAsset, Product, Status

_LISTING_RE = re.compile(r"/listing/(\d+)(?:/[^?#]*)?", re.I)


class EtsyAdapter(BaseAdapter):
    """Etsy public-page adapter based on the user's previously working scraper.

    The important behavior is preserved without stealth/browser fingerprint hiding:
    listing/shop/search page -> listing detail page -> complete published image gallery.
    The downloader later expands Etsy CDN variants to ``il_fullxfull`` and validates
    the actual bytes before accepting a file.
    """

    @staticmethod
    def _page_url(url: str, page: int) -> str:
        if page <= 1:
            return url
        p = urlsplit(url)
        pairs = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if k.lower() != "page"]
        pairs.append(("page", str(page)))
        return urlunsplit((p.scheme, p.netloc, p.path, urlencode(pairs), ""))

    def _browser_html(self, url: str, request) -> tuple[str, str]:
        if not self.browser:
            raise ScrapeError(Status.UNSUPPORTED, "Etsy adapter requires the normal Playwright browser fallback")
        html = self.browser.fetch(url, request.max_scrolls, int(request.delay * 1000), cancel_event=request.cancel_event)
        # Reuse the same public app-state/media capture already used by the generic dynamic adapter.
        if self.browser.last_json_payloads:
            html += "".join(
                '<script type="application/json">' + json.dumps(payload, ensure_ascii=False).replace("</script>", "<\\/script>") + "</script>"
                for payload in self.browser.last_json_payloads
            )
        if self.browser.last_image_candidates:
            html += '<script id="__JARVIS_BROWSER_MEDIA__" type="application/json">' + json.dumps(
                {"images": self.browser.last_image_candidates}, ensure_ascii=False
            ).replace("</script>", "<\\/script>") + "</script>"
        final_url = self.browser.last_url or url
        check_access(html, final_url)
        return html, final_url

    @staticmethod
    def _listing_links(html: str, base_url: str) -> list[tuple[str, str | None, str | None]]:
        soup = BeautifulSoup(html, "lxml")
        out: list[tuple[str, str | None, str | None]] = []
        seen: set[str] = set()

        # Exact selectors from the user's previously working Etsy scraper.
        for card in soup.select("div[data-listing-id], [data-listing-id]"):
            listing_id = card.get("data-listing-id")
            anchor = card.select_one("a[data-listing-link][href], a[href*='/listing/']")
            href = anchor.get("href") if anchor else None
            if not href and listing_id:
                href = f"https://www.etsy.com/listing/{listing_id}"
            if not href:
                continue
            url = urljoin(base_url, href).split("#", 1)[0]
            m = _LISTING_RE.search(urlsplit(url).path)
            if not m or url in seen:
                continue
            seen.add(url)
            title_input = card.select_one("input[name='listing_title']")
            title = title_input.get("value") if title_input else None
            if not title and anchor:
                title = anchor.get("aria-label") or anchor.get("title") or anchor.get_text(" ", strip=True)
            out.append((url, title or None, m.group(1)))

        # Current Etsy markup can move the data-listing-id onto another wrapper;
        # accept strong /listing/<id> anchors as a bounded fallback.
        for anchor in soup.select("a[href*='/listing/']"):
            href = anchor.get("href") or ""
            url = urljoin(base_url, href).split("#", 1)[0]
            m = _LISTING_RE.search(urlsplit(url).path)
            if not m or url in seen:
                continue
            seen.add(url)
            out.append((url, anchor.get("aria-label") or anchor.get("title") or anchor.get_text(" ", strip=True) or None, m.group(1)))
        return out

    @staticmethod
    def _detail_product(html: str, url: str, hinted_name: str | None = None, listing_id: str | None = None) -> Product | None:
        soup = BeautifulSoup(html, "lxml")
        m = _LISTING_RE.search(urlsplit(url).path)
        listing_id = listing_id or (m.group(1) if m else None)

        title = hinted_name
        if not title:
            h1 = soup.find("h1")
            title = h1.get_text(" ", strip=True) if h1 else None
        if not title:
            og = soup.select_one('meta[property="og:title"]')
            title = og.get("content") if og else None
        title = title or f"Etsy Listing {listing_id or ''}".strip()

        description = None
        for selector in (
            "[data-product-details-description-text-content]",
            "#product-details-content-toggle-product-details-read-more-content",
            "[data-id='description-text']",
            "meta[property='og:description']",
        ):
            node = soup.select_one(selector)
            if node:
                description = node.get("content") if node.name == "meta" else node.get_text(" ", strip=True)
                if description:
                    break

        regions = soup.select(
            "[data-component='listing-page-image-carousel'], "
            "[data-testid*='listing-page-image'], [data-testid*='image-carousel'], "
            "[data-listing-page-image], [class*='carousel'], [class*='gallery']"
        )
        assets: list[ImageAsset] = []
        seen: set[str] = set()
        for region in regions:
            for image in extract_images(str(region), url, "etsy"):
                # Etsy listing photography is served from its image CDN. Restrict the
                # marketplace adapter to that CDN so carousel chrome/recommendations
                # never become product photos.
                if not (urlsplit(image.image_url).hostname or "").lower().endswith("etsystatic.com"):
                    continue
                if image.image_url not in seen:
                    seen.add(image.image_url)
                    image.source_strategy = "etsy"
                    assets.append(image)

        # Structured/app-state fallback catches current Etsy variants where the
        # carousel DOM only contains placeholders.
        for image in extract_embedded_images(html, url):
            host = (urlsplit(image.image_url).hostname or "").lower()
            if host.endswith("etsystatic.com") and image.image_url not in seen:
                seen.add(image.image_url)
                image.source_strategy = "etsy"
                assets.append(image)

        # Last-resort Etsy CDN scan. Do not accept arbitrary page chrome.
        if not assets:
            for img in soup.select("img[src], img[data-src], img[srcset], source[srcset]"):
                raw = " ".join(str(img.get(k) or "") for k in ("src", "data-src", "srcset", "data-srcset"))
                if "etsystatic.com" not in raw:
                    continue
                for image in extract_images(str(img), url, "etsy"):
                    if image.image_url not in seen:
                        seen.add(image.image_url)
                        assets.append(image)

        if not assets:
            return None
        return Product(
            name=title,
            url=url,
            id=listing_id or url,
            slug=(urlsplit(url).path.rstrip("/").split("/")[-1] or listing_id),
            description=description,
            images=assets,
            metadata={"marketplace": "etsy", "listing_id": listing_id},
        )

    def scrape(self, request, result) -> bool:
        direct = bool(_LISTING_RE.search(urlsplit(request.url).path))
        candidates: list[tuple[str, str | None, str | None]] = []

        if direct:
            candidates = [(request.url, None, None)]
        else:
            seen: set[str] = set()
            limit = request.product_limit
            for page in range(1, request.max_pages + 1):
                page_url = self._page_url(request.url, page)
                html, final_url = self._browser_html(page_url, request)
                batch = self._listing_links(html, final_url)
                new = 0
                for row in batch:
                    if row[0] not in seen:
                        seen.add(row[0]); candidates.append(row); new += 1
                        if limit is not None and len(candidates) >= limit:
                            break
                if (limit is not None and len(candidates) >= limit) or not batch or new == 0:
                    break

        result.stats["etsy_listing_candidates"] = len(candidates)
        selected_candidates = candidates if request.product_limit is None else candidates[:request.product_limit]
        for detail_url, title, listing_id in selected_candidates:
            try:
                html, final_url = self._browser_html(detail_url, request)
                product = self._detail_product(html, final_url, title, listing_id)
                if product:
                    result.products.append(product)
                    result.images.extend(product.images)
            except ScrapeError as exc:
                if exc.status in {Status.BLOCKED, Status.LOGIN_REQUIRED, Status.RATE_LIMITED, Status.ROBOTS_DISALLOWED}:
                    result.warnings.append(f"Etsy listing skipped: {exc.status.value}: {detail_url}")
                    continue
                raise

        return bool(result.images)
