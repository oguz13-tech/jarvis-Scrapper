from __future__ import annotations

import csv
import json
import logging
import os
import queue
import subprocess
import threading
import time
import tkinter as tk
from datetime import datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from .engine import Engine
from .models import ScrapeRequest

_API_KEYS = (
    ('PIXABAY_API_KEY', 'Pixabay API Key'),
    ('PEXELS_API_KEY', 'Pexels API Key'),
    ('UNSPLASH_ACCESS_KEY', 'Unsplash Access Key'),
    ('WALLHAVEN_API_KEY', 'Wallhaven API Key (opsiyonel)'),
)


class _QueueLogHandler(logging.Handler):
    def __init__(self, events: queue.Queue, file_handler: logging.Handler | None = None):
        super().__init__(logging.DEBUG)
        self.events = events
        self.file_handler = file_handler
        self.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s | %(message)s', '%H:%M:%S'))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            text = self.format(record)
            self.events.put(('log', text))
            if self.file_handler is not None:
                self.file_handler.emit(record)
        except Exception:
            return


class ScraperGUI(tk.Tk):
    """Operator UI with live observability, stop/resume and crash-safe state."""

    def __init__(self):
        super().__init__()
        self.title('JARVIS Scraper')
        self.geometry('1020x820')
        self.minsize(860, 650)
        self.events: queue.Queue = queue.Queue()
        self.running = False
        self.cancel_event = threading.Event()
        self.worker_thread: threading.Thread | None = None
        self.project_root = Path.cwd()
        self.last_activity = time.monotonic()
        self.started_monotonic: float | None = None
        self.session_rows: list[dict] = []
        self.current_urls: list[str] = []
        self.current_index = 0
        self.current_config: dict = {}
        self.session_log_path: Path | None = None
        self._log_visible = False
        self._build()
        self.protocol('WM_DELETE_WINDOW', self._on_close)
        self.after(150, self._drain_events)
        self.after(1000, self._heartbeat)
        self.after(600, self._offer_resume)

    def _build(self):
        root = ttk.Frame(self, padding=16)
        root.pack(fill='both', expand=True)

        ttk.Label(root, text='JARVIS SCRAPER', font=('Segoe UI', 18, 'bold')).pack(anchor='w')
        ttk.Label(
            root,
            text='Tek link veya alt alta birden fazla link yapıştır. Ürün sitelerinde ürün detaylarına, '
                 'galeri/stock sitelerinde içerik detaylarına gidilir; büyük/orijinal yayımlanmış görsel önceliklendirilir.',
            wraplength=940,
        ).pack(anchor='w', pady=(2, 10))

        self.urls = tk.Text(root, height=8, wrap='word')
        self.urls.pack(fill='x')

        opts = ttk.LabelFrame(root, text='Kazıma Ayarları', padding=10)
        opts.pack(fill='x', pady=10)
        ttk.Label(opts, text='Çıktı klasörü:').grid(row=0, column=0, sticky='w')
        self.output = tk.StringVar(value=str(Path.cwd() / 'output'))
        ttk.Entry(opts, textvariable=self.output).grid(row=0, column=1, columnspan=4, sticky='ew', padx=6)
        ttk.Button(opts, text='Seç', command=self._choose_output).grid(row=0, column=5)
        opts.columnconfigure(1, weight=1)

        ttk.Label(opts, text='E-ticaret ürün limiti:').grid(row=1, column=0, sticky='w', pady=(8, 0))
        self.product_limit = tk.StringVar(value='')
        ttk.Entry(opts, textvariable=self.product_limit, width=10).grid(row=1, column=1, sticky='w', padx=6, pady=(8, 0))
        ttk.Label(opts, text='boş = TÜMÜ').grid(row=1, column=2, sticky='w', pady=(8, 0))

        ttk.Label(opts, text='Galeri/görsel limiti:').grid(row=2, column=0, sticky='w', pady=(6, 0))
        self.image_limit = tk.StringVar(value='')
        ttk.Entry(opts, textvariable=self.image_limit, width=10).grid(row=2, column=1, sticky='w', padx=6, pady=(6, 0))
        ttk.Label(opts, text='boş = TÜMÜ').grid(row=2, column=2, sticky='w', pady=(6, 0))

        ttk.Label(opts, text='Min. genişlik:').grid(row=1, column=3, sticky='e', pady=(8, 0))
        self.min_width = tk.IntVar(value=400)
        ttk.Spinbox(opts, from_=1, to=20000, textvariable=self.min_width, width=8).grid(row=1, column=4, sticky='w', padx=6, pady=(8, 0))
        ttk.Label(opts, text='Min. yükseklik:').grid(row=1, column=5, sticky='e', pady=(8, 0))
        self.min_height = tk.IntVar(value=400)
        ttk.Spinbox(opts, from_=1, to=20000, textvariable=self.min_height, width=8).grid(row=1, column=6, sticky='w', pady=(8, 0))

        self.group_products = tk.BooleanVar(value=True)
        ttk.Checkbutton(opts, text='Ürün başına klasör oluştur', variable=self.group_products).grid(row=3, column=0, columnspan=2, sticky='w', pady=(8, 0))
        self.respect_robots = tk.BooleanVar(value=True)
        ttk.Checkbutton(opts, text='robots.txt politikasına uy', variable=self.respect_robots).grid(row=3, column=2, columnspan=2, sticky='w', pady=(8, 0))
        ttk.Label(opts, text='✓ Thumbnail/logo/ikon final sonuç sayılmaz').grid(row=3, column=4, columnspan=3, sticky='w', pady=(8, 0))

        buttons = ttk.Frame(root)
        buttons.pack(fill='x', pady=(0, 8))
        self.start = ttk.Button(buttons, text='KAZIMAYI BAŞLAT', command=self._start)
        self.start.pack(side='left', fill='x', expand=True, ipady=8)
        self.stop = ttk.Button(buttons, text='DURDUR', command=self._stop, state='disabled')
        self.stop.pack(side='left', padx=(8, 0), ipady=8)
        ttk.Button(buttons, text='API Ayarları', command=self._api_settings).pack(side='left', padx=(8, 0), ipady=8)
        ttk.Button(buttons, text='Çıktıyı Aç', command=self._open_output).pack(side='left', padx=(8, 0), ipady=8)

        status = ttk.LabelFrame(root, text='Canlı Durum', padding=8)
        status.pack(fill='x', pady=(0, 8))
        self.status_text = tk.StringVar(value='Hazır')
        self.detail_text = tk.StringVar(value='Aktif iş yok.')
        ttk.Label(status, textvariable=self.status_text, font=('Segoe UI', 10, 'bold')).pack(anchor='w')
        ttk.Label(status, textvariable=self.detail_text).pack(anchor='w', pady=(2, 0))
        self.progress = ttk.Progressbar(status, mode='determinate')
        self.progress.pack(fill='x', pady=(6, 0))

        log_buttons = ttk.Frame(root)
        log_buttons.pack(fill='x')
        self.log_toggle = ttk.Button(log_buttons, text='CANLI LOGU GÖSTER', command=self._toggle_log)
        self.log_toggle.pack(side='left')
        ttk.Button(log_buttons, text='Logu Kopyala', command=self._copy_log).pack(side='left', padx=(8, 0))
        ttk.Button(log_buttons, text='Log Dosyasını Aç', command=self._open_log).pack(side='left', padx=(8, 0))

        self.log_frame = ttk.LabelFrame(root, text='Canlı Teknik Log', padding=6)
        self.log = tk.Text(self.log_frame, height=18, wrap='word', state='disabled')
        scroll = ttk.Scrollbar(self.log_frame, orient='vertical', command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.pack(side='left', fill='both', expand=True)
        scroll.pack(side='right', fill='y')

    @staticmethod
    def _parse_optional_limit(value: str, label: str) -> int | None:
        value = value.strip()
        if not value:
            return None
        try:
            number = int(value)
        except ValueError as exc:
            raise ValueError(f'{label} sayı olmalı veya boş bırakılmalı.') from exc
        if number < 1:
            raise ValueError(f'{label} en az 1 olmalı veya boş bırakılmalı.')
        return number

    def _choose_output(self):
        chosen = filedialog.askdirectory(initialdir=self.output.get() or str(Path.cwd()))
        if chosen:
            self.output.set(chosen)

    def _open_output(self):
        path = Path(self.output.get()).expanduser()
        path.mkdir(parents=True, exist_ok=True)
        self._open_path(path)

    @staticmethod
    def _open_path(path: Path):
        try:
            os.startfile(path)  # type: ignore[attr-defined]
        except AttributeError:
            subprocess.Popen(['xdg-open', str(path)])

    def _open_log(self):
        if self.session_log_path and self.session_log_path.exists():
            self._open_path(self.session_log_path)
        else:
            messagebox.showinfo('JARVIS Scraper', 'Henüz bu oturuma ait log dosyası yok.')

    def _api_settings(self):
        win = tk.Toplevel(self)
        win.title('API Ayarları')
        win.resizable(False, False)
        frame = ttk.Frame(win, padding=14)
        frame.pack(fill='both', expand=True)
        ttk.Label(frame, text='Opsiyonel resmi API anahtarları', font=('Segoe UI', 11, 'bold')).grid(row=0, column=0, columnspan=2, sticky='w')
        ttk.Label(frame, text='Anahtar yoksa public HTML/browser fallback denenir. Erişim kontrolleri aşılmaz.', wraplength=520).grid(row=1, column=0, columnspan=2, sticky='w', pady=(2, 10))
        vars_: dict[str, tk.StringVar] = {}
        for row, (key, label) in enumerate(_API_KEYS, start=2):
            ttk.Label(frame, text=label + ':').grid(row=row, column=0, sticky='w', pady=4)
            var = tk.StringVar(value=os.getenv(key, ''))
            vars_[key] = var
            ttk.Entry(frame, textvariable=var, show='•', width=50).grid(row=row, column=1, padx=(8, 0), pady=4)

        def save():
            env_path = self.project_root / '.env'
            existing: dict[str, str] = {}
            if env_path.exists():
                for line in env_path.read_text(encoding='utf-8').splitlines():
                    if '=' in line and not line.lstrip().startswith('#'):
                        k, v = line.split('=', 1)
                        existing[k.strip()] = v.strip()
            for key, var in vars_.items():
                value = var.get().strip()
                existing[key] = value
                if value:
                    os.environ[key] = value
                else:
                    os.environ.pop(key, None)
            self._atomic_text(env_path, '\n'.join(f'{k}={v}' for k, v in existing.items()) + '\n')
            messagebox.showinfo('JARVIS Scraper', 'API ayarları kaydedildi.')
            win.destroy()

        ttk.Button(frame, text='Kaydet', command=save).grid(row=2 + len(_API_KEYS), column=0, columnspan=2, sticky='ew', pady=(10, 0))

    def _toggle_log(self):
        self._log_visible = not self._log_visible
        if self._log_visible:
            self.log_frame.pack(fill='both', expand=True, pady=(6, 0))
            self.log_toggle.configure(text='CANLI LOGU GİZLE')
        else:
            self.log_frame.pack_forget()
            self.log_toggle.configure(text='CANLI LOGU GÖSTER')

    def _copy_log(self):
        text = self.log.get('1.0', 'end').strip()
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update_idletasks()

    def _write(self, text: str):
        self.last_activity = time.monotonic()
        self.log.configure(state='normal')
        self.log.insert('end', text + '\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def _event_callback(self, event: str, message: str, data: dict):
        self.events.put(('engine_event', (event, message, data)))

    def _capture_config(self) -> dict:
        return {
            'output': self.output.get(),
            'product_limit': self._parse_optional_limit(self.product_limit.get(), 'Ürün limiti'),
            'image_limit': self._parse_optional_limit(self.image_limit.get(), 'Görsel limiti'),
            'min_width': max(1, int(self.min_width.get())),
            'min_height': max(1, int(self.min_height.get())),
            'respect_robots': bool(self.respect_robots.get()),
            'group_products': bool(self.group_products.get()),
        }

    def _start(self, resume_index: int = 0):
        if self.running:
            return
        urls = list(dict.fromkeys(line.strip() for line in self.urls.get('1.0', 'end').splitlines() if line.strip()))
        if not urls:
            messagebox.showwarning('JARVIS Scraper', 'En az bir URL gir.')
            return
        try:
            config = self._capture_config()
        except (ValueError, tk.TclError) as exc:
            messagebox.showwarning('JARVIS Scraper', str(exc))
            return

        self.current_urls = urls
        self.current_config = config
        self.current_index = max(0, min(resume_index, len(urls)))
        self.session_rows = self._load_existing_summary(Path(config['output'])) if self.current_index else []
        self.cancel_event = threading.Event()
        self.running = True
        self.started_monotonic = time.monotonic()
        self.last_activity = self.started_monotonic
        self.start.configure(state='disabled')
        self.stop.configure(state='normal')
        self.progress.configure(maximum=len(urls), value=self.current_index)
        self.status_text.set('ÇALIŞIYOR')
        self.detail_text.set(f'{self.current_index}/{len(urls)} URL tamamlandı')
        self._setup_session_log(Path(config['output']))
        self._write(f'{len(urls)} link sıraya alındı. Ürün limiti={config["product_limit"] or "TÜMÜ"}, görsel limiti={config["image_limit"] or "TÜMÜ"}.')
        self._save_session_state('running')
        try:
            self._atomic_text(self.project_root / '.jarvis_last_session.json', json.dumps({'output': config['output']}, ensure_ascii=False))
        except Exception:
            pass
        self.worker_thread = threading.Thread(target=self._worker, args=(urls, config, self.current_index), daemon=True)
        self.worker_thread.start()

    def _stop(self):
        if not self.running:
            return
        self.cancel_event.set()
        self.stop.configure(state='disabled')
        self.status_text.set('DURDURULUYOR…')
        self._write('Durdurma istendi. Güvenli noktada checkpoint alınarak işlem sonlandırılıyor…')
        self._save_session_state('stopping')

    def _worker(self, urls: list[str], config: dict, start_index: int):
        out = Path(config['output']).expanduser()
        for zero_index in range(start_index, len(urls)):
            if self.cancel_event.is_set():
                break
            index = zero_index + 1
            url = urls[zero_index]
            self.current_index = zero_index
            self.events.put(('log', f'[{index}/{len(urls)}] {url}'))
            self.events.put(('status', f'Aktif URL {index}/{len(urls)}: {url}'))
            self._save_session_state('running')
            try:
                result = Engine().run(ScrapeRequest(
                    url=url,
                    output=config['output'],
                    max_items=0,
                    max_products=config['product_limit'],
                    max_images=config['image_limit'],
                    min_width=config['min_width'],
                    min_height=config['min_height'],
                    strategy='auto',
                    resume=True,
                    respect_robots=config['respect_robots'],
                    group_products=config['group_products'],
                    cancel_event=self.cancel_event,
                    event_callback=self._event_callback,
                ))
                downloaded = result.stats.get('images_downloaded', 0)
                rejected = result.stats.get('images_rejected', 0)
                row = {
                    'url': url, 'status': result.status.value, 'strategy': result.strategy_used or '',
                    'downloaded': downloaded, 'rejected': rejected,
                    'duplicates': result.stats.get('images_duplicate', 0),
                    'products': result.stats.get('products_detected', 0),
                    'report_path': result.stats.get('report_path', ''),
                    'error': '; '.join(result.errors),
                }
                self._upsert_session_row(row)
                self.events.put(('log', f'  → {result.status.value} | strateji={result.strategy_used or "-"} | indirilen={downloaded} | reddedilen={rejected}'))
                if result.status.value == 'STOPPED':
                    self.cancel_event.set()
                elif result.status.value in {'BLOCKED', 'LOGIN_REQUIRED', 'ROBOTS_DISALLOWED', 'RATE_LIMITED'}:
                    self.events.put(('log', '     Erişim kısıtı raporlandı; sonraki linke geçildi.'))
                elif result.status.value == 'ORIGINAL_NOT_FOUND':
                    self.events.put(('log', '     Büyük/orijinal aday doğrulanamadı; thumbnail final sonuç olarak kaydedilmedi.'))
            except Exception as exc:
                row = {'url': url, 'status': 'PARSER_ERROR', 'strategy': '', 'downloaded': 0, 'rejected': 0,
                       'duplicates': 0, 'products': 0, 'report_path': '', 'error': f'{type(exc).__name__}: {exc}'}
                self._upsert_session_row(row)
                self.events.put(('log', f'  → HATA: {type(exc).__name__}: {exc}'))
            finally:
                self._write_summary_atomic(out)

            if self.cancel_event.is_set():
                break
            self.current_index = index
            self.events.put(('progress', index))
            self._save_session_state('running')

        stopped = self.cancel_event.is_set()
        if not stopped:
            self.current_index = len(urls)
        self._write_summary_atomic(out)
        self._save_session_state('stopped' if stopped else 'completed')
        self.events.put(('done', 'Durduruldu. İlerleme kaydedildi; tekrar Başlat ile devam edebilirsin.' if stopped else 'Bitti. Özet ve site raporları çıktı klasörüne kaydedildi.'))

    def _upsert_session_row(self, row: dict):
        for i, existing in enumerate(self.session_rows):
            if existing.get('url') == row.get('url'):
                self.session_rows[i] = row
                return
        self.session_rows.append(row)

    @staticmethod
    def _atomic_text(path: Path, text: str):
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(path.name + '.tmp')
        tmp.write_text(text, encoding='utf-8')
        os.replace(tmp, path)

    def _write_summary_atomic(self, out: Path):
        out.mkdir(parents=True, exist_ok=True)
        self._atomic_text(out / 'JARVIS_SESSION_SUMMARY.json', json.dumps(self.session_rows, ensure_ascii=False, indent=2))
        csv_tmp = out / 'JARVIS_SESSION_SUMMARY.csv.tmp'
        with csv_tmp.open('w', encoding='utf-8-sig', newline='') as stream:
            fields = ['url', 'status', 'strategy', 'downloaded', 'rejected', 'duplicates', 'products', 'report_path', 'error']
            writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
            writer.writeheader()
            writer.writerows(self.session_rows)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(csv_tmp, out / 'JARVIS_SESSION_SUMMARY.csv')

    @staticmethod
    def _load_existing_summary(out: Path) -> list[dict]:
        path = out / 'JARVIS_SESSION_SUMMARY.json'
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def _state_path(self, output: str | Path | None = None) -> Path:
        base = Path(output or self.output.get()).expanduser()
        return base / 'JARVIS_SESSION_STATE.json'

    def _save_session_state(self, status: str):
        if not self.current_config:
            return
        payload = {
            'version': 2,
            'status': status,
            'urls': self.current_urls,
            'next_index': self.current_index,
            'config': self.current_config,
            'updated_at': datetime.now().isoformat(timespec='seconds'),
            'session_log': str(self.session_log_path) if self.session_log_path else '',
        }
        try:
            self._atomic_text(self._state_path(self.current_config['output']), json.dumps(payload, ensure_ascii=False, indent=2))
        except Exception:
            pass

    def _offer_resume(self):
        if self.running:
            return
        path = self._state_path()
        pointer = self.project_root / '.jarvis_last_session.json'
        if pointer.exists():
            try:
                remembered = json.loads(pointer.read_text(encoding='utf-8')).get('output')
                if remembered:
                    candidate = self._state_path(remembered)
                    if candidate.exists():
                        path = candidate
            except Exception:
                pass
        if not path.exists():
            return
        try:
            state = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            return
        if state.get('status') not in {'running', 'stopping', 'stopped', 'interrupted'}:
            return
        urls = state.get('urls') or []
        if not urls:
            return
        next_index = int(state.get('next_index') or 0)
        if not messagebox.askyesno('JARVIS Scraper', f'Yarım kalan kazı bulundu.\n\nTamamlanan/sıradaki konum: {next_index}/{len(urls)}\n\nKaldığı yerden devam edilsin mi?'):
            return
        cfg = state.get('config') or {}
        self.urls.delete('1.0', 'end')
        self.urls.insert('1.0', '\n'.join(urls))
        self.output.set(cfg.get('output', self.output.get()))
        self.product_limit.set('' if cfg.get('product_limit') is None else str(cfg.get('product_limit')))
        self.image_limit.set('' if cfg.get('image_limit') is None else str(cfg.get('image_limit')))
        self.min_width.set(int(cfg.get('min_width', 400)))
        self.min_height.set(int(cfg.get('min_height', 400)))
        self.respect_robots.set(bool(cfg.get('respect_robots', True)))
        self.group_products.set(bool(cfg.get('group_products', True)))
        self._start(resume_index=next_index)

    def _setup_session_log(self, out: Path):
        log_dir = out / '_session_logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        self.session_log_path = log_dir / (datetime.now().strftime('%Y-%m-%d_%H-%M-%S') + '.log')
        file_handler = logging.FileHandler(self.session_log_path, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s | %(message)s'))
        handler = _QueueLogHandler(self.events, file_handler)
        root = logging.getLogger()
        root.setLevel(logging.DEBUG)
        # Remove only previous JARVIS queue handlers from this GUI instance.
        for old in list(root.handlers):
            if isinstance(old, _QueueLogHandler):
                root.removeHandler(old)
                try:
                    if old.file_handler:
                        old.file_handler.close()
                except Exception:
                    pass
        root.addHandler(handler)
        logging.getLogger('urllib3').setLevel(logging.WARNING)
        logging.getLogger('PIL').setLevel(logging.WARNING)

    def _heartbeat(self):
        if self.running:
            elapsed = int(time.monotonic() - (self.started_monotonic or time.monotonic()))
            idle = int(time.monotonic() - self.last_activity)
            hh, rem = divmod(elapsed, 3600)
            mm, ss = divmod(rem, 60)
            base = 'DURDURULUYOR…' if self.cancel_event.is_set() else 'ÇALIŞIYOR ●'
            self.status_text.set(f'{base}  Süre {hh:02d}:{mm:02d}:{ss:02d}  |  Son hareket {idle} sn önce')
        self.after(1000, self._heartbeat)

    def _drain_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                self.last_activity = time.monotonic()
                if kind == 'log':
                    self._write(str(payload))
                elif kind == 'engine_event':
                    event, message, data = payload
                    if message:
                        stamp = datetime.now().strftime('%H:%M:%S')
                        self._write(f'{stamp} [{event.upper()}] {message}')
                    if event in {'detect', 'strategy', 'download', 'image'} and message:
                        self.detail_text.set(message[:180])
                elif kind == 'status':
                    self.detail_text.set(str(payload)[:220])
                elif kind == 'progress':
                    self.progress.configure(value=payload)
                    self.detail_text.set(f'{payload}/{len(self.current_urls)} URL tamamlandı')
                elif kind == 'done':
                    self._write(payload)
                    self.running = False
                    self.start.configure(state='normal')
                    self.stop.configure(state='disabled')
                    self.status_text.set('DURDURULDU — ilerleme kaydedildi' if self.cancel_event.is_set() else 'TAMAMLANDI')
        except queue.Empty:
            pass
        self.after(150, self._drain_events)

    def _on_close(self):
        if self.running:
            self.cancel_event.set()
            self._save_session_state('interrupted')
        self.destroy()


def main():
    ScraperGUI().mainloop()


if __name__ == '__main__':
    main()
