import argparse, json
from .models import ScrapeRequest
from .engine import Engine
from .logging_config import configure
from .config import REQUEST_DELAY

def build_parser():
    p=argparse.ArgumentParser(description='JARVIS Scraper')
    p.add_argument('url',nargs='?'); p.add_argument('--file','-f'); p.add_argument('--output','-o',default='output'); p.add_argument('--max-items',type=int,default=100,help='Legacy ortak limit'); p.add_argument('--max-products',type=int,default=None,help='E-ticaret ürün limiti; verilmezse --max-items kullanılır'); p.add_argument('--max-images',type=int,default=None,help='Galeri/görsel limiti; verilmezse --max-items kullanılır')
    p.add_argument('--strategy',choices=['auto','shopify','woocommerce','static','dynamic','official_api','reddit','pinterest','pixabay','pexels','unsplash','etsy','trendyol'],default='auto'); p.add_argument('--min-width',type=int,default=400); p.add_argument('--min-height',type=int,default=400)
    p.add_argument('--max-pages',type=int,default=20); p.add_argument('--max-scrolls',type=int,default=20); p.add_argument('--delay',type=float,default=REQUEST_DELAY); p.add_argument('--resume',action='store_true'); p.add_argument('--dry-run',action='store_true'); p.add_argument('--verbose',action='store_true')
    p.add_argument('--respect-robots',action=argparse.BooleanOptionalAction,default=True)
    p.add_argument('--group-products', action=argparse.BooleanOptionalAction, default=False, help='Create product subfolders inside orientation folders')
    return p

def main():
    a=build_parser().parse_args(); configure(a.verbose); urls=[]
    if a.file:
        with open(a.file,encoding='utf-8') as f: urls=[x.strip() for x in f if x.strip() and not x.lstrip().startswith('#')]
    elif a.url: urls=[a.url]
    else: build_parser().print_help(); return
    for u in urls:
        req=ScrapeRequest(url=u,output=a.output,max_items=a.max_items,max_products=a.max_products,max_images=a.max_images,strategy=a.strategy,min_width=a.min_width,min_height=a.min_height,max_pages=a.max_pages,max_scrolls=a.max_scrolls,delay=a.delay,resume=a.resume,dry_run=a.dry_run,respect_robots=a.respect_robots,verbose=a.verbose,group_products=a.group_products)
        try:
            r=Engine().run(req)
            print(json.dumps({'url': u, 'status': r.status.value, 'strategy': r.strategy_used,
                              'stats': r.stats, 'errors': r.errors, 'warnings': r.warnings}, ensure_ascii=False, indent=2))
        except Exception as e:
            print(json.dumps({'url': u, 'status': 'PARSER_ERROR', 'error': str(e)}))
if __name__=='__main__': main()
