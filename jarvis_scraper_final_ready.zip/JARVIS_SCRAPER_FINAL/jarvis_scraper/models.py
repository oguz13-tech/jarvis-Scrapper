from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Callable


class Status(str, Enum):
    SUCCESS = 'SUCCESS'
    PARTIAL_SUCCESS = 'PARTIAL_SUCCESS'
    NO_RESULTS = 'NO_RESULTS'
    BLOCKED = 'BLOCKED'
    LOGIN_REQUIRED = 'LOGIN_REQUIRED'
    RATE_LIMITED = 'RATE_LIMITED'
    ROBOTS_DISALLOWED = 'ROBOTS_DISALLOWED'
    UNSUPPORTED = 'UNSUPPORTED'
    NETWORK_ERROR = 'NETWORK_ERROR'
    PARSER_ERROR = 'PARSER_ERROR'
    DOWNLOAD_ERROR = 'DOWNLOAD_ERROR'
    ORIGINAL_NOT_FOUND = 'ORIGINAL_NOT_FOUND'
    TEMPORARILY_UNAVAILABLE = 'TEMPORARILY_UNAVAILABLE'
    STOPPED = 'STOPPED'


@dataclass
class ImageAsset:
    page_url: str
    image_url: str
    original_url: str | None = None
    normalized_url: str | None = None
    local_path: str | None = None
    alt_text: str | None = None
    title: str | None = None
    width: int | None = None
    height: int | None = None
    mime_type: str | None = None
    file_size: int | None = None
    sha256: str | None = None
    perceptual_hash: str | None = None
    source_strategy: str | None = None
    download_status: str = 'pending'
    duplicate_of: str | None = None
    rejection_reason: str | None = None
    candidate_urls: list[str] = field(default_factory=list)


@dataclass
class Product:
    name: str
    url: str
    sku: str | None = None
    description: str | None = None
    images: list[ImageAsset] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str | None = None
    slug: str | None = None
    vendor: str | None = None
    product_type: str | None = None


@dataclass
class StrategyAttempt:
    strategy: str
    score: float = 0.0
    success: bool = False
    reason: str = ''
    started_at: str | None = None
    finished_at: str | None = None
    items_found: int = 0
    error_type: str | None = None
    error_message: str | None = None


@dataclass
class SiteProfile:
    domain: str
    preferred_strategy: str | None = None
    adapter: str | None = None
    requires_auth: bool = False
    official_api: bool = False
    notes: str = ''
    selectors: dict[str, Any] = field(default_factory=dict)
    tested: bool = False


@dataclass
class ScrapeRequest:
    url: str
    output: str = 'output'
    # Backwards-compatible legacy limit. New GUI uses max_products/max_images.
    # 0 means "no user limit".
    max_items: int = 100
    max_products: int | None = None
    max_images: int | None = None
    strategy: str = 'auto'
    min_width: int = 400
    min_height: int = 400
    # Safety ceilings, not user-facing content limits. Adapters still stop earlier
    # when the site reports no next page/new content.
    max_pages: int = 500
    max_scrolls: int = 200
    delay: float = 0.75
    resume: bool = False
    dry_run: bool = False
    respect_robots: bool = True
    verbose: bool = False
    group_products: bool = False
    cancel_event: Any = field(default=None, repr=False, compare=False)
    event_callback: Callable[..., Any] | None = field(default=None, repr=False, compare=False)

    @property
    def output_dir(self) -> str:
        return self.output

    @staticmethod
    def _normalize_limit(value: int | None) -> int | None:
        if value is None:
            return None
        try:
            ivalue = int(value)
        except (TypeError, ValueError):
            return None
        return ivalue if ivalue > 0 else None

    @property
    def product_limit(self) -> int | None:
        explicit = self._normalize_limit(self.max_products)
        if explicit is not None:
            return explicit
        return self._normalize_limit(self.max_items)

    @property
    def image_limit(self) -> int | None:
        explicit = self._normalize_limit(self.max_images)
        if explicit is not None:
            return explicit
        return self._normalize_limit(self.max_items)

    def emit(self, event: str, message: str = '', **data: Any) -> None:
        callback = self.event_callback
        if callback is None:
            return
        try:
            callback(event, message, data)
        except Exception:
            # UI/observer failures must never break the scraping pipeline.
            return

    @property
    def is_cancelled(self) -> bool:
        try:
            return bool(self.cancel_event and self.cancel_event.is_set())
        except Exception:
            return False


@dataclass
class ScrapeResult:
    source_url: str
    domain: str
    strategy_used: str | None = None
    attempted_strategies: list[StrategyAttempt] = field(default_factory=list)
    products: list[Product] = field(default_factory=list)
    images: list[ImageAsset] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    stats: dict[str, Any] = field(default_factory=dict)
    status: Status = Status.NO_RESULTS

    def to_dict(self) -> dict:
        return asdict(self)
