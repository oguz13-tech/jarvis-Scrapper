import csv
from collections import Counter
import json
import logging
import os
import time
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit

from .models import ScrapeResult, StrategyAttempt, Status
from .detector import Detector
from .platforms import detect_platform
from .registry import normalize_domain, get_profile
from .exceptions import ScrapeError, check_access
from .paths import safe_name, job_name, suffix
from .fetchers.http_fetcher import HttpFetcher, validate_url
from .fetchers.browser_fetcher import BrowserFetcher
from .adapters.shopify import ShopifyAdapter
from .adapters.woocommerce import WooCommerceAdapter
from .adapters.generic_static import GenericStaticAdapter
from .adapters.generic_dynamic import GenericDynamicAdapter
from .adapters.wallhaven import WallhavenAdapter
from .adapters.reddit import RedditAdapter
from .adapters.pinterest import PinterestAdapter
from .adapters.pixabay import PixabayAdapter
from .adapters.pexels import PexelsAdapter
from .adapters.unsplash import UnsplashAdapter
from .adapters.etsy import EtsyAdapter
from .adapters.trendyol import TrendyolAdapter
from .adapters.stock_api import KEYS
from .download.downloader import Downloader
from .storage.manifest import Manifest
from .storage.strategy_memory import StrategyMemory

ADAPTERS = {
    'shopify': ShopifyAdapter,
    'woocommerce': WooCommerceAdapter,
    'static': GenericStaticAdapter,
    'dynamic': GenericDynamicAdapter,
    'official_api': WallhavenAdapter,
    'reddit': RedditAdapter,
    'pinterest': PinterestAdapter,
    'pixabay': PixabayAdapter,
    'pexels': PexelsAdapter,
    'unsplash': UnsplashAdapter,
    'etsy': EtsyAdapter,
    'trendyol': TrendyolAdapter,
}
log = logging.getLogger(__name__)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def _emit(request, event: str, message: str = '', **data) -> None:
    try:
        request.emit(event, message, **data)
    except Exception:
        pass


def _check_cancel(request) -> None:
    if getattr(request, 'is_cancelled', False):
        raise ScrapeError(Status.STOPPED, 'Kullanıcı tarafından durduruldu; mevcut ilerleme kaydedildi')


def _limit_reached(result: ScrapeResult, request, counts: dict) -> bool:
    """Return True when the user-requested target has been fully satisfied.

    Product jobs are complete once the requested number of products has at least one
    saved/resumed/duplicate image. Gallery jobs are complete once the requested image
    count is usable. Rejected extra candidates do not downgrade a completed target.
    """
    if result.products:
        limit = request.product_limit
        if limit is None:
            return False
        saved_products = sum(
            any(i.download_status in {'downloaded', 'resume_skipped'} or i.download_status.startswith('duplicate') for i in p.images)
            for p in result.products
        )
        return saved_products >= limit
    limit = request.image_limit
    if limit is None:
        return False
    usable = counts.get('images_downloaded', 0) + counts.get('images_duplicate', 0) + counts.get('resume_skipped', 0)
    return usable >= limit


class Engine:
    """Adaptive scrape orchestrator.

    Strategy success is quality-gated: finding HTML image URLs is not enough. In
    normal (non-dry-run) mode at least one candidate must survive high-resolution
    expansion, validation and de-duplication before a strategy wins. A static
    thumbnail-only result can therefore fall through to a dynamic/browser strategy.
    """

    @staticmethod
    def _copy_trial(target: ScrapeResult, trial: ScrapeResult, strategy: str, status: Status) -> None:
        target.products = trial.products
        target.images = trial.images
        target.stats.update(trial.stats)
        target.strategy_used = strategy
        target.status = status
        for warning in trial.warnings:
            if warning not in target.warnings:
                target.warnings.append(warning)
        for error in trial.errors:
            if error not in target.errors:
                target.errors.append(error)

    @staticmethod
    def _download_outcome(trial: ScrapeResult) -> tuple[Status, dict, Counter]:
        counts = {
            'images_downloaded': sum(i.download_status == 'downloaded' for i in trial.images),
            'images_rejected': sum(i.download_status == 'rejected' for i in trial.images),
            'images_failed': sum(i.download_status == 'failed' for i in trial.images),
            'resume_skipped': sum(i.download_status == 'resume_skipped' for i in trial.images),
            'images_duplicate': sum(i.download_status.startswith('duplicate') for i in trial.images),
        }
        reasons = Counter(
            i.rejection_reason or '' for i in trial.images
            if i.download_status in {'rejected', 'failed'}
        )
        usable = counts['images_downloaded'] + counts['images_duplicate'] + counts['resume_skipped']
        bad = counts['images_rejected'] + counts['images_failed']
        if usable:
            status = Status.PARTIAL_SUCCESS if bad else Status.SUCCESS
        elif reasons and set(reasons) <= {'preview_only', 'low_resolution'}:
            status = Status.ORIGINAL_NOT_FOUND
        else:
            status = Status.DOWNLOAD_ERROR
        return status, counts, reasons

    @staticmethod
    def _plain_http_403(error: ScrapeError) -> bool:
        # A normal browser render may be tried after a bare presentation-page 403.
        # CAPTCHA/login/challenge text is never treated as a browser-fallback signal.
        msg = str(error).lower()
        return error.status == Status.BLOCKED and msg.startswith('http 403:') and not any(
            token in msg for token in ('captcha', 'verify you are human', 'challenge', 'login', 'signin')
        )

    def run(self, request):
        start, started = time.monotonic(), now()
        domain = normalize_domain(urlsplit(request.url).netloc)
        result = ScrapeResult(request.url, domain)
        root = (Path(request.output) / safe_name(domain) / job_name(request.url)).resolve()
        root.mkdir(parents=True, exist_ok=True)
        # Interrupted binary writes are intentionally left as .part files. They are
        # never treated as completed downloads; clean them before resuming.
        for partial in root.rglob('*.part'):
            try:
                partial.unlink()
            except OSError:
                pass
        manifest = Manifest(root / 'manifest.jsonl')
        memory = StrategyMemory(Path(request.output) / '.jarvis_strategy_memory.json')
        http = HttpFetcher(request.delay, request.respect_robots)
        browser = BrowserFetcher(http=http)
        selected = False
        best_failed = None
        last_status = Status.NO_RESULTS
        try:
            _check_cancel(request)
            _emit(request, 'job_start', f'İş başlatıldı: {request.url}', url=request.url, domain=domain)
            validate_url(request.url)
            if request.max_pages < 1 or request.min_width < 1 or request.min_height < 1 or request.delay < 0 or request.max_scrolls < 0:
                raise ScrapeError(Status.UNSUPPORTED, 'Invalid numeric limits')

            profile = get_profile(domain)
            # Page discovery always honors the job robots policy before HTTP/browser access.
            http.check_robots(request.url)
            html = None
            presentation_403 = None
            api_ready = profile.adapter in KEYS and bool(os.getenv(KEYS[profile.adapter]))
            if profile.adapter in KEYS and not api_ready:
                result.warnings.append(f'{KEYS[profile.adapter]} is absent; trying public page/browser fallbacks')

            dedicated_first = {'wallhaven', 'reddit', 'etsy', 'trendyol', 'pixabay', 'pexels', 'unsplash'}
            if profile.adapter not in dedicated_first and not api_ready:
                try:
                    response = http.get(request.url, cached=True)
                    html = response.text
                    check_access(html, response.url)
                except ScrapeError as e:
                    # requests-style 403s are sometimes presentation-layer/WAF differences.
                    # In auto mode we may still try an ordinary, non-stealth browser render.
                    if request.strategy == 'auto' and self._plain_http_403(e):
                        presentation_403 = e
                        result.warnings.append('Presentation HTTP returned 403; trying normal browser rendering without stealth/challenge bypass')
                    else:
                        raise

            ranked = Detector().rank(request.url, html) if request.strategy == 'auto' else [(request.strategy, 1.0)]
            if presentation_403 and request.strategy == 'auto':
                score_map = dict(ranked)
                score_map['dynamic'] = max(score_map.get('dynamic', 0.0), 1.05)
                ranked = sorted(score_map.items(), key=lambda item: item[1], reverse=True)

            fingerprint = detect_platform(request.url, html)
            learned = memory.get(domain) if request.strategy == 'auto' else None
            if learned and learned.get('strategy') in ADAPTERS:
                learned_strategy = learned['strategy']
                score_map = dict(ranked)
                score_map[learned_strategy] = max(score_map.get(learned_strategy, 0.0), 0.90)
                ranked = sorted(score_map.items(), key=lambda item: item[1], reverse=True)

            result.stats.update(
                platform=fingerprint.platform,
                detected_site_type=fingerprint.site_type,
                platform_scores=fingerprint.scores,
                platform_signals=fingerprint.signals,
                fallback_strategies=[s for s, _ in ranked],
                official_api=profile.official_api,
                learned_strategy=(learned or {}).get('strategy'),
                presentation_http_403=bool(presentation_403),
            )
            log.info('[DETECT] domain=%s platform=%s type=%s', domain, fingerprint.platform, fingerprint.site_type)
            _emit(request, 'detect', f'Platform: {fingerprint.platform} | tür: {fingerprint.site_type}', platform=fingerprint.platform, site_type=fingerprint.site_type)

            for position, (strategy, score) in enumerate(ranked):
                _check_cancel(request)
                attempt = StrategyAttempt(strategy, score, started_at=now())
                trial = ScrapeResult(request.url, domain)
                attempt_status = Status.NO_RESULTS
                log.info('[STRATEGY] trying=%s score=%.2f', strategy, score)
                _emit(request, 'strategy', f'Strateji deneniyor: {strategy}', strategy=strategy, score=score)
                try:
                    cls = ADAPTERS.get(strategy)
                    if not cls:
                        raise ScrapeError(Status.UNSUPPORTED, f'Unknown strategy: {strategy}')
                    ok = cls(http, browser).scrape(request, trial)
                    attempt.items_found = len(trial.images)
                    for warning in trial.warnings:
                        if warning not in result.warnings:
                            result.warnings.append(warning)

                    if not (ok and trial.images):
                        attempt.reason = 'no_data'
                        attempt_status = Status.NO_RESULTS
                        last_status = attempt_status
                    elif request.dry_run:
                        attempt.success = True
                        attempt.reason = 'candidates_found_dry_run'
                        attempt_status = Status.SUCCESS
                        self._copy_trial(result, trial, strategy, attempt_status)
                        selected = True
                    else:
                        # Quality gate the strategy before accepting it. This lets a
                        # thumbnail-only static parse fall through to browser/dynamic.
                        self.save_images(request, trial, root, manifest, http)
                        attempt_status, trial_counts, reasons = self._download_outcome(trial)
                        trial.stats.update(trial_counts)
                        trial.stats['rejection_reasons'] = dict(reasons)
                        usable = trial_counts['images_downloaded'] + trial_counts['images_duplicate'] + trial_counts['resume_skipped']
                        attempt.success = usable > 0
                        attempt.reason = 'quality_verified' if attempt.success else attempt_status.value.lower()
                        if attempt.success:
                            self._copy_trial(result, trial, strategy, attempt_status)
                            selected = True
                        else:
                            # Preserve the richest failed attempt for an honest final report
                            # if every later strategy also fails.
                            rank_key = (len(trial.images), 1 if attempt_status == Status.ORIGINAL_NOT_FOUND else 0)
                            if best_failed is None or rank_key > best_failed[0]:
                                best_failed = (rank_key, trial, strategy, attempt_status)
                            last_status = attempt_status
                            result.warnings.append(
                                f'{strategy}: candidates failed quality/download gate ({attempt_status.value}); trying fallback'
                            )
                except Exception as e:
                    status = e.status if isinstance(e, ScrapeError) else Status.PARSER_ERROR
                    attempt_status = status
                    last_status = status
                    attempt.error_type = status.value
                    attempt.error_message = str(e)
                    attempt.reason = str(e)
                    result.warnings.append(f'{strategy}: {status.value}: {e}')
                finally:
                    attempt.finished_at = now()
                    result.attempted_strategies.append(attempt)

                if selected:
                    break

                # Do not route around explicit policy/login/rate-limit/challenge states.
                if attempt_status in {Status.ROBOTS_DISALLOWED, Status.LOGIN_REQUIRED, Status.RATE_LIMITED, Status.TEMPORARILY_UNAVAILABLE, Status.STOPPED}:
                    break
                if attempt_status == Status.BLOCKED:
                    remaining = {name for name, _ in ranked[position + 1:]}
                    # A bare requests 403 may fall through to an ordinary browser once.
                    if request.strategy == 'auto' and strategy != 'dynamic' and 'dynamic' in remaining and attempt.error_message and attempt.error_message.lower().startswith('http 403:'):
                        continue
                    break

            if not selected and best_failed is not None:
                _, trial, strategy, status = best_failed
                self._copy_trial(result, trial, strategy, status)
            elif not selected:
                result.status = last_status

            if result.strategy_used and result.images and result.status in {Status.SUCCESS, Status.PARTIAL_SUCCESS}:
                memory.remember(
                    domain,
                    result.strategy_used,
                    result.stats.get('platform', fingerprint.platform),
                    result.stats.get('detected_site_type', fingerprint.site_type),
                )
        except ScrapeError as e:
            result.status = e.status
            result.errors.append(str(e))
        except Exception as e:
            log.exception('Job failed')
            result.status = Status.PARSER_ERROR
            result.errors.append(f'{type(e).__name__}: {e}')
        finally:
            browser.close()
            http.close()

        counts = {
            name: sum(image.download_status == status for image in result.images)
            for name, status in [
                ('images_downloaded', 'downloaded'),
                ('images_rejected', 'rejected'),
                ('images_failed', 'failed'),
                ('resume_skipped', 'resume_skipped'),
            ]
        }
        counts['images_duplicate'] = sum(image.download_status.startswith('duplicate') for image in result.images)
        counts['products_saved'] = sum(
            any(i.download_status in {'downloaded', 'resume_skipped'} or i.duplicate_of for i in p.images)
            for p in result.products
        )
        rejection_reasons = Counter(
            image.rejection_reason or '' for image in result.images
            if image.download_status in {'rejected', 'failed'}
        )
        if result.images and not request.dry_run and result.status != Status.STOPPED:
            usable = counts['images_downloaded'] + counts['images_duplicate'] + counts['resume_skipped']
            bad = counts['images_rejected'] + counts['images_failed']
            target_reached = _limit_reached(result, request, counts)
            if usable:
                result.status = Status.SUCCESS if target_reached or not bad else Status.PARTIAL_SUCCESS
            elif rejection_reasons and set(rejection_reasons) <= {'preview_only', 'low_resolution'}:
                result.status = Status.ORIGINAL_NOT_FOUND
            elif result.status not in {Status.BLOCKED, Status.LOGIN_REQUIRED, Status.RATE_LIMITED, Status.ROBOTS_DISALLOWED}:
                result.status = Status.DOWNLOAD_ERROR
        else:
            target_reached = False

        result.stats.update(counts)
        result.stats['rejection_reasons'] = dict(rejection_reasons)
        result.stats.update(
            products_detected=len(result.products),
            candidate_images=len(result.images),
            robots=http.robots_results,
            http_requests=http.history,
            dry_run=request.dry_run,
            group_products=request.group_products,
            product_limit=request.product_limit,
            image_limit=request.image_limit,
            target_reached=target_reached,
            downloaded=counts['images_downloaded'],
            duplicates_skipped=counts['images_duplicate'],
            started_at=started,
            finished_at=now(),
            elapsed_seconds=round(time.monotonic() - start, 3),
        )
        report = result.to_dict()
        report.update(result.stats)
        report.update(strategy_selected=result.strategy_used, strategies_attempted=report['attempted_strategies'])
        write_json(root / 'scrape_report.json', report)
        result.stats['report_path'] = str(root / 'scrape_report.json')
        log.info(
            '[RESULT] %s products=%s candidates=%s downloaded=%s',
            result.status.value, len(result.products), len(result.images), counts['images_downloaded']
        )
        _emit(request, 'job_result', f'{result.status.value} | ürün={len(result.products)} | indirilen={counts["images_downloaded"]} | reddedilen={counts["images_rejected"]}', status=result.status.value, **counts)
        return result

    def save_images(self, request, result, root, manifest, http) -> None:
        downloader = Downloader(request.min_width, request.min_height, request.delay, http, cancel_event=request.cancel_event, event_callback=request.event_callback)
        previous = {}
        if request.resume:
            for row in manifest.successful():
                downloader.dedup.remember(row['image_url'], row.get('sha256'), row.get('perceptual_hash'), row['local_path'])
                previous[downloader.dedup.normalize_url(row['image_url'])] = row
        groups = [(p, p.images, root / 'products' / (safe_name(p.slug or p.name) + '-' + suffix(p.url + (p.id or '')))) for p in result.products]
        if not groups:
            groups = [(None, result.images, root / 'gallery')]
        attempted = []
        for product, images, directory in groups:
            saved = 0
            for index, image in enumerate(images, 1):
                if not product and request.image_limit is not None and saved >= request.image_limit:
                    break
                _check_cancel(request)
                attempted.append(image)
                image.normalized_url = downloader.dedup.normalize_url(image.image_url)
                prior = previous.get(image.normalized_url)
                if prior:
                    for key in ('local_path', 'width', 'height', 'mime_type', 'file_size', 'sha256', 'perceptual_hash'):
                        setattr(image, key, prior.get(key))
                    image.download_status = 'resume_skipped'
                else:
                    downloader.download(image, root, index, directory.name if product and request.group_products else None)
                row = asdict(image)
                for key in ('local_path', 'duplicate_of'):
                    if row.get(key):
                        row[key] = str(Path(row[key]).relative_to(root))
                row.update(timestamp=now(), product_id=product.id if product else None,
                    product_name=product.name if product else None, product_url=product.url if product else None,
                    bytes=image.file_size, status=image.download_status, strategy=image.source_strategy)
                manifest.append(row)
                saved += image.download_status in {'downloaded', 'resume_skipped'}
                _emit(request, 'image', f'{image.download_status}: {image.width or "?"}x{image.height or "?"} {image.image_url}', status=image.download_status, width=image.width, height=image.height, url=image.image_url)
            if product:
                directory = root / 'metadata' / directory.name
                directory.mkdir(parents=True, exist_ok=True)
                write_json(directory / 'metadata.json', asdict(product))
        if not result.products:
            result.stats['discovered_candidates'] = len(result.images)
            result.images = attempted
        if result.products:
            with (root / 'products.csv').open('w', encoding='utf-8', newline='') as stream:
                writer = csv.writer(stream)
                writer.writerow(['id', 'name', 'url', 'downloaded', 'resumed', 'duplicates', 'failed', 'rejected'])
                for product in result.products:
                    writer.writerow([product.id, product.name, product.url,
                        sum(i.download_status == 'downloaded' for i in product.images),
                        sum(i.download_status == 'resume_skipped' for i in product.images),
                        sum(i.download_status.startswith('duplicate') for i in product.images),
                        sum(i.download_status == 'failed' for i in product.images),
                        sum(i.download_status == 'rejected' for i in product.images)])
