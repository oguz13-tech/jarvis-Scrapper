from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

ACCESS_STATUSES = {
    'BLOCKED', 'LOGIN_REQUIRED', 'RATE_LIMITED', 'ROBOTS_DISALLOWED', 'TEMPORARILY_UNAVAILABLE'
}


def _text(row: dict[str, Any]) -> str:
    parts = [row.get('status', ''), row.get('strategy', '')]
    parts.extend(row.get('errors') or [])
    parts.extend(row.get('warnings') or [])
    for attempt in row.get('attempted_strategies') or []:
        parts.extend([
            attempt.get('error_type') or '', attempt.get('error_message') or '',
            attempt.get('reason') or '', attempt.get('strategy') or ''
        ])
    return ' '.join(str(p) for p in parts if p).lower()


def classify_failure(row: dict[str, Any]) -> dict[str, str]:
    status = str(row.get('status') or 'UNKNOWN')
    stats = row.get('stats') or {}
    txt = _text(row)
    platform = str(stats.get('platform') or stats.get('detected_platform') or 'unknown')
    site_type = str(stats.get('detected_site_type') or 'unknown')
    attempts = row.get('attempted_strategies') or []
    attempted_names = {str(a.get('strategy') or '') for a in attempts}
    attempt_errors = {str(a.get('error_type') or '') for a in attempts if a.get('error_type')}

    if status in {'SUCCESS', 'PARTIAL_SUCCESS'}:
        if status == 'PARTIAL_SUCCESS':
            return {'category': 'PARTIAL_DOWNLOAD', 'severity': 'medium', 'action': 'inspect_rejections'}
        return {'category': 'OK', 'severity': 'none', 'action': 'none'}
    if status in ACCESS_STATUSES:
        return {'category': 'ACCESS_CONTROL', 'severity': 'external', 'action': 'report_only'}
    # Preserve the semantic meaning of NO_RESULTS. Browser warnings may contain
    # words like "timeout" even when the page itself loaded successfully; that
    # must not be mislabeled as a network outage.
    if status == 'NO_RESULTS':
        if attempt_errors and attempt_errors <= {'NETWORK_ERROR', 'TEMPORARILY_UNAVAILABLE'}:
            return {'category': 'NETWORK', 'severity': 'external', 'action': 'retry_later'}
        if platform in {'nextjs', 'nuxt', 'react', 'react_spa'} or site_type in {'js_app', 'storefront', 'dynamic_or_cms'} or 'dynamic' in attempted_names:
            return {'category': 'DYNAMIC_EXTRACTION_GAP', 'severity': 'high', 'action': 'inspect_hydration_xhr_selectors'}
        if any(x in txt for x in ('sitemap', 'product', 'gallery', 'selector')):
            return {'category': 'DISCOVERY_GAP', 'severity': 'high', 'action': 'expand_product_gallery_discovery'}
        return {'category': 'NO_DATA_GENERIC', 'severity': 'high', 'action': 'inspect_page_structure'}
    if status == 'NETWORK_ERROR':
        return {'category': 'NETWORK', 'severity': 'external', 'action': 'retry_later'}
    if status == 'ORIGINAL_NOT_FOUND':
        return {'category': 'ORIGINAL_RESOLUTION_GAP', 'severity': 'high', 'action': 'follow_detail_page_and_expand_highres_candidates'}
    if status == 'DOWNLOAD_ERROR':
        if any(x in txt for x in ('resolution', 'too small', 'minimum', 'low_resolution')):
            return {'category': 'LOW_RESOLUTION', 'severity': 'medium', 'action': 'expand_highres_candidates'}
        if any(x in txt for x in ('html', 'content-type', 'pillow', 'decode', 'mime')):
            return {'category': 'INVALID_IMAGE_RESPONSE', 'severity': 'medium', 'action': 'inspect_image_endpoint'}
        if any(x in txt for x in ('403', '401', 'robots_disallowed', 'rate_limited')):
            return {'category': 'ASSET_ACCESS_CONTROL', 'severity': 'external', 'action': 'report_asset_host_restriction'}
        return {'category': 'DOWNLOAD_PIPELINE', 'severity': 'medium', 'action': 'inspect_download_failures'}
    if status == 'PARSER_ERROR':
        if any(x in txt for x in ('json', 'decode', 'expecting value')):
            return {'category': 'STRUCTURED_DATA_PARSE', 'severity': 'high', 'action': 'harden_json_parser'}
        return {'category': 'PARSER_BUG', 'severity': 'high', 'action': 'inspect_trace_and_fixture'}
    if status == 'UNSUPPORTED':
        return {'category': 'UNSUPPORTED_STRUCTURE', 'severity': 'high', 'action': 'add_reusable_adapter_or_rule'}
    if any(x in txt for x in ('connectionerror', 'dns', 'name resolution', 'timed out', 'timeout', 'ssl')):
        return {'category': 'NETWORK', 'severity': 'external', 'action': 'retry_later'}
    return {'category': 'UNKNOWN_FAILURE', 'severity': 'medium', 'action': 'inspect_raw_report'}


def build_retry_plan(row: dict[str, Any]) -> list[dict[str, Any]]:
    status = str(row.get('status') or '')
    stats = row.get('stats') or {}
    attempted = [a.get('strategy') for a in row.get('attempted_strategies') or [] if a.get('strategy')]
    platform = str(stats.get('platform') or 'unknown')
    plan: list[dict[str, Any]] = []

    if status in ACCESS_STATUSES:
        return plan
    if status in {'NETWORK_ERROR', 'TEMPORARILY_UNAVAILABLE'}:
        plan.append({'kind': 'retry_same', 'reason': 'transient network/service failure'})
        return plan
    if status in {'NO_RESULTS', 'PARSER_ERROR', 'UNSUPPORTED'}:
        candidates = []
        if platform == 'shopify':
            candidates += ['shopify', 'static', 'dynamic']
        elif platform in {'woocommerce', 'wordpress'}:
            candidates += ['woocommerce', 'static', 'dynamic']
        else:
            candidates += ['static', 'dynamic']
        for strategy in candidates:
            if strategy not in attempted:
                plan.append({'kind': 'strategy_retry', 'strategy': strategy, 'reason': 'fallback coverage'})
    if status == 'ORIGINAL_NOT_FOUND':
        plan.append({'kind': 'reextract', 'reason': 'follow detail/original links and expand provider high-resolution candidates'})
        return plan
    if status == 'DOWNLOAD_ERROR':
        plan.append({'kind': 'reextract', 'reason': 'rebuild image candidate list and follow detail/original links before redownload'})
    return plan[:3]


def analyze_run(rows: list[dict[str, Any]]) -> dict[str, Any]:
    status_counts = Counter()
    category_counts = Counter()
    platform_counts = Counter()
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    actionable = []

    for row in rows:
        status = str(row.get('status') or 'UNKNOWN')
        stats = row.get('stats') or {}
        platform = str(stats.get('platform') or 'unknown')
        diagnosis = classify_failure(row)
        row['diagnosis'] = diagnosis
        row['retry_plan'] = build_retry_plan(row)
        status_counts[status] += 1
        category_counts[diagnosis['category']] += 1
        platform_counts[platform] += 1
        grouped[diagnosis['category']].append({
            'url': row.get('url'), 'status': status, 'platform': platform,
            'strategy': row.get('strategy'), 'action': diagnosis['action'],
        })
        if diagnosis['severity'] == 'high':
            actionable.append(grouped[diagnosis['category']][-1])

    return {
        'total': len(rows),
        'status_counts': dict(status_counts),
        'failure_categories': dict(category_counts),
        'platform_counts': dict(platform_counts),
        'groups': dict(grouped),
        'high_priority': actionable,
    }
