from urllib.parse import urlsplit
import os
from .registry import get_profile
from .adapters.stock_api import KEYS
from .platforms import detect_platform


class Detector:
    """Rank generic strategies from runtime fingerprints plus light registry hints."""

    def rank(self, url: str, html: str | None = None) -> list[tuple[str, float]]:
        profile = get_profile(urlsplit(url).netloc)
        fp = detect_platform(url, html)
        scores: dict[str, float] = {'static': 0.45, 'dynamic': 0.30}

        # Registry is only a hint. Runtime evidence may outrank it.
        if profile.preferred_strategy:
            # With no document yet, registry hints help choose the first fetch path.
            # Once HTML exists, absent runtime evidence must be allowed to override stale hints.
            hint = 0.60 if html is None else 0.40
            scores[profile.preferred_strategy] = max(scores.get(profile.preferred_strategy, 0), hint)

        platform = fp.platform
        if platform == 'shopify':
            if fp.scores.get('shopify', 0) >= 0.90:
                scores['shopify'] = 0.99
            scores['static'] = max(scores['static'], 0.76)
        elif platform == 'woocommerce':
            scores['woocommerce'] = 0.98
            scores['static'] = max(scores['static'], 0.88)
            scores['dynamic'] = max(scores['dynamic'], 0.48)
        elif platform in {'wordpress', 'magento', 'prestashop', 'opencart', 'bigcommerce', 'salesforce_commerce', 'structured_commerce'}:
            scores['static'] = max(scores['static'], 0.88)
            scores['dynamic'] = max(scores['dynamic'], 0.48)
        elif platform in {'nextjs', 'nuxt', 'react_spa'}:
            # Structured hydration may still be parseable without a browser, so try static first.
            scores['static'] = max(scores['static'], 0.68)
            scores['dynamic'] = max(scores['dynamic'], 0.86)

        h = (html or '').lower()
        if 'application/ld+json' in h and 'product' in h:
            scores['static'] = max(scores['static'], 0.82)
        if '__next_data__' in h or '__nuxt__' in h or 'data-reactroot' in h:
            scores['dynamic'] = max(scores['dynamic'], 0.78)

        if profile.adapter == 'wallhaven':
            scores['official_api'] = 1.0
        if profile.adapter in KEYS:
            # Dedicated stock adapters use the official API when configured and
            # otherwise fall back to the public rendered/detail-page pipeline.
            scores[profile.adapter] = 1.08 if os.getenv(KEYS[profile.adapter]) else 1.01
        if profile.adapter == 'reddit':
            scores['reddit'] = 0.98
        if profile.adapter == 'pinterest':
            scores['pinterest'] = 0.97
        if profile.adapter == 'etsy':
            scores['etsy'] = 1.10
        if profile.adapter == 'trendyol':
            scores['trendyol'] = 1.10

        return sorted(scores.items(), key=lambda item: item[1], reverse=True)
