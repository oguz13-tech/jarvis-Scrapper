from ..exceptions import ScrapeError, check_access
from ..models import Status
from ..config import USER_AGENT
import time
import json
from urllib.parse import urlsplit

_ANALYTICS_HOST_MARKERS = (
    'googletagmanager.com', 'google-analytics.com', 'doubleclick.net', 'facebook.net',
    'tiktok.com', 'bing.com', 'clarity.ms', 'hotjar.com', 'segment.io', 'segment.com',
)


class BrowserFetcher:
    def __init__(self, user_agent=None, http=None):
        self.user_agent = user_agent or USER_AGENT
        self.http = http
        self.playwright = self.browser = self.context = None
        self.start_error = None
        self.last_warning = None
        self.last_json_payloads = []
        self.last_image_candidates = []
        self.last_url = None

    def start(self) -> None:
        if self.context:
            return
        if self.start_error:
            raise ScrapeError(Status.UNSUPPORTED, self.start_error)
        try:
            from playwright.sync_api import sync_playwright
            self.playwright = sync_playwright().start()
            self.browser = self.playwright.chromium.launch(headless=True)
            self.context = self.browser.new_context(
                user_agent=self.user_agent,
                viewport={'width': 1440, 'height': 1000},
                service_workers='block',
            )
        except Exception as e:
            self.close()
            self.start_error = f'Playwright unavailable: {type(e).__name__}: {e}'
            raise ScrapeError(Status.UNSUPPORTED, self.start_error) from e

    @staticmethod
    def _host(url: str) -> str:
        return (urlsplit(url).hostname or '').lower()

    @staticmethod
    def _dismiss_public_modal(page) -> bool:
        """Dismiss a visibly closable public-page modal without bypassing login.

        We only use ordinary UI actions (explicit close/dismiss buttons or Escape).
        If the site still requires authentication, the normal access checks report
        LOGIN_REQUIRED; overlays are never deleted from the DOM.
        """
        selectors = (
            'button[aria-label="Close"]', 'button[aria-label="close"]',
            'button[aria-label="Dismiss"]', 'button[aria-label="dismiss"]',
            '[role="dialog"] button[data-testid*="close" i]',
            '[role="dialog"] button[data-test-id*="close" i]',
            '[role="dialog"] [data-testid*="dismiss" i]',
        )
        for selector in selectors:
            try:
                loc = page.locator(selector).first
                if loc.count() and loc.is_visible():
                    loc.click(timeout=1000)
                    page.wait_for_timeout(150)
                    return True
            except Exception:
                continue
        try:
            page.keyboard.press('Escape')
            page.wait_for_timeout(100)
        except Exception:
            pass
        return False

    def fetch(self, url, max_scrolls=20, scroll_delay=750, wait_until='domcontentloaded', wait_selector=None, dismiss_public_modals=False, cancel_event=None):
        if cancel_event is not None and cancel_event.is_set():
            raise ScrapeError(Status.STOPPED, 'Kullanıcı tarafından durduruldu')
        if self.http:
            self.http.check_robots(url)
        self.start()
        self.last_warning = None
        self.last_json_payloads = []
        self.last_image_candidates = []
        self.last_url = None
        page = self.context.new_page()
        denied = []
        deadline = time.monotonic() + 75
        main_host = self._host(url)
        network_media = set()

        def route_request(route):
            req = route.request
            if time.monotonic() > deadline:
                route.abort()
                return
            # Capture image/media request URLs even though binaries are not loaded in
            # the browser. Dynamic lazy-load code often reveals the real CDN URL only
            # through a request event. The downloader validates/fetches it later.
            if req.resource_type in {'image', 'media'}:
                if req.url.startswith(('http://', 'https://')):
                    network_media.add(req.url)
                route.abort()
                return
            if req.resource_type == 'font' or req.method != 'GET':
                route.abort()
                return
            host = self._host(req.url)
            # Third-party analytics are irrelevant and frequently introduce noisy robots calls.
            if any(marker in host for marker in _ANALYTICS_HOST_MARKERS):
                route.abort()
                return
            try:
                if self.http:
                    self.http.check_robots(req.url)
                    self.http.throttle(req.url)
                route.continue_()
            except ScrapeError as e:
                if req.is_navigation_request() and req.frame == page.main_frame:
                    denied.append(e)
                route.abort()

        page.route('**/*', route_request)

        def capture_response(resp):
            if len(self.last_json_payloads) >= 40:
                return
            try:
                # Same-origin application JSON only. Do not harvest arbitrary third-party payloads.
                if self._host(resp.url) != main_host:
                    return
                ctype = (resp.headers.get('content-type') or '').lower()
                if 'json' not in ctype:
                    return
                body = resp.body()
                if len(body) > 3 * 1024 * 1024:
                    return
                data = json.loads(body.decode('utf-8', 'replace'))
                self.last_json_payloads.append(data)
            except Exception:
                return

        page.on('response', capture_response)
        try:
            response = page.goto(url, wait_until='commit', timeout=45000)
            if denied:
                raise denied[0]
            if response and response.status >= 400:
                status = {401: Status.LOGIN_REQUIRED, 403: Status.BLOCKED, 429: Status.RATE_LIMITED}.get(
                    response.status, Status.TEMPORARILY_UNAVAILABLE
                )
                raise ScrapeError(status, f'Browser HTTP {response.status}: {page.url}')
            if wait_until != 'commit':
                from playwright.sync_api import TimeoutError as PlaywrightTimeoutError
                try:
                    page.wait_for_load_state(wait_until, timeout=15000)
                except PlaywrightTimeoutError:
                    self.last_warning = 'DOM readiness timed out; extracting the currently rendered public document'
            if dismiss_public_modals:
                self._dismiss_public_modal(page)
            check_access(page.content(), page.url)
            if wait_selector:
                page.wait_for_selector(wait_selector, timeout=10000)

            previous, stable = None, 0
            clicks = 0
            for _ in range(max_scrolls):
                if cancel_event is not None and cancel_event.is_set():
                    raise ScrapeError(Status.STOPPED, 'Kullanıcı tarafından durduruldu')
                if time.monotonic() > deadline:
                    break
                page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
                page.wait_for_timeout(scroll_delay)
                if dismiss_public_modals:
                    self._dismiss_public_modal(page)
                if clicks < 8:
                    for selector in (
                        'button:has-text("Load more")', 'a:has-text("Load more")',
                        'button:has-text("Show more")', 'a:has-text("Show more")',
                        'button:has-text("Daha fazla")', 'a:has-text("Daha fazla")',
                        '[data-testid*="load-more"]', '.load-more button', '.load-more a',
                    ):
                        try:
                            loc = page.locator(selector).first
                            if loc.count() and loc.is_visible():
                                loc.click(timeout=1500)
                                clicks += 1
                                page.wait_for_timeout(scroll_delay)
                                break
                        except Exception:
                            continue
                current = page.evaluate('[document.body.scrollHeight, document.images.length, document.body.innerText.length]')
                stable = stable + 1 if current == previous else 0
                previous = current
                if stable >= 3:
                    break

            # Browser-computed currentSrc is useful on sites that populate URLs only after
            # intersection/lazy-loading logic. We only collect strings; binaries remain blocked.
            try:
                media = page.evaluate(r'''() => {
                    const out = [];
                    const push = (v) => { if (typeof v === 'string' && v) out.push(v); };
                    const pushSet = (v) => {
                        if (!v) return;
                        for (const part of String(v).split(/,\s*/)) push(part.trim().split(/\s+/)[0]);
                    };
                    for (const img of document.querySelectorAll('img')) {
                        const values = [img.currentSrc, img.src, img.dataset.src, img.dataset.original,
                            img.dataset.originalSrc, img.dataset.originalFile, img.dataset.full, img.dataset.fullImage,
                            img.dataset.hires, img.dataset.highRes, img.dataset.zoom, img.dataset.zoomImage,
                            img.dataset.large, img.dataset.largeImage, img.dataset.srcLarge, img.dataset.downloadUrl]
                            .filter(Boolean);
                        for (const v of values) push(v);
                        pushSet(img.srcset); pushSet(img.dataset.srcset); pushSet(img.dataset.lazySrcset);
                    }
                    for (const source of document.querySelectorAll('picture source')) {
                        push(source.src); pushSet(source.srcset); pushSet(source.dataset.srcset);
                    }
                    for (const a of document.querySelectorAll('a[download][href], a[data-download-url], a[href*="original"], a[href*="full"]')) {
                        push(a.href || a.dataset.downloadUrl);
                    }
                    for (const meta of document.querySelectorAll('meta[property="og:image"], meta[property="og:image:secure_url"], meta[name="twitter:image"], meta[name="twitter:image:src"]')) {
                        push(meta.content);
                    }
                    for (const link of document.querySelectorAll('link[rel="image_src"], link[rel="preload"][as="image"]')) {
                        push(link.href); pushSet(link.imageSrcset);
                    }
                    for (const el of document.querySelectorAll('[style*="url("], [style*="background"]')) {
                        const bg = getComputedStyle(el).backgroundImage || '';
                        for (const m of bg.matchAll(/url\(["']?([^"')]+)["']?\)/g)) push(m[1]);
                    }
                    return [...new Set(out)].slice(0, 2000);
                }''')
                combined = list(network_media) + [x for x in media if isinstance(x, str)]
                seen_media = set()
                self.last_image_candidates = []
                for item in combined:
                    if isinstance(item, str) and item.startswith(('http://', 'https://')) and item not in seen_media:
                        seen_media.add(item)
                        self.last_image_candidates.append(item)
                        if len(self.last_image_candidates) >= 2000:
                            break
            except Exception:
                self.last_image_candidates = []

            if dismiss_public_modals:
                self._dismiss_public_modal(page)
            html = page.content()
            self.last_url = page.url
            # Keep the ordinary rendered-page session consistent with subsequent
            # direct binary downloads. Some public CDNs require a benign session
            # cookie set by the presentation page even though no login is involved.
            if self.http is not None:
                try:
                    for cookie in self.context.cookies():
                        self.http.session.cookies.set(
                            cookie.get('name'), cookie.get('value'),
                            domain=cookie.get('domain') or None,
                            path=cookie.get('path') or '/',
                        )
                except Exception:
                    pass
            check_access(html, page.url)
            return html
        except ScrapeError:
            raise
        except Exception as e:
            if denied:
                raise denied[0] from e
            raise ScrapeError(Status.NETWORK_ERROR, f'Browser navigation failed: {url}: {e}') from e
        finally:
            page.close()

    def close(self) -> None:
        if self.context:
            self.context.close()
        if self.browser:
            self.browser.close()
        if self.playwright:
            self.playwright.stop()
        self.context = self.browser = self.playwright = None
