import logging
import random
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urlsplit, urljoin, parse_qsl, urlencode, urlunsplit
import requests
try:
    from protego import Protego  # type: ignore
except ImportError:  # compact Protego-compatible fallback for minimal/offline installs
    import re as _robots_re
    from urllib.parse import urlsplit as _robots_urlsplit

    class Protego:
        def __init__(self, groups):
            self.groups = groups
        @classmethod
        def parse(cls, text):
            groups, current = [], None
            for raw in text.splitlines():
                line = raw.split('#', 1)[0].strip()
                if not line or ':' not in line:
                    continue
                key, value = [x.strip() for x in line.split(':', 1)]
                key = key.lower()
                if key == 'user-agent':
                    if current is None or current.get('rules') or current.get('delay') is not None:
                        current = {'agents': [], 'rules': [], 'delay': None}; groups.append(current)
                    current['agents'].append(value.lower())
                elif current is not None and key in {'allow', 'disallow'}:
                    if value or key == 'allow':
                        current['rules'].append((key == 'allow', value))
                elif current is not None and key == 'crawl-delay':
                    try: current['delay'] = float(value)
                    except ValueError: pass
            return cls(groups)
        def _groups(self, user_agent):
            ua = user_agent.lower()
            specific = [g for g in self.groups if any(a != '*' and a in ua for a in g['agents'])]
            return specific or [g for g in self.groups if '*' in g['agents']]
        @staticmethod
        def _match(path, pattern):
            if pattern == '': return None
            end = pattern.endswith('$')
            if end: pattern = pattern[:-1]
            regex = '^' + _robots_re.escape(pattern).replace(r'\*', '.*') + ('$' if end else '')
            return _robots_re.search(regex, path)
        def can_fetch(self, url, user_agent):
            path = _robots_urlsplit(url).path or '/'
            if _robots_urlsplit(url).query: path += '?' + _robots_urlsplit(url).query
            matches = []
            for group in self._groups(user_agent):
                for allow, pattern in group['rules']:
                    if self._match(path, pattern):
                        matches.append((len(pattern.replace('*','')), allow))
            if not matches: return True
            longest = max(length for length, _ in matches)
            # Allow wins when equally specific, matching RFC 9309 behavior.
            return any(allow for length, allow in matches if length == longest)
        def crawl_delay(self, user_agent):
            for group in self._groups(user_agent):
                if group['delay'] is not None: return group['delay']
            return None

from ..config import USER_AGENT, MAX_RETRIES
from ..exceptions import ScrapeError
from ..models import Status

log = logging.getLogger(__name__)

def public_url(url: str) -> str:
    p = urlsplit(url)
    query = urlencode([(key, '[REDACTED]' if any(word in key.lower() for word in
                      ('key', 'token', 'secret', 'signature', 'password', 'state', 'code')) else value)
                       for key, value in parse_qsl(p.query, keep_blank_values=True)])
    return urlunsplit((p.scheme, p.netloc, p.path, query, ''))

def validate_url(url: str) -> str:
    p = urlsplit(url)
    if p.scheme not in ('http', 'https') or not p.hostname or p.username or p.password:
        raise ScrapeError(Status.UNSUPPORTED, 'Expected an HTTP(S) URL without credentials')
    return url

class HttpFetcher:
    """Sequential shared session: at most one active request per job/domain."""
    def __init__(self, delay: float = 0.75, respect_robots: bool = True):
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': USER_AGENT})
        self.delay = delay
        self.base_delay = delay
        self.domain_delay: dict[str, float] = {}
        self.success_streak: dict[str, int] = {}
        self.respect_robots = respect_robots
        self.last: dict[str, float] = {}
        self.robots: dict[str, Protego] = {}
        self.robots_errors: dict[str, ScrapeError] = {}
        self.robots_results: dict[str, str] = {}
        self.robots_sitemaps: dict[str, list[str]] = {}
        self.history: list[dict] = []
        self.cache: dict[str, requests.Response] = {}

    def _effective_delay(self, url: str) -> float:
        domain = urlsplit(url).netloc
        return max(self.delay, self.domain_delay.get(domain, self.delay))

    @staticmethod
    def _retry_after_seconds(value: str) -> float | None:
        if not value:
            return None
        try:
            return max(0.0, float(value))
        except ValueError:
            try:
                return max(0.0, (parsedate_to_datetime(value) - datetime.now(timezone.utc)).total_seconds())
            except (ValueError, TypeError, OverflowError):
                return None

    def _note_response(self, url: str, status_code: int, headers=None) -> None:
        """Adjust per-domain pacing from explicit server pressure signals.

        403 is never auto-retried here. 429/5xx increase the delay for later
        requests; sustained successful responses slowly recover toward the
        configured base delay. This is load control, not access-control evasion.
        """
        domain = urlsplit(url).netloc
        current = self.domain_delay.get(domain, self.delay)
        headers = headers or {}
        if status_code == 429:
            retry_after = self._retry_after_seconds(headers.get('Retry-After', ''))
            target = max(current * 2 if current else 1.0, 1.0)
            if retry_after is not None:
                target = max(target, min(retry_after, 30.0))
            self.domain_delay[domain] = min(30.0, max(self.delay, target))
            self.success_streak[domain] = 0
        elif status_code >= 500:
            self.domain_delay[domain] = min(15.0, max(self.delay, current * 1.5, self.delay + 0.25))
            self.success_streak[domain] = 0
        elif status_code == 403:
            # Preserve the existing no-retry behavior, but slow any later public
            # requests to the same domain if the caller continues for another URL.
            self.domain_delay[domain] = min(15.0, max(self.delay, current * 1.5, self.delay + 0.5))
            self.success_streak[domain] = 0
        elif 200 <= status_code < 400:
            streak = self.success_streak.get(domain, 0) + 1
            self.success_streak[domain] = streak
            if streak >= 10 and current > self.delay:
                self.domain_delay[domain] = max(self.delay, current * 0.8)
                self.success_streak[domain] = 0

    def throttle(self, url: str) -> None:
        domain = urlsplit(url).netloc
        delay = self._effective_delay(url)
        wait = delay - (time.monotonic() - self.last.get(domain, 0))
        if wait > 0:
            time.sleep(wait)
        self.last[domain] = time.monotonic()

    def _raw(self, url: str, timeout=30, headers=None) -> requests.Response:
        for attempt in range(max(1, MAX_RETRIES)):
            self.throttle(url)
            try:
                r = self.session.get(url, timeout=timeout, headers=headers, allow_redirects=False, stream=True)
                chunks, size = [], 0
                for chunk in r.iter_content(65536):
                    size += len(chunk)
                    if size > 50 * 1024 * 1024:
                        r.close()
                        raise ScrapeError(Status.DOWNLOAD_ERROR, f'Response exceeds 50 MiB: {public_url(url)}')
                    chunks.append(chunk)
                r._content = b''.join(chunks)
                r._content_consumed = True
                r.close()
            except requests.RequestException as e:
                if attempt + 1 == max(1, MAX_RETRIES):
                    raise ScrapeError(Status.NETWORK_ERROR, f'{public_url(url)}: {type(e).__name__}') from e
                time.sleep(min(8, 2 ** attempt + random.random()))
                continue
            self.history.append({'url': public_url(url), 'http_status': r.status_code})
            self._note_response(url, r.status_code, r.headers)
            log.debug('[HTTP] %s %s delay=%.2fs', r.status_code, public_url(url), self._effective_delay(url))
            if r.status_code != 429 and r.status_code < 500:
                return r
            if attempt + 1 == max(1, MAX_RETRIES):
                return r
            retry = r.headers.get('Retry-After', '')
            parsed_retry = self._retry_after_seconds(retry)
            wait = parsed_retry if parsed_retry is not None else 2 ** attempt + random.random()
            # Do not retry earlier than a long Retry-After; return the explicit error instead.
            if wait > 30:
                return r
            time.sleep(max(0, wait))
        raise AssertionError('unreachable')

    def check_robots(self, url: str) -> None:
        validate_url(url)
        if not self.respect_robots:
            self.robots_results[public_url(url)] = 'DISABLED'
            return
        p = urlsplit(url)
        origin = f'{p.scheme}://{p.netloc}'
        if origin in self.robots_errors:
            raise self.robots_errors[origin]
        if origin not in self.robots:
            robots_url = origin + '/robots.txt'
            for _ in range(6):
                r = self._raw(robots_url, timeout=10)
                if r.is_redirect:
                    robots_url = validate_url(urljoin(robots_url, r.headers['Location']))
                else:
                    break
            if r.status_code in (404, 410):
                policy = ''
            elif r.status_code == 200 and not r.text.lstrip().lower().startswith(('<html', '<!doctype')):
                policy = r.text
            else:
                try:
                    self.raise_status(r)
                    raise ScrapeError(Status.TEMPORARILY_UNAVAILABLE, f'Cannot establish robots policy: {robots_url}')
                except ScrapeError as e:
                    self.robots_errors[origin] = e
                    self.robots_results[public_url(url)] = e.status.value
                    raise
            self.robots[origin] = Protego.parse(policy)
            self.robots_sitemaps[origin] = [
                line.split(':', 1)[1].strip() for line in policy.splitlines()
                if line.strip().lower().startswith('sitemap:') and line.split(':', 1)[1].strip()
            ]
        parser = self.robots[origin]
        allowed = parser.can_fetch(url, USER_AGENT)
        self.robots_results[public_url(url)] = 'ALLOWED' if allowed else 'ROBOTS_DISALLOWED'
        crawl_delay = parser.crawl_delay(USER_AGENT)
        if crawl_delay:
            self.delay = max(self.delay, float(crawl_delay))
        if not allowed:
            raise ScrapeError(Status.ROBOTS_DISALLOWED, f'robots.txt disallows {public_url(url)}')

    @staticmethod
    def raise_status(r) -> None:
        code = r.status_code
        if code < 400:
            return
        status = {401: Status.LOGIN_REQUIRED, 403: Status.BLOCKED, 429: Status.RATE_LIMITED,
                  404: Status.UNSUPPORTED, 410: Status.UNSUPPORTED}.get(code)
        status = status or (Status.TEMPORARILY_UNAVAILABLE if code >= 500 else Status.NETWORK_ERROR)
        raise ScrapeError(status, f'HTTP {code}: {public_url(r.url)}')

    def get(self, url: str, timeout=30, headers=None, cached=False):
        validate_url(url)
        if cached and url in self.cache:
            return self.cache[url]
        original = url
        for _ in range(10):
            self.check_robots(url)
            r = self._raw(url, timeout, headers)
            if r.is_redirect:
                url = validate_url(urljoin(url, r.headers['Location']))
                continue
            self.raise_status(r)
            if cached:
                self.cache[original] = r
            return r
        raise ScrapeError(Status.NETWORK_ERROR, f'Too many redirects: {public_url(original)}')

    def get_asset(self, url: str, timeout=30, headers=None, *, official_api_asset=False):
        """Fetch a directly referenced public binary asset.

        Page discovery/navigation is governed by ``get`` and the job robots policy.
        Once an allowed page (or an official API response) explicitly publishes an
        image URL, downloading that exact binary does not crawl the CDN namespace,
        so we do not perform a second robots.txt discovery against the asset host.
        HTTP authentication/challenge/status codes are still enforced normally and
        redirects are bounded. This prevents unrelated CDN robots endpoints from
        turning a valid product gallery into a false DOWNLOAD_ERROR.
        """
        validate_url(url)
        original = url
        for _ in range(10):
            r = self._raw(url, timeout, headers)
            if r.is_redirect:
                url = validate_url(urljoin(url, r.headers['Location']))
                continue
            self.raise_status(r)
            return r
        raise ScrapeError(Status.NETWORK_ERROR, f'Too many redirects: {public_url(original)}')

    def close(self) -> None:
        self.session.close()
