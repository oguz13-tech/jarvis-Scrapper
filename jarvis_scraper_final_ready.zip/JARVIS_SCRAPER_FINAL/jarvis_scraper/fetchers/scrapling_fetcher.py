class ScraplingFetcher:
    def fetch(self,url):
        try:
            from scrapling.fetchers import Fetcher
        except ImportError as e:
            raise RuntimeError('Install with: pip install "scrapling[fetchers]" && scrapling install') from e
        page=Fetcher.get(url)
        return getattr(page,"html_content",str(page))
