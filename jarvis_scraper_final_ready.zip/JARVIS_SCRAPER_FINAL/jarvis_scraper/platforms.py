"""Runtime platform fingerprinting.

Fingerprints are hints, never hard requirements. The detector intentionally uses
multiple weak signals instead of assuming a domain always runs one stack.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import re
from urllib.parse import urlsplit
from bs4 import BeautifulSoup


@dataclass
class PlatformFingerprint:
    platform: str = "unknown"
    scores: dict[str, float] = field(default_factory=dict)
    signals: list[str] = field(default_factory=list)
    site_type: str = "gallery_or_unknown"

    def add(self, name: str, score: float, signal: str) -> None:
        if score > self.scores.get(name, 0.0):
            self.scores[name] = score
        self.signals.append(f"{name}:{signal}")

    def finalize(self) -> "PlatformFingerprint":
        if self.scores:
            self.platform = max(self.scores, key=self.scores.get)
        if self.platform in {
            "shopify", "woocommerce", "magento", "prestashop", "opencart",
            "bigcommerce", "salesforce_commerce", "etsy_like",
        }:
            self.site_type = "ecommerce"
        elif self.platform in {"wordpress", "nextjs", "nuxt", "react_spa"}:
            self.site_type = "dynamic_or_cms"
        return self


def detect_platform(url: str, html: str | None) -> PlatformFingerprint:
    fp = PlatformFingerprint()
    if not html:
        return fp
    h = html.lower()
    soup = BeautifulSoup(html, "lxml")

    # Shopify. A Shopify CDN URL alone is weak evidence: shopify.com itself
    # serves stock-photo assets from Shopify CDNs without being a merchant storefront.
    if any(x in h for x in ("shopify-section", "shopify.theme", "shopify-payment-button")):
        fp.add("shopify", 0.99, "theme marker")
    elif "cdn.shopify.com" in h:
        fp.add("shopify", 0.60, "cdn-only marker")
    if soup.select_one("form[action*='/cart/add']"):
        fp.add("shopify", 0.96, "cart/add form")

    # WooCommerce / WordPress
    if any(x in h for x in ("woocommerce", "wc-ajax", "wp-content/plugins/woocommerce", "wc-block-")):
        fp.add("woocommerce", 0.98, "woocommerce marker")
    if any(x in h for x in ("wp-content/", "wp-includes/", "wp-json")):
        fp.add("wordpress", 0.82, "wordpress assets")

    # Magento 2 / Adobe Commerce
    if any(x in h for x in ("mage/cookies", "magento_", "x-magento-init", "mage-cache-storage")):
        fp.add("magento", 0.97, "magento marker")
    if soup.select_one("script[type='text/x-magento-init']"):
        fp.add("magento", 0.99, "x-magento-init")

    # PrestaShop
    if any(x in h for x in ("prestashop", "prestashop.page", "modules/ps_")):
        fp.add("prestashop", 0.96, "prestashop marker")

    # OpenCart
    if any(x in h for x in ("route=product/product", "index.php?route=product", "catalog/view/theme")):
        fp.add("opencart", 0.94, "opencart route/theme")

    # BigCommerce
    if any(x in h for x in ("stencil-utils", "bigcommerce", "cdn11.bigcommerce.com")):
        fp.add("bigcommerce", 0.95, "bigcommerce marker")

    # Salesforce Commerce Cloud
    if any(x in h for x in ("demandware", "dwcont", "on/demandware.store")):
        fp.add("salesforce_commerce", 0.95, "demandware marker")

    # Modern JS frameworks
    if soup.select_one("script#__NEXT_DATA__") or "/_next/" in h:
        fp.add("nextjs", 0.92, "next data/assets")
    if "__nuxt__" in h or "/_nuxt/" in h:
        fp.add("nuxt", 0.90, "nuxt state/assets")
    if any(x in h for x in ("data-reactroot", "__react", "react-dom")):
        fp.add("react_spa", 0.68, "react marker")

    # Generic structured commerce evidence. This is intentionally not a named platform.
    ld = soup.select("script[type='application/ld+json']")
    if ld and re.search(r'"@type"\s*:\s*"Product"', html, re.I):
        fp.add("structured_commerce", 0.72, "JSON-LD Product")
        fp.site_type = "ecommerce"
    if soup.select_one("[itemtype*='schema.org/Product'], [itemprop='price'], meta[property='product:price:amount']"):
        fp.add("structured_commerce", 0.70, "schema/product price")
        fp.site_type = "ecommerce"

    # Domain/path is a weak fallback only.
    path = urlsplit(url).path.lower()
    if re.search(r"/(product|products|urun|urunler|listing|shop)/", path):
        fp.site_type = "ecommerce"

    return fp.finalize()
