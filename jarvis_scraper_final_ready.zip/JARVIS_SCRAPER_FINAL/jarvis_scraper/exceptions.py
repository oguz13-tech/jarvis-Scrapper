from .models import Status

class ScrapeError(Exception):
    def __init__(self, status: Status, message: str):
        super().__init__(message)
        self.status = status

STOP_STATUSES = {Status.BLOCKED, Status.LOGIN_REQUIRED, Status.RATE_LIMITED,
                 Status.ROBOTS_DISALLOWED, Status.TEMPORARILY_UNAVAILABLE, Status.STOPPED}

def check_access(html: str, url: str) -> None:
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'lxml')
    title = soup.title.get_text(' ', strip=True).lower() if soup.title else ''
    if any(s in title for s in ('just a moment', 'access denied', 'verify you are human', 'captcha')):
        raise ScrapeError(Status.BLOCKED, f'Access challenge: {url} ({title})')
    if '/login' in url or '/signin' in url or title.startswith(('log in', 'login', 'sign in')):
        raise ScrapeError(Status.LOGIN_REQUIRED, f'Login wall: {url}')
