import hashlib
import re
from urllib.parse import urlsplit

def safe_name(value: str) -> str:
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '-', str(value)).strip(' .-')[:90].rstrip(' .')
    if not name or name in {'.', '..'}:
        name = 'item'
    if re.fullmatch(r'(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?', name, re.I):
        name = '_' + name
    return name

def suffix(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()[:10]

def job_name(url: str) -> str:
    p = urlsplit(url)
    return safe_name(p.path.rstrip('/').split('/')[-1] or 'root') + '-' + suffix(url)
