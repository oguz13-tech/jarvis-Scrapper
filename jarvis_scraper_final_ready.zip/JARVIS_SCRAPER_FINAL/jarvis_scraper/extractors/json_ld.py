import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from ..models import Product, ImageAsset

def extract_jsonld_products(html: str, base_url: str) -> list[Product]:
    soup, products, seen = BeautifulSoup(html, 'lxml'), [], set()
    def nodes(value):
        if isinstance(value, list):
            for item in value:
                yield from nodes(item)
        elif isinstance(value, dict):
            yield value
            for key in ('@graph', 'mainEntity', 'itemListElement', 'item'):
                if key in value:
                    yield from nodes(value[key])
    for script in soup.find_all('script', attrs={'type': 'application/ld+json'}):
        try:
            data = json.loads(script.string or script.get_text())
        except (ValueError, TypeError):
            continue
        for node in nodes(data):
            types = node.get('@type', [])
            if isinstance(types, str):
                types = [types]
            if 'Product' not in types:
                continue
            url = urljoin(base_url, node.get('url') or base_url)
            if url in seen:
                continue
            seen.add(url)
            brand = node.get('brand') or {}
            p = Product(name=node.get('name') or 'Unnamed', url=url, id=str(node.get('productID') or node.get('sku') or url),
                        sku=node.get('sku'), description=node.get('description'),
                        vendor=brand.get('name') if isinstance(brand, dict) else str(brand),
                        metadata={key: value for key, value in node.items() if key != 'image'})
            images = node.get('image') or []
            if isinstance(images, (str, dict)):
                images = [images]
            for candidate in images:
                if isinstance(candidate, dict):
                    candidate = candidate.get('contentUrl') or candidate.get('url')
                if isinstance(candidate, str):
                    image_url = urljoin(base_url, candidate)
                    if image_url.startswith(('https://', 'http://')):
                        p.images.append(ImageAsset(url, image_url, original_url=image_url, source_strategy='jsonld'))
            products.append(p)
    return products
