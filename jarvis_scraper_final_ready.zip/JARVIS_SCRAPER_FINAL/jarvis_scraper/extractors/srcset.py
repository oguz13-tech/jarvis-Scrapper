import re

_DESCRIPTOR = re.compile(r'^(\d+(?:\.\d+)?)(w|x)$')


def _parts(srcset: str) -> list[str]:
    """Split a srcset without corrupting CDN URLs that contain literal commas.

    Most browsers/templating engines serialize candidate separators as comma +
    whitespace. CDN transform paths (notably Wix/DeviantArt) often contain
    commas with *no* whitespace, so a naive ``split(',')`` turns one valid URL
    into bogus requests such as ``/h_700`` or ``/q_70``.
    """
    text = (srcset or '').strip()
    if not text:
        return []
    parts = [p.strip() for p in re.split(r',(?=\s+)', text) if p.strip()]
    # Compact serializers occasionally omit whitespace between normal
    # candidates. Only use the legacy split when every resulting segment has
    # an explicit valid descriptor; otherwise preserve the comma-containing URL.
    if len(parts) == 1 and ',' in text:
        raw = [p.strip() for p in text.split(',') if p.strip()]
        if len(raw) > 1 and all(len(p.split()) == 2 and _DESCRIPTOR.fullmatch(p.split()[1]) for p in raw):
            parts = raw
    return parts


def _rank(srcset: str) -> list[tuple[float, str]]:
    candidates = []
    for raw in _parts(srcset):
        bits = raw.rsplit(None, 1)
        if not bits or bits[0].startswith('data:'):
            continue
        score = 1.0
        url = bits[0]
        if len(bits) == 2:
            match = _DESCRIPTOR.fullmatch(bits[1])
            if match:
                if float(match[1]) <= 0:
                    continue
                score = float(match[1]) * (10000 if match[2] == 'x' else 1)
            else:
                # No recognized descriptor: the entire raw token is the URL.
                # This is important for URLs that themselves contain spaces only
                # after escaping; malformed candidates are ignored conservatively.
                if any(ch.isspace() for ch in raw):
                    continue
                url = raw
        candidates.append((score, url))
    return candidates


def best_srcset(srcset: str) -> str | None:
    candidates = _rank(srcset)
    return max(candidates, key=lambda x: x[0])[1] if candidates else None


def ranked_srcset(srcset: str) -> list[str]:
    """Return srcset URLs from highest to lowest declared resolution/density."""
    out, seen = [], set()
    for _, url in sorted(_rank(srcset), key=lambda x: x[0], reverse=True):
        if url not in seen:
            seen.add(url)
            out.append(url)
    return out
