from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urljoin, urlsplit, urlunsplit
from bs4 import BeautifulSoup

NEXT_SELECTORS = (
    "a[rel='next']", "link[rel='next']", "a.next", ".pagination a.next", ".pagination__next",
    "a.next.page-numbers", "a[aria-label*='Next' i]", "a[aria-label*='Sonraki' i]",
    "a[title*='Next' i]", "a[title*='Sonraki' i]", "li.next a", ".pager-next a",
)


def next_page(html: str, current_url: str) -> str | None:
    soup = BeautifulSoup(html, "lxml")
    host = urlsplit(current_url).hostname
    for selector in NEXT_SELECTORS:
        node = soup.select_one(selector)
        if node and node.get("href"):
            target = urljoin(current_url, node["href"])
            if urlsplit(target).hostname == host and target != current_url:
                return target
    # Text fallback, deliberately narrow.
    for a in soup.find_all("a", href=True):
        text = a.get_text(" ", strip=True).lower()
        if text in {"next", "next ›", "next »", "sonraki", "sonraki ›", "sonraki »", "→", ">", "»"}:
            target = urljoin(current_url, a["href"])
            if urlsplit(target).hostname == host and target != current_url:
                return target
    return None


def increment_page_url(url: str, page: int) -> str | None:
    """Return a conservative next-page candidate when the URL already exposes a page token."""
    p = urlsplit(url)
    path = p.path
    patterns = [
        (r"(/page/)(\d+)(?=/|$)", rf"\g<1>{page}"),
        (r"(/page-)(\d+)(?=/|$)", rf"\g<1>{page}"),
        (r"(/p/)(\d+)(?=/|$)", rf"\g<1>{page}"),
    ]
    for pattern, repl in patterns:
        if re.search(pattern, path, re.I):
            return urlunsplit((p.scheme, p.netloc, re.sub(pattern, repl, path, flags=re.I), p.query, ""))
    params = dict(parse_qsl(p.query, keep_blank_values=True))
    for key in ("page", "p", "pg", "pageNumber", "currentPage"):
        if key in params:
            params[key] = str(page)
            return urlunsplit((p.scheme, p.netloc, p.path, urlencode(params), ""))
    return None
