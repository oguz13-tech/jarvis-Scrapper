import json
import re
from urllib.parse import urljoin, urlsplit
from bs4 import BeautifulSoup
from .srcset import ranked_srcset
from .quality import is_probable_ui_asset, candidate_score, dedupe_urls
from ..models import ImageAsset

IMG_ATTRS = [
    'data-download-url', 'data-original-file', 'data-zoom-image', 'data-full-image', 'data-full',
    'data-hires', 'data-high-res', 'data-src-large', 'data-large-image', 'data-large',
    'data-original-src', 'data-original', 'data-lazy-src', 'data-image', 'data-zoom',
    'data-src', 'src',
]
IMAGE_KEYS = {
    'image', 'images', 'imageurl', 'contenturl', 'original', 'originalurl', 'largeimageurl',
    'full', 'fullsize', 'full_size', 'hires', 'highres', 'downloadurl', 'download_url', 'media', 'photos',
}


def extract_images(html: str, base_url: str, strategy: str = 'static') -> list[ImageAsset]:
    soup = BeautifulSoup(html, 'lxml')
    out, seen = [], set()

    def add(url, alt=None, title=None, alternatives=None, classes=None):
        if not isinstance(url, str) or not url.strip() or url.strip().startswith('data:'):
            return
        url = urljoin(base_url, url.strip().replace('\\/', '/'))
        if urlsplit(url).scheme not in {'http', 'https'}:
            return
        if is_probable_ui_asset(url, alt=alt, title=title, classes=classes) or url in seen:
            return
        candidates = []
        for raw in alternatives or []:
            if not isinstance(raw, str) or not raw.strip() or raw.strip().startswith('data:'):
                continue
            candidate = urljoin(base_url, raw.strip().replace('\\/', '/'))
            if urlsplit(candidate).scheme not in {'http', 'https'}:
                continue
            if is_probable_ui_asset(candidate, alt=alt, title=title, classes=classes):
                continue
            if candidate != url:
                candidates.append(candidate)
        # Preserve published preference order but remove duplicates.
        candidates = dedupe_urls(candidates)
        seen.add(url)
        out.append(ImageAsset(
            base_url, url, original_url=url, alt_text=alt, title=title,
            source_strategy=strategy, candidate_urls=candidates,
        ))

    for img in soup.find_all('img'):
        if img.find_parent('noscript'):
            continue
        try:
            declared_w = int(str(img.get('width') or '').strip())
        except ValueError:
            declared_w = 0
        try:
            declared_h = int(str(img.get('height') or '').strip())
        except ValueError:
            declared_h = 0
        if declared_w and declared_h and declared_w < 80 and declared_h < 80:
            continue
        classes = ' '.join(img.get('class', []))
        alt, title = img.get('alt'), img.get('title')
        srcset = (
            img.get('data-srcset') or img.get('data-lazy-srcset') or
            img.get('data-responsive-srcset') or img.get('srcset') or ''
        )
        ordered = ranked_srcset(srcset)
        attrs = [img.get(attr) for attr in IMG_ATTRS if img.get(attr) and not str(img.get(attr)).startswith('data:')]
        parent = img.find_parent('a', href=True)
        direct = None
        if parent:
            href = parent.get('href') or ''
            # Direct image/download links are useful; normal detail links are handled elsewhere.
            if re.search(r'\.(?:jpg|jpeg|png|webp|avif|gif|svg)(?:\?|$)', href, re.I) or parent.has_attr('download'):
                direct = href
        all_candidates = dedupe_urls(([direct] if direct else []) + ordered + attrs)
        if not all_candidates:
            continue
        # Highest declared srcset/data-full candidate should be primary.
        ranked = sorted(
            enumerate(all_candidates),
            key=lambda pair: (candidate_score(
                urljoin(base_url, pair[1]), alt=alt, title=title, classes=classes,
                direct_download=bool(direct and pair[1] == direct),
            ), -pair[0]),
            reverse=True,
        )
        primary = ranked[0][1]
        alternatives = [value for value in all_candidates if value != primary]
        add(primary, alt, title, alternatives, classes)
        # Published alternate product renders, not fabricated URL rewrites.
        for attr in ('data-print-src', 'data-canvas-src'):
            add(img.get(attr), alt, title, classes=classes)

    for source in soup.select('picture source'):
        source_set = source.get('srcset') or source.get('data-srcset') or source.get('data-lazy-srcset') or ''
        ordered = ranked_srcset(source_set)
        values = dedupe_urls(ordered + ([source.get('src')] if source.get('src') else []))
        if values:
            add(values[0], alternatives=values[1:])

    # Commerce/gallery elements frequently keep the original URL in data-* attributes.
    for node in soup.select(
        '[data-zoom-image], [data-large-image], [data-full-image], [data-image], [data-original], '
        '[data-download-url], [data-original-file]'
    ):
        if node.name == 'img':
            continue
        values = [node.get(k) for k in (
            'data-download-url', 'data-original-file', 'data-zoom-image', 'data-full-image',
            'data-large-image', 'data-original', 'data-image'
        ) if node.get(k)]
        if values:
            add(values[0], alternatives=values[1:], classes=' '.join(node.get('class', [])))

    # Explicit download anchors may point straight at the public full-size asset.
    for node in soup.select('a[download][href], a[data-download-url], [data-download-url]'):
        raw = node.get('href') or node.get('data-download-url')
        add(raw, title=node.get_text(' ', strip=True), classes=' '.join(node.get('class', [])))

    for meta in soup.find_all('meta'):
        key = (meta.get('property') or meta.get('name') or '').lower()
        if key in {
            'og:image', 'og:image:secure_url', 'twitter:image', 'twitter:image:src',
            'og:image:url', 'image',
        }:
            add(meta.get('content'))

    for tag in soup.find_all(style=True):
        classes = ' '.join(tag.get('class', []))
        for match in re.finditer(r"url\(['\"]?([^)'\"]+)", tag['style']):
            add(match[1], classes=classes)

    def visit(node, image_context=False):
        if isinstance(node, dict):
            # Sized maps: pick the largest public record and preserve the others as alternatives.
            if image_context and node and all(isinstance(v, dict) for v in node.values()):
                sized = [v for v in node.values() if v.get('url') and (v.get('width') or v.get('height'))]
                if sized:
                    ranked = sorted(
                        sized,
                        key=lambda v: float(v.get('width') or 0) * float(v.get('height') or v.get('width') or 0),
                        reverse=True,
                    )
                    add(ranked[0]['url'], alternatives=[v.get('url') for v in ranked[1:]])
                    return
            for key, value in node.items():
                normalized = str(key).lower().replace('_', '').replace('-', '')
                next_context = image_context or normalized in {k.replace('_', '') for k in IMAGE_KEYS}
                if next_context and normalized in {'url', 'src', 'source', 'contenturl', 'originalurl'}:
                    add(value)
                else:
                    visit(value, next_context)
        elif isinstance(node, list):
            for value in node:
                visit(value, image_context)
        elif image_context:
            add(node)

    for script in soup.find_all('script'):
        text = script.string or script.get_text() or ''
        if script.get('type') in {'application/json', 'application/ld+json'} or script.get('id') in {
            '__NEXT_DATA__', '__PWS_DATA__', '__APOLLO_STATE__', '__PRELOADED_STATE__', '__JARVIS_BROWSER_MEDIA__'
        }:
            try:
                visit(json.loads(text))
            except (ValueError, TypeError):
                pass
        # Conservative fallback for JS assignment blobs. Commas inside URLs are preserved
        # because the regex consumes the complete quoted string.
        for match in re.finditer(
            r'''["']((?:https?:)?//[^"'\\\s]+?\.(?:jpe?g|png|webp|avif|gif|svg)(?:\?[^"'\\\s]*)?|/[^"'\\\s]+?\.(?:jpe?g|png|webp|avif|gif|svg)(?:\?[^"'\\\s]*)?)["']''',
            text, re.I,
        ):
            add(match.group(1).replace('\\/', '/'))

    return out
