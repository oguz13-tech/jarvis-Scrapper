from bs4 import BeautifulSoup

def extract_og(html: str) -> dict:
    soup=BeautifulSoup(html,"lxml")
    out={}
    for m in soup.find_all("meta"):
        k=(m.get("property") or m.get("name") or "").lower()
        if k.startswith("og:") or k.startswith("twitter:"):
            out[k]=m.get("content")
    return out
