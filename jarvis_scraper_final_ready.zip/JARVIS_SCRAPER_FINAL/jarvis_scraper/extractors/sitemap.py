from __future__ import annotations

import re
from xml.etree import ElementTree
from urllib.parse import urljoin, urlsplit

PRODUCTISH = re.compile(
    r'/(?:products?|product|urun|urunler|listing|listings|p)/|'
    r'[-_/](?:product|urun)[-_/]|-p-\d+(?:[./?#]|$)|[?&](?:product_id|productId)=',
    re.I,
)


def parse_sitemap(content: bytes) -> tuple[list[str], bool]:
    """Return (locations, is_index). Handles regular XML sitemap formats."""
    try:
        root = ElementTree.fromstring(content)
    except ElementTree.ParseError:
        return [], False
    tag = root.tag.split('}')[-1].lower()
    is_index = tag == 'sitemapindex'
    out = []
    for node in root.iter():
        if node.tag.split('}')[-1].lower() == 'loc' and node.text:
            value = node.text.strip()
            if value.startswith(('http://', 'https://')):
                out.append(value)
    return out, is_index


def product_urls(urls: list[str], base_url: str, limit: int = 500) -> list[str]:
    host = urlsplit(base_url).hostname
    out, seen = [], set()
    for url in urls:
        if urlsplit(url).hostname != host or url in seen:
            continue
        if PRODUCTISH.search(urlsplit(url).path + ('?' + urlsplit(url).query if urlsplit(url).query else '')):
            seen.add(url); out.append(url)
            if len(out) >= limit:
                break
    return out


def choose_child_sitemaps(urls: list[str], limit: int = 3) -> list[str]:
    preferred = [u for u in urls if re.search(r'(product|urun|item|listing)', u, re.I)]
    return (preferred or urls)[:limit]
