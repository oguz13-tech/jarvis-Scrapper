import re
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlsplit
from .html_images import extract_images
from .embedded_state import extract_embedded_products

GALLERIES = (
    'media-gallery', '[data-product-gallery]', '.woocommerce-product-gallery',
    '.product__media-list', '.product-single__photos', '.product-gallery',
    '.product-images', '#product-gallery', '[itemprop="associatedMedia"]',
    '.fotorama', '[data-gallery-role="gallery-placeholder"]', '.gallery-placeholder',
    '.product-cover', '.product-images', '.images-container', '.product-left',
    '#content .thumbnails', '.product-info .image', '.product-info .image-additional',
    '[data-testid*="listing-page-image"]', '[data-testid*="image-carousel"]',
    '.productView-images', '.productView-image', '.productView-thumbnails',
    '.js-qv-product-images', '.images-container .product-images', '.product-image-container',
    '.carousel-inner', '.gallery-container', '.product-slide', '[data-carousel-pane]',
    '.slick-slider', '.swiper-wrapper', '.splide__list', '.glide__slides',
    '[data-listing-page-image]', '[data-listing-image]', '[data-image-carousel]',
    '.gallery-enlarged-image', '.image-container', '.product-image-gallery',
    '.base-product-image', '.gallery-modal-content', '.product-detail-image-container',
)


CARD_SELECTORS = (
    '.product', '.product-card', '.product-item', '.product-tile', '.product-grid-item',
    '.grid-product', '.grid__item', 'li.product', '.products-grid .item',
    '.product-layout', '.product-thumb', '.product-miniature', '[data-product-id]',
    '.card-product', '.productGrid .card', '.productGrid-item', '.product-item-info',
    '.product-small', '.product-box', '.item-product', '.js-product-miniature',
    '[data-product-item]', '[data-testid*="product-card"]', '[data-testid*="listing-card"]',
    '[data-listing-id]', '.listing-card', '.wt-grid__item-xs-6', '.p-card-wrppr', '.prdct-cntnr-wrppr',
    '.product-card-container', '.product-item-container',
)


PRODUCT_PATH_RE = re.compile(
    r'/(?:products?|product-detail|product_details?|p|listing|listings|urun|urunler|ürün|magaza/urun|free-food-photo|stock-photos/photos)/'
    r'|/[^/?#]+-p-\d+(?:[/?#]|$)'
    r'|[?&](?:product_id|productId|route=product/product)=',
    re.I,
)

NEGATIVE_PATH = re.compile(
    r'/(?:collections?|categories?|category|search|tag|tags|account|login|signin|cart|basket|wishlist|blog|pages?|policies|help)(?:/|$)',
    re.I,
)


def _same_host(a: str, b: str) -> bool:
    return (urlsplit(a).hostname or '').lower() == (urlsplit(b).hostname or '').lower()


def product_links(html: str, base_url: str) -> list[str]:
    soup, out, seen = BeautifulSoup(html, 'lxml'), [], set()

    # Prefer anchors living in known product-card containers.
    for card in soup.select(','.join(CARD_SELECTORS)):
        ranked = []
        for anchor in card.select('a[href]'):
            href = anchor.get('href') or ''
            if not href or href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
                continue
            low = href.lower()
            if any(x in low for x in ('wishlist', 'compare', 'quickview', 'quick-view', 'add-to-cart', 'login')):
                continue
            url = urljoin(base_url, href.split('#')[0])
            if not _same_host(url, base_url) or NEGATIVE_PATH.search(urlsplit(url).path):
                continue
            score = 5 if PRODUCT_PATH_RE.search(href) else 0
            score += 2 if anchor.find('img') else 0
            score += 1 if anchor.get_text(' ', strip=True) else 0
            score += 1 if not urlsplit(url).query else 0
            ranked.append((score, url))
        for _, url in sorted(ranked, key=lambda x: x[0], reverse=True):
            if url not in seen:
                seen.add(url); out.append(url)
                break

    # Then accept strongly product-looking URLs outside cards.
    for anchor in soup.find_all('a', href=True):
        if anchor.find_parent(['nav', 'header', 'footer']):
            continue
        href = anchor['href']
        if any(word in href.lower() for word in ('login', 'signin', 'cart', 'account', 'add-to-cart', 'wishlist')):
            continue
        if not PRODUCT_PATH_RE.search(href):
            continue
        url = urljoin(base_url, href.split('#')[0])
        if _same_host(url, base_url) and not NEGATIVE_PATH.search(urlsplit(url).path) and url not in seen:
            seen.add(url); out.append(url)
    return out


def gallery_images(html: str, url: str):
    soup = BeautifulSoup(html, 'lxml')
    # A composed mockup's empty frame/background is not a product photograph.
    for node in soup.select('.mock-image__frame, .mock-image__frame-container'):
        node.attrs.pop('style', None)
    for node in soup.select('.mock-image__static, .pdp-title-chip__avatar'):
        node.decompose()
    areas = soup.select(','.join(GALLERIES))
    images = extract_images(''.join(str(area) for area in areas), url, 'product_gallery') if areas else []

    # Hydration state often has the full gallery even when DOM only has one lazy image.
    embedded = extract_embedded_products(html, url)
    current_path = urlsplit(url).path.rstrip('/')
    for product in embedded:
        ppath = urlsplit(product.url).path.rstrip('/')
        if product.url == url or not ppath or ppath == current_path:
            images.extend(product.images)

    out, seen = [], set()
    for image in images:
        if image.image_url not in seen:
            seen.add(image.image_url); out.append(image)
    return out


def product_region_images(html: str, url: str):
    """Fallback gallery extraction from the main product region.

    Used only when a caller already has product evidence. Related/recommended
    sections are removed to avoid assigning another product's images.
    """
    soup = BeautifulSoup(html, 'lxml')
    root = soup.select_one('main, [role="main"], #main, #content, .product-detail, .product-page') or soup
    noise = re.compile(r'(related|recommend|upsell|cross.?sell|recent|similar|also.?like|review|footer|header|breadcrumb|social|share|avatar|brand-logo)', re.I)
    for node in root.find_all(True):
        classes = ' '.join(node.get('class', []))
        marker = classes + ' ' + str(node.get('id', ''))
        if noise.search(marker):
            node.decompose()
    images = extract_images(str(root), url, 'product_region')
    # Product-region fallback should not explode on icon-heavy pages.
    return images[:80]
