from __future__ import annotations

import re
from urllib.parse import urlsplit, parse_qs

# Conservative UI/chrome markers. These are intentionally semantic and path based;
# they are not used to reject content solely because a filename contains a short word.
_UI_MARKERS = (
    '/icons/', '/icon/', '/logos/', '/logo/', '/avatars/', '/avatar/', '/badges/', '/badge/',
    '/emoji/', '/flags/', '/languages/', '/language/', '/social/', '/sprites/', '/sprite/', '/payments/', '/payment/',
    'fontawesome', 'favicon', 'apple-touch-icon', 'app-logo', 'site-logo', 'brand-logo',
    'social-', 'facebook.com/tr?', 'facebook-icon', 'instagram-icon', 'twitter-icon', 'tiktok-icon', 'youtube-icon',
    'pinterest-icon', 'linkedin-icon', 'whatsapp-icon', 'qr-', 'qrcode', 'tracking-pixel',
    'pixel.gif', 'spacer.gif', 'blank.gif', 'default.jpg', 'default.png', 'no-image', 'no_image',
    'placeholder', 'loading.gif', 'spinner', 'loader',
    'google-play', 'app-store', 'trustpilot', 'stars-rating', 'rating-star', 'verified-badge',
)
_TEXT_NOISE = re.compile(
    r'\b(?:logo|icon|avatar|badge|sprite|favicon|social|share|rating|star|payment|flag|emoji|'
    r'placeholder|loading|spinner|loader|qr\s*code|app\s*store|google\s*play)\b', re.I
)
_CONTENT_HINTS = re.compile(
    r'(?:original|full(?:size)?|full[-_ ]?res|high[-_ ]?res|download|wallpaper|photo|image|art|'
    r'product|gallery|media|render|poster|print|pattern|background|asset)', re.I
)
_PREVIEW_HINTS = re.compile(r'(?:thumb|thumbnail|preview|small|tiny|low[-_ ]?res|placeholder)', re.I)
_DIMENSION_RE = re.compile(r'(?<!\d)(\d{2,5})[xX×](\d{2,5})(?!\d)')


def is_svg(url: str) -> bool:
    return urlsplit(url).path.lower().endswith('.svg')


def is_probable_ui_asset(url: str, *, alt: str | None = None, title: str | None = None,
                         classes: str | None = None) -> bool:
    low = (url or '').lower()
    if any(marker in low for marker in _UI_MARKERS):
        return True
    semantic = ' '.join(x for x in (alt, title, classes) if x)
    if semantic and _TEXT_NOISE.search(semantic):
        # Do not reject a real photo whose alt text merely mentions a logo unless the URL
        # also looks like a small/UI resource.
        path = urlsplit(url).path.lower()
        if is_svg(url) or _PREVIEW_HINTS.search(path) or any(k in path for k in ('logo', 'icon', 'avatar', 'badge')):
            return True
    return False


def declared_pixels(url: str) -> int:
    """Best-effort size score from a URL. Never treated as authoritative."""
    p = urlsplit(url)
    text = p.path + '?' + p.query
    best = 0
    for w, h in _DIMENSION_RE.findall(text):
        best = max(best, int(w) * int(h))
    q = parse_qs(p.query)
    def number(*keys: str) -> int:
        for key in keys:
            value = q.get(key, [''])[0]
            if str(value).isdigit():
                return int(value)
        return 0
    w = number('width', 'w')
    h = number('height', 'h')
    if w and h:
        best = max(best, w * h)
    return best


def candidate_score(url: str, *, alt: str | None = None, title: str | None = None,
                    classes: str | None = None, direct_download: bool = False) -> float:
    if not url or is_probable_ui_asset(url, alt=alt, title=title, classes=classes):
        return -1e12
    low = url.lower()
    score = 0.0
    pixels = declared_pixels(url)
    if pixels:
        score += min(pixels / 1_000_000.0, 100.0)
    if _CONTENT_HINTS.search(low):
        score += 8.0
    if _PREVIEW_HINTS.search(low):
        score -= 12.0
    if direct_download:
        score += 40.0
    if any(token in low for token in ('original', 'fullxfull', 'full-size', 'full_size', '1920', '2560', '3840', '4k', '5k', '8k')):
        score += 20.0
    if is_svg(url):
        # SVGs are valuable for pattern/vector galleries but generic UI pages are overwhelmingly SVG chrome.
        score -= 2.0
    return score


def dedupe_urls(urls: list[str]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for url in urls:
        if url and url not in seen:
            seen.add(url)
            out.append(url)
    return out


def is_known_preview(url: str) -> bool:
    low = (url or '').lower()
    if _PREVIEW_HINTS.search(low):
        return True
    p = urlsplit(url)
    q = parse_qs(p.query)
    dims = []
    for key in ('width', 'height', 'w', 'h'):
        value = q.get(key, [''])[0]
        if str(value).isdigit():
            dims.append(int(value))
    if dims and max(dims) <= 400:
        return True
    matches = [(int(w), int(h)) for w, h in _DIMENSION_RE.findall(p.path)]
    return bool(matches and max(max(w, h) for w, h in matches) <= 400)
