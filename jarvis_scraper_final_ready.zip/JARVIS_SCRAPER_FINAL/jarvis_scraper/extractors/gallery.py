"""Discover public detail pages and the strongest published content image on each page."""
from __future__ import annotations

import re
from urllib.parse import urljoin, urlsplit
from bs4 import BeautifulSoup
from ..models import ImageAsset
from .html_images import extract_images
from .quality import candidate_score, is_probable_ui_asset, dedupe_urls
from .svg import extract_svg_assets

IMAGE_EXT = re.compile(r'\.(jpg|jpeg|png|webp|avif|gif|svg)(?:\?|$)', re.I)
NEGATIVE = re.compile(
    r'/(?:login|signin|account|cart|basket|wishlist|search|tag|tags|category|categories|privacy|terms|about|contact|'
    r'author|profile|help|support|blog)(?:/|$)', re.I,
)
DETAIL_HINT = re.compile(
    r'\.html$|/(?:photo|photos|image|images|wallpaper|wallpapers|pattern|patterns|download|full|png|art|dl|listing|'
    r'free-food-photo|stock-photos/photos)/|/big\.php\?i=', re.I,
)
CARD_HINT = re.compile(r'(card|item|thumb|gallery|photo|wallpaper|image|asset|result|pattern|listing|tile|grid)', re.I)


def detail_links(html: str, url: str) -> list[str]:
    soup = BeautifulSoup(html, 'lxml')
    origin = (urlsplit(url).hostname or '').lower()
    ranked: list[tuple[float, int, str]] = []
    seen: set[str] = set()
    order = 0
    for a in soup.select('a[href]'):
        order += 1
        if a.find_parent(['nav', 'header', 'footer']):
            continue
        href = a.get('href') or ''
        if not href or href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
            continue
        target = urljoin(url, href.split('#')[0])
        p = urlsplit(target)
        if (p.hostname or '').lower() != origin or IMAGE_EXT.search(target) or NEGATIVE.search(p.path):
            continue
        if target == url or target in seen:
            continue
        image = a.find('img') or a.find('picture')
        classes = ' '.join(a.get('class', [])) + ' ' + ' '.join((a.parent.get('class', []) if getattr(a, 'parent', None) else []))
        text = a.get_text(' ', strip=True)
        joined = p.path + ('?' + p.query if p.query else '')
        score = 0.0
        if DETAIL_HINT.search(joined):
            score += 8
        depth = len([part for part in p.path.split('/') if part])
        if depth >= 1:
            score += min(depth, 3)
        if image:
            score += 5
        if CARD_HINT.search(classes):
            score += 4
        if text and 2 <= len(text) <= 160:
            score += 1.5
        # Pattern/content sites often use clean /slug detail routes with text-only cards.
        if depth == 1 and text and not p.query:
            score += 1
        # Category pagination and filter links are not detail items.
        if re.search(r'(?:^|/)(?:page|pages)/?\d*$', p.path, re.I) or re.search(r'[?&](?:page|pagi|sort|filter)=', p.query, re.I):
            score -= 10
        if score >= 4:
            seen.add(target)
            ranked.append((score, -order, target))
    ranked.sort(reverse=True)
    return [target for _, _, target in ranked]


def _direct_downloads(soup: BeautifulSoup, url: str) -> list[tuple[float, str]]:
    candidates: list[tuple[float, str]] = []
    for a in soup.select('a[href]'):
        href = urljoin(url, a.get('href') or '')
        if not href.startswith(('http://', 'https://')):
            continue
        text = a.get_text(' ', strip=True)
        attrs = ' '.join(str(a.get(k) or '') for k in ('class', 'id', 'title', 'aria-label'))
        looks_download = bool(a.has_attr('download') or re.search(r'(download|original|full.?size|high.?res|4k|5k|8k)', text + ' ' + attrs, re.I))
        if not IMAGE_EXT.search(href) and not looks_download:
            continue
        if is_probable_ui_asset(href, title=text, classes=attrs):
            continue
        resolution = re.search(r'(\d{3,5})\s*[xX×]\s*(\d{3,5})', text + ' ' + href)
        score = candidate_score(href, title=text, classes=attrs, direct_download=looks_download)
        if resolution:
            score += int(resolution[1]) * int(resolution[2]) / 1_000_000
        candidates.append((score, href))
    return candidates


def download_page_links(html: str, url: str) -> list[str]:
    """Return same-origin HTML links that explicitly promise original/full media.

    Many wallpaper/image catalogues route a detail card -> download/options page ->
    actual image. We follow only one bounded public HTML hop; binary image links are
    already handled by ``full_image_links``.
    """
    soup = BeautifulSoup(html, 'lxml')
    origin = (urlsplit(url).hostname or '').lower()
    ranked: list[tuple[float, int, str]] = []
    seen: set[str] = set()
    for order, a in enumerate(soup.select('a[href]')):
        if a.find_parent(['nav', 'header', 'footer']):
            continue
        href = a.get('href') or ''
        if not href or href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
            continue
        target = urljoin(url, href.split('#')[0])
        p = urlsplit(target)
        if (p.hostname or '').lower() != origin or target == url or IMAGE_EXT.search(target):
            continue
        text = a.get_text(' ', strip=True)
        attrs = ' '.join(str(a.get(k) or '') for k in ('class', 'id', 'title', 'aria-label'))
        semantic = text + ' ' + attrs + ' ' + p.path
        if not re.search(r'(download(?:\s+original)?|original|full.?size|high.?res|4k|5k|8k|resolution)', semantic, re.I):
            continue
        if NEGATIVE.search(p.path):
            continue
        score = 10.0
        if re.search(r'(original|full.?size|high.?res)', semantic, re.I):
            score += 20
        resolution = re.search(r'(\d{3,5})\s*[xX×]\s*(\d{3,5})', semantic)
        if resolution:
            score += int(resolution[1]) * int(resolution[2]) / 1_000_000
        if target not in seen:
            seen.add(target)
            ranked.append((score, -order, target))
    ranked.sort(reverse=True)
    return [target for _, _, target in ranked]


def full_image_links(html: str, url: str) -> list[ImageAsset]:
    """Return one strongest content asset from a detail page with fallbacks attached.

    A detail page frequently contains dozens of related thumbnails, logos and chrome.
    Returning one ranked asset keeps flat-gallery semantics: one card/detail => one image.
    The downloader can still try all published alternatives through ``candidate_urls``.
    """
    soup = BeautifulSoup(html, 'lxml')
    for node in soup.select('nav, header, footer, [role="navigation"], .related, .recommendations, .social-share, .share-buttons'):
        node.decompose()
    root = soup.select_one('main, [role="main"], article, .content, #content') or soup

    scored: list[tuple[float, str, ImageAsset | None]] = []
    for score, href in _direct_downloads(root, url):
        scored.append((score + 30, href, None))

    extracted = extract_images(str(root), url, 'gallery_detail')
    if (urlsplit(url).hostname or '').lower().endswith('pattern.monster'):
        extracted.extend(extract_svg_assets(str(root), url))
    for asset in extracted:
        score = candidate_score(asset.image_url, alt=asset.alt_text, title=asset.title)
        # OpenGraph on a detail page is usually the primary media, while thumbnails
        # and recommendation images score lower through URL semantics.
        if asset.source_strategy == 'gallery_detail':
            score += 3
        scored.append((score, asset.image_url, asset))
        for alt in asset.candidate_urls:
            scored.append((candidate_score(alt, alt=asset.alt_text, title=asset.title) + 1, alt, asset))

    if not scored:
        return []
    scored.sort(key=lambda x: x[0], reverse=True)
    best_score, best_url, best_asset = scored[0]
    if best_score <= -1e10:
        return []

    # Keep a bounded set of other published candidates so validation can fall back
    # if the apparent best URL 404s or is a low-resolution transform.
    alternatives = dedupe_urls([u for _, u, _ in scored[1:20] if u != best_url])
    if best_asset is None:
        return [ImageAsset(url, best_url, original_url=best_url, source_strategy='gallery_detail', candidate_urls=alternatives)]
    return [ImageAsset(
        url, best_url, original_url=best_asset.original_url or best_url,
        alt_text=best_asset.alt_text, title=best_asset.title,
        source_strategy='gallery_detail', candidate_urls=dedupe_urls(best_asset.candidate_urls + alternatives),
    )]
