from __future__ import annotations

import base64
import hashlib
import re
from urllib.parse import urljoin, urlsplit
from bs4 import BeautifulSoup
from ..models import ImageAsset
from .quality import is_probable_ui_asset


def _inline_svg_candidate(node) -> str | None:
    if node.find_parent(['nav', 'header', 'footer', 'button']):
        return None
    classes = ' '.join(node.get('class', []))
    parent = node.parent
    marker = classes + ' ' + str(node.get('id', ''))
    if parent is not None:
        marker += ' ' + ' '.join(parent.get('class', [])) + ' ' + str(parent.get('id', ''))
    if re.search(r'(icon|logo|social|menu|chevron|arrow|spinner|loader|badge)', marker, re.I):
        return None
    view = (node.get('viewBox') or '').replace(',', ' ').split()
    try:
        vw, vh = (float(view[2]), float(view[3])) if len(view) == 4 else (0.0, 0.0)
    except ValueError:
        vw, vh = 0.0, 0.0
    def num(value):
        m = re.match(r'\s*(\d+(?:\.\d+)?)', str(value or ''))
        return float(m.group(1)) if m else 0.0
    w, h = num(node.get('width')), num(node.get('height'))
    area = max(vw * vh, w * h)
    content_context = bool(re.search(r'(pattern|preview|canvas|design|gallery|art|content|image)', marker, re.I))
    if area and area < 4096 and not content_context:
        return None
    if not area and not content_context:
        return None
    raw = str(node).encode('utf-8')
    if len(raw) > 2 * 1024 * 1024:
        return None
    return 'data:image/svg+xml;base64,' + base64.b64encode(raw).decode('ascii')


def extract_svg_assets(html: str, base_url: str) -> list[ImageAsset]:
    soup = BeautifulSoup(html, 'lxml')
    out: list[ImageAsset] = []
    seen: set[str] = set()
    for node in soup.select("a[href$='.svg' i], img[src$='.svg' i], source[src$='.svg' i], object[data$='.svg' i]"):
        raw = node.get('href') or node.get('src') or node.get('data')
        if not raw:
            continue
        url = urljoin(base_url, raw)
        if is_probable_ui_asset(url, classes=' '.join(node.get('class', []))):
            continue
        if urlsplit(url).scheme in {'http', 'https'} and url not in seen:
            seen.add(url)
            out.append(ImageAsset(base_url, url, original_url=url, source_strategy='svg_gallery'))

    # Pattern/vector tools often render the downloadable artwork as an inline SVG.
    for node in soup.find_all('svg'):
        data_uri = _inline_svg_candidate(node)
        if not data_uri:
            continue
        digest = hashlib.sha256(data_uri.encode()).hexdigest()
        key = 'inline-svg:' + digest
        if key in seen:
            continue
        seen.add(key)
        out.append(ImageAsset(base_url, data_uri, original_url=data_uri, source_strategy='inline_svg'))
    return out
