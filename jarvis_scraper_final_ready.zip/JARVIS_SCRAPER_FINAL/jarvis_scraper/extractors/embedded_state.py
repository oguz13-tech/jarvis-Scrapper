"""Extract products and image candidates from JSON/hydration state.

Works with Next.js, many React/Vue storefronts and generic application/json
blobs without depending on a particular vendor schema.
"""
from __future__ import annotations

import json
import re
from typing import Any, Iterable
from urllib.parse import urljoin, urlsplit
from bs4 import BeautifulSoup
from ..models import ImageAsset, Product
from .quality import is_probable_ui_asset

IMAGE_RE = re.compile(r"\.(?:jpe?g|png|webp|avif|gif|svg)(?:[?#]|$)", re.I)
PRODUCT_KEYS = {"product", "products", "item", "items", "listing", "listings", "productdata", "product_data"}
IMAGE_KEYS = {
    "image", "images", "media", "gallery", "photos", "pictures", "assets",
    "featuredimage", "featured_image", "srcset", "thumbnail", "original",
}
NAME_KEYS = ("name", "title", "productname", "product_name")
URL_KEYS = ("url", "href", "handle", "slug", "producturl", "product_url")
ID_KEYS = ("id", "productid", "product_id", "sku")


def _json_scripts(html: str) -> Iterable[Any]:
    soup = BeautifulSoup(html, "lxml")
    for script in soup.find_all("script"):
        typ = (script.get("type") or "").lower()
        sid = script.get("id") or ""
        text = script.string or script.get_text() or ""
        if not text.strip():
            continue
        if typ in {"application/json", "application/ld+json"} or sid in {
            "__NEXT_DATA__", "__PWS_DATA__", "__APOLLO_STATE__", "__PRELOADED_STATE__"
        }:
            try:
                yield json.loads(text)
            except (ValueError, TypeError):
                continue


def _absolute(base: str, value: str) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    value = value.strip().replace("\\/", "/")
    if value.startswith("data:"):
        return None
    result = urljoin(base, value)
    return result if urlsplit(result).scheme in {"http", "https"} else None


def _image_urls(value: Any, base: str, image_context: bool = False) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()

    def add(v: Any) -> None:
        if not isinstance(v, str):
            return
        # srcset can appear inside a JSON property.
        parts = [p.strip().split()[0] for p in v.split(",")] if "," in v else [v]
        for part in parts:
            u = _absolute(base, part)
            if u and not is_probable_ui_asset(u) and (IMAGE_RE.search(urlsplit(u).path) or any(k in u.lower() for k in ("image", "img", "media", "photo"))):
                if u not in seen:
                    seen.add(u); out.append(u)

    def walk(node: Any, ctx: bool = False) -> None:
        if isinstance(node, dict):
            # Common sized-image map: {"236x": {"url":..., "width":236}, ...}
            sized = [v for v in node.values() if isinstance(v, dict) and isinstance(v.get("url"), str)]
            if ctx and sized:
                ranked = sorted(sized, key=lambda d: (int(d.get("width") or 0), int(d.get("height") or 0)), reverse=True)
                if ranked:
                    add(ranked[0].get("url"))
            for k, v in node.items():
                kl = str(k).lower().replace("-", "").replace(" ", "")
                next_ctx = ctx or kl in IMAGE_KEYS or kl.endswith("image") or kl.endswith("images")
                if next_ctx and kl in {"url", "src", "source", "contenturl", "originalurl", "original"}:
                    add(v)
                else:
                    walk(v, next_ctx)
        elif isinstance(node, list):
            for v in node:
                walk(v, ctx)
        elif ctx:
            add(node)

    walk(value, image_context)
    return out


def _looks_product(node: dict[str, Any]) -> bool:
    keys = {str(k).lower().replace("-", "").replace("_", "") for k in node}
    has_name = any(k.replace("_", "") in keys for k in NAME_KEYS)
    has_media = any(k.replace("_", "") in keys for k in IMAGE_KEYS)
    commerce = any(k in keys for k in ("price", "offers", "variants", "sku", "productid", "availability"))
    return has_name and has_media and commerce


def extract_embedded_products(html: str, base_url: str, limit: int = 500) -> list[Product]:
    products: list[Product] = []
    seen: set[str] = set()

    def first(node: dict, keys: tuple[str, ...]):
        lowered = {str(k).lower(): v for k, v in node.items()}
        for k in keys:
            if k in lowered and lowered[k] not in (None, ""):
                return lowered[k]
        return None

    def walk(node: Any, product_context: bool = False) -> None:
        if len(products) >= limit:
            return
        if isinstance(node, dict):
            local_context = product_context or _looks_product(node)
            if local_context and _looks_product(node):
                name = first(node, NAME_KEYS)
                raw_url = first(node, URL_KEYS)
                product_url = base_url
                if isinstance(raw_url, str):
                    if raw_url.startswith(("http://", "https://", "/")):
                        product_url = urljoin(base_url, raw_url)
                    elif "/products/" in base_url or "/product/" in base_url:
                        product_url = base_url
                pid = first(node, ID_KEYS)
                identity = str(pid or product_url or name)
                if identity not in seen:
                    images = [ImageAsset(product_url, u, original_url=u, source_strategy="embedded_json")
                              for u in _image_urls(node, base_url)]
                    if images:
                        seen.add(identity)
                        products.append(Product(
                            name=str(name or "Product"), url=product_url, id=str(pid or identity),
                            sku=str(node.get("sku")) if node.get("sku") is not None else None,
                            description=node.get("description") if isinstance(node.get("description"), str) else None,
                            images=images,
                            metadata={"embedded_state": True},
                        ))
            for k, v in node.items():
                key = str(k).lower().replace("-", "").replace("_", "")
                walk(v, local_context or key in PRODUCT_KEYS)
        elif isinstance(node, list):
            for v in node:
                walk(v, product_context)

    for data in _json_scripts(html):
        walk(data)
    return products


def extract_embedded_images(html: str, base_url: str) -> list[ImageAsset]:
    out: list[ImageAsset] = []
    seen: set[str] = set()
    for data in _json_scripts(html):
        for url in _image_urls(data, base_url):
            if url not in seen:
                seen.add(url)
                out.append(ImageAsset(base_url, url, original_url=url, source_strategy="embedded_json"))
    return out
