"""Conservative provider-specific high-resolution candidate expansion.

Only well-known public CDN transform patterns are rewritten. Unknown hosts are
never mutated. Candidate generation does not bypass authentication or access
controls; normal HTTP/robots rules still apply in the downloader.
"""
from __future__ import annotations

import re
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit


def _replace_path(url: str, path: str, query: str | None = None) -> str:
    p = urlsplit(url)
    return urlunsplit((p.scheme, p.netloc, path, p.query if query is None else query, p.fragment))


def provider_highres_candidates(url: str) -> list[str]:
    p = urlsplit(url)
    host = (p.hostname or '').lower()
    path = p.path
    out: list[str] = []

    # Shopify/Burst image CDN resize query controls. Removing only width/height
    # asks the same published object without fabricating another asset id.
    if host in {'burst.shopifycdn.com', 'cdn.shopify.com'} or host.endswith('.shopifycdn.com'):
        pairs = parse_qsl(p.query, keep_blank_values=True)
        stripped = [(k, v) for k, v in pairs if k.lower() not in {'width', 'height', 'w', 'h'}]
        if len(stripped) != len(pairs):
            out.append(urlunsplit((p.scheme, p.netloc, path, urlencode(stripped), p.fragment)))

    # Pixabay public CDN uses suffixes such as _340/_640/_1280/_1920 for the
    # same image id. Prefer the largest known published variants first.
    if host == 'cdn.pixabay.com' or host.endswith('.pixabay.com'):
        # Kept broad for cdn.pixabay.com and pixabay.com image hosts.
        if re.search(r'_(?:340|640|960_720|1280|1920)(?=\.[a-z0-9]+$)', path, re.I):
            for size in ('1920', '1280'):
                new_path = re.sub(r'_(?:340|640|960_720|1280|1920)(?=\.[a-z0-9]+$)', '_' + size, path, flags=re.I)
                out.append(_replace_path(url, new_path))

    # Etsy's public image CDN commonly exposes il_340x270/il_570xN and
    # il_fullxfull variants of the same listing image.
    if host.endswith('etsystatic.com'):
        if re.search(r'/il_[^/]+\.', path, re.I):
            new_path = re.sub(r'/il_[^./]+', '/il_fullxfull', path, count=1, flags=re.I)
            out.append(_replace_path(url, new_path))

    # Trendyol/DSM CDN often wraps a stable media path in mnresize/W/H/.
    if host.endswith('dsmcdn.com') and '/mnresize/' in path:
        # Legacy Trendyol scraper proved that the stable media object sits after
        # the mnresize transform. Numeric width/height transforms have two path
        # segments; named transforms (for example ty1000_prod) have one.
        match = re.search(r'/mnresize/([^/]+)/([^/]+)/', path, re.I)
        if match and match.group(1).isdigit() and match.group(2).isdigit():
            new_path = path[:match.start()] + '/' + path[match.end():]
        else:
            new_path = re.sub(r'/mnresize/[^/]+/', '/', path, count=1, flags=re.I)
        if new_path != path:
            out.append(_replace_path(url, new_path))


    # Pexels public image CDN uses query transforms for preview sizing. Removing
    # only the size/crop transform keys retains the same published photo object.
    if host == 'images.pexels.com' or host.endswith('.pexels.com'):
        pairs = parse_qsl(p.query, keep_blank_values=True)
        stripped = [(k, v) for k, v in pairs if k.lower() not in {'w', 'h', 'width', 'height', 'fit', 'crop'}]
        if len(stripped) != len(pairs):
            out.append(urlunsplit((p.scheme, p.netloc, path, urlencode(stripped), p.fragment)))

    # Unsplash serves the same public image id through query-based transforms.
    # Keep format/quality hints but remove only geometry transforms.
    if host == 'images.unsplash.com' or host.endswith('.images.unsplash.com'):
        pairs = parse_qsl(p.query, keep_blank_values=True)
        stripped = [(k, v) for k, v in pairs if k.lower() not in {'w', 'h', 'width', 'height', 'fit', 'crop', 'rect'}]
        if len(stripped) != len(pairs):
            out.append(urlunsplit((p.scheme, p.netloc, path, urlencode(stripped), p.fragment)))

    # HDQWalls exposes list thumbnails under /wallpapers/thumb/ while detail
    # pages use the same filename under /wallpapers/ for the larger asset.
    if host == 'images.hdqwalls.com' and '/wallpapers/thumb/' in path:
        out.append(_replace_path(url, path.replace('/wallpapers/thumb/', '/wallpapers/', 1)))

    # WallpapersCraft category thumbnails encode the chosen resolution in the
    # filename. Try commonly published desktop sizes before the 300x168 preview.
    if host == 'images.wallpaperscraft.com' and re.search(r'_\d{2,4}x\d{2,4}\.(?:jpe?g|webp)$', path, re.I):
        for size in ('3840x2160', '2560x1440', '1920x1080', '1600x900', '1280x720'):
            new_path = re.sub(r'_\d{2,4}x\d{2,4}(?=\.(?:jpe?g|webp)$)', '_' + size, path, flags=re.I)
            out.append(_replace_path(url, new_path))


    # AdaWall category cards publish 250px thumbnails while public detail pages
    # expose the same stable image ids under /resimler/800/.
    if host == 'www.adawall.com.tr' or host == 'adawall.com.tr':
        if re.search(r'/resimler/250/', path, re.I):
            out.append(_replace_path(url, re.sub(r'/resimler/250/', '/resimler/800/', path, count=1, flags=re.I)))

    # 3dduvarkagitlari uses conventional size folders (m/l) for public
    # catalogue media. Try the large sibling first and retain m as fallback.
    if host == '3dduvarkagitlari.com' or host == 'www.3dduvarkagitlari.com':
        if re.search(r'/content/images/.*/m/', path, re.I):
            out.append(_replace_path(url, re.sub(r'/m/', '/l/', path, count=1, flags=re.I)))

    # DeviantArt/Wix media transform path: the object before /v1/fill|fit|crop/
    # is the underlying published media id. Preserve the signed query token.
    if host.endswith('wixmp.com') and re.search(r'/v1/(?:fill|fit|crop)/', path, re.I):
        base = re.split(r'/v1/(?:fill|fit|crop)/', path, maxsplit=1, flags=re.I)[0]
        out.append(_replace_path(url, base))

    # Some Wix image transforms use a trailing /v1/... segment but preserve an
    # original object immediately before it. Only strip that known transform namespace.
    if host.endswith('wixstatic.com') and '/v1/' in path:
        out.append(_replace_path(url, path.split('/v1/', 1)[0]))

    deduped: list[str] = []
    seen = {url}
    for candidate in out:
        if candidate and candidate not in seen:
            seen.add(candidate)
            deduped.append(candidate)
    return deduped
