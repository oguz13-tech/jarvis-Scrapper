from pathlib import Path
import base64
import shutil
from urllib.parse import unquote_to_bytes
from ..fetchers.http_fetcher import HttpFetcher
from ..exceptions import ScrapeError
from ..models import Status
from ..config import MIN_FREE_GB
from .validator import validate_image
from .deduplicator import Deduplicator
from .highres import provider_highres_candidates
from ..extractors.quality import candidate_score, is_probable_ui_asset, is_known_preview


class DiskSpaceError(ScrapeError):
    pass


def check_free_space(path=".", min_gb=MIN_FREE_GB):
    """Fail fast before a download can exhaust the destination volume.

    The check walks up to an existing parent so it also works before a nested
    product/orientation directory has been created.
    """
    target = Path(path).resolve()
    while not target.exists() and target.parent != target:
        target = target.parent
    _total, _used, free = shutil.disk_usage(target)
    minimum = int(float(min_gb) * (2 ** 30))
    if free < minimum:
        free_gb = free / (2 ** 30)
        raise DiskSpaceError(
            Status.DOWNLOAD_ERROR,
            f'Disk alanı kritik seviyede: {free_gb:.2f} GB boş alan kaldı; en az {float(min_gb):.2f} GB gerekli'
        )
    return free


class Downloader:
    def __init__(self, min_width=400, min_height=400, delay=0.75, fetcher=None, cancel_event=None, event_callback=None):
        self.min_width, self.min_height = min_width, min_height
        self.fetcher = fetcher or HttpFetcher(delay)
        self.dedup = Deduplicator()
        self.cancel_event = cancel_event
        self.event_callback = event_callback

    def _check_cancel(self):
        if self.cancel_event is not None and self.cancel_event.is_set():
            raise ScrapeError(Status.STOPPED, 'Kullanıcı tarafından durduruldu; indirilen dosyalar korundu')

    def _emit(self, event, message, **data):
        if self.event_callback is None:
            return
        try:
            self.event_callback(event, message, data)
        except Exception:
            pass

    def _candidates(self, asset):
        out, seen = [], set()
        for url in [asset.image_url, *(getattr(asset, 'candidate_urls', []) or [])]:
            if not url:
                continue
            expanded = provider_highres_candidates(url)
            for candidate in [*expanded, url]:
                if not candidate or candidate in seen:
                    continue
                if is_probable_ui_asset(candidate, alt=asset.alt_text, title=asset.title):
                    continue
                seen.add(candidate)
                out.append(candidate)
        return out

    def download(self, asset, out_base, index=1, product_folder=None):
        self._check_cancel()
        check_free_space(out_base)
        last_reason = None
        for candidate in self._candidates(asset):
            self._check_cancel()
            asset.normalized_url = self.dedup.normalize_url(candidate)
            duplicate = self.dedup.find(url=candidate)
            if duplicate:
                asset.image_url = candidate
                asset.download_status, asset.duplicate_of = 'duplicate_url', duplicate
                return asset
            try:
                inline = candidate.startswith('data:image/')
                if inline:
                    header, payload = candidate.split(',', 1)
                    if ';base64' in header.lower():
                        content = base64.b64decode(payload, validate=True)
                    else:
                        content = unquote_to_bytes(payload)
                    content_type = header[5:].split(';', 1)[0]
                else:
                    # The candidate is an exact public asset URL discovered from an
                    # already-allowed page/API response. Fetch the binary directly;
                    # navigation/access controls are still enforced by HTTP status.
                    # Avoid broad ``hasattr`` for generic unittest mocks, but
                    # official API assets may intentionally provide get_asset on an
                    # injected fetcher instance.
                    official = asset.source_strategy in {'pixabay', 'pexels', 'unsplash', 'official_api'}
                    direct_fetch = getattr(self.fetcher, 'get_asset', None) if official else getattr(type(self.fetcher), 'get_asset', None)
                    if callable(direct_fetch):
                        response = self.fetcher.get_asset(
                            candidate, headers={'Referer': asset.page_url},
                            official_api_asset=official,
                        )
                    else:
                        response = self.fetcher.get(candidate, headers={'Referer': asset.page_url})
                    content = response.content
                    content_type = response.headers.get('Content-Type', '')
                ok, info = validate_image(content, content_type,
                                          self.min_width, self.min_height)
                asset.mime_type = info.get('mime')
                asset.width, asset.height = info.get('width'), info.get('height')
                if not ok:
                    last_reason = info['reason']
                    # Keep trying published alternatives (srcset/data-full/etc.).
                    continue
                # Generic pages contain many valid SVG logos/icons. Only explicit
                # vector-gallery extraction is allowed to persist SVG artwork.
                if info.get('mime') == 'image/svg+xml' and asset.source_strategy not in {'svg_gallery', 'inline_svg'}:
                    last_reason = 'ui_svg'
                    continue
                # A known thumbnail/preview is not accepted as a final result merely
                # because it clears the minimum dimensions. The final product is an
                # original/high-quality collector, not a thumbnail collector.
                if is_known_preview(candidate) and info.get('mime') != 'image/svg+xml':
                    last_reason = 'preview_only'
                    continue
                sha, ph = self.dedup.hashes(content)
                asset.sha256, asset.perceptual_hash = sha, ph
                asset.file_size = len(content)
                duplicate = self.dedup.find(sha=sha, ph=ph)
                if duplicate:
                    asset.image_url = ('inline-svg:' + sha if inline else candidate)
                    asset.original_url = asset.image_url if inline else asset.original_url
                    asset.candidate_urls = [] if inline else asset.candidate_urls
                    asset.download_status, asset.duplicate_of = 'duplicate_content', duplicate
                    self.dedup.remember(candidate, sha, ph, duplicate)
                    return asset
                orientation = 'Yatay' if asset.width > asset.height else ('Dikey' if asset.height > asset.width else 'Kare')
                root = Path(out_base) / orientation
                if product_folder:
                    root = root / product_folder
                root.mkdir(parents=True, exist_ok=True)
                path = root / f'{index:03d}-{sha[:12]}{info["ext"]}'
                temporary = path.with_suffix(path.suffix + '.part')
                check_free_space(root)
                temporary.write_bytes(content)
                # replace() is atomic on the same volume; a power loss can leave only
                # the .part file, which is ignored and re-downloaded on resume.
                temporary.replace(path)
                asset.image_url = ('inline-svg:' + sha if inline else candidate)
                asset.original_url = asset.image_url if inline else asset.original_url
                asset.candidate_urls = [] if inline else asset.candidate_urls
                asset.normalized_url = asset.image_url if inline else self.dedup.normalize_url(candidate)
                asset.local_path, asset.download_status = str(path), 'downloaded'
                asset.rejection_reason = None
                self.dedup.remember(candidate, sha, ph, str(path))
                self._emit('download', f'İndirildi: {asset.width}x{asset.height} {path.name}', path=str(path), width=asset.width, height=asset.height, url=candidate)
                return asset
            except DiskSpaceError:
                raise
            except (ScrapeError, OSError) as e:
                last_reason = f'{getattr(e, "status", "DOWNLOAD_ERROR")}: {e}'
                continue
        asset.download_status = 'rejected' if last_reason in {'invalid_mime', 'decode_failed', 'low_resolution', 'invalid_svg', 'unsupported_format', 'preview_only', 'ui_svg'} else 'failed'
        asset.rejection_reason = last_reason or 'no_candidate'
        return asset
