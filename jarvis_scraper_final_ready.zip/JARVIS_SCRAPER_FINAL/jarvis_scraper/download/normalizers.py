from urllib.parse import urlsplit, urlunsplit

class GenericNormalizer:
    def normalize(self, url: str) -> str:
        p = urlsplit(url)
        return urlunsplit((p.scheme.lower(), p.netloc.lower(), p.path, p.query, ''))

class ShopifyNormalizer(GenericNormalizer):
    """Keep signed queries and filenames intact; prefer published srcset/API originals."""

class CloudinaryNormalizer(GenericNormalizer):
    """No guessed transforms, which may invalidate signatures."""

class ImgixNormalizer(GenericNormalizer):
    """No guessed transforms, which may invalidate signatures."""

def normalize_url(url: str) -> str:
    host = urlsplit(url).hostname or ''
    cls = ShopifyNormalizer if host.endswith('.shopify.com') else (
        CloudinaryNormalizer if host == 'res.cloudinary.com' else (
        ImgixNormalizer if host.endswith('.imgix.net') else GenericNormalizer))
    return cls().normalize(url)
