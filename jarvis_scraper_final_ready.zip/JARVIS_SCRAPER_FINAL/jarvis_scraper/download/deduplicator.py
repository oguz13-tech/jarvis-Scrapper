import hashlib
from io import BytesIO
from PIL import Image, ImageStat
from .normalizers import normalize_url

def perceptual_hash(content: bytes) -> str | None:
    try:
        with Image.open(BytesIO(content)) as original:
            image = original.convert('RGB').resize((16, 16))
            # Uniform graphics collide under plain aHash. Omit perceptual matching for them.
            if max(ImageStat.Stat(image).stddev) < 3:
                return None
            gray = image.convert('L').resize((9, 8))
            pixels = list(gray.get_flattened_data() if hasattr(gray, 'get_flattened_data') else gray.getdata())
            bits = ''.join('1' if pixels[y*9+x] > pixels[y*9+x+1] else '0'
                           for y in range(8) for x in range(8))
            color = ''.join(f'{round(v / 16):02x}' for v in ImageStat.Stat(image).mean)
            return f'{int(bits, 2):016x}:{color}'
    except (OSError, ValueError):
        return None

class Deduplicator:
    def __init__(self):
        self.urls, self.sha, self.phashes = {}, {}, {}

    normalize_url = staticmethod(normalize_url)

    def hashes(self, content: bytes):
        return hashlib.sha256(content).hexdigest(), perceptual_hash(content)

    def find(self, url=None, sha=None, ph=None):
        if url and normalize_url(url) in self.urls:
            return self.urls[normalize_url(url)]
        if sha in self.sha:
            return self.sha[sha]
        # Conservative exact structural + color signature; SHA remains authoritative.
        if ph and ph in self.phashes:
            return self.phashes[ph]
        return None

    def remember(self, url, sha, ph, path):
        self.urls[normalize_url(url)] = path
        if sha:
            self.sha[sha] = path
        if ph:
            self.phashes[ph] = path

    def url_seen(self, url):
        key = normalize_url(url)
        if key in self.urls:
            return True
        self.urls[key] = key
        return False

    def content_seen(self, sha, ph, threshold=0):
        if self.find(sha=sha, ph=ph):
            return True
        self.sha[sha] = sha
        if ph:
            self.phashes[ph] = sha
        return False
