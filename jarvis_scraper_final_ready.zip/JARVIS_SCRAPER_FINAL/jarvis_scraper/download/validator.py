from io import BytesIO
from xml.etree import ElementTree
from PIL import Image, UnidentifiedImageError

ALLOWED = {'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp',
           'image/gif': '.gif', 'image/avif': '.avif', 'image/svg+xml': '.svg'}
FORMATS = {'JPEG': ('image/jpeg', '.jpg'), 'PNG': ('image/png', '.png'),
           'WEBP': ('image/webp', '.webp'), 'GIF': ('image/gif', '.gif'), 'AVIF': ('image/avif', '.avif')}


def _svg(content: bytes, hinted_mime: str):
    probe = content.lstrip()[:512].lower()
    looks_svg = hinted_mime == 'image/svg+xml' or probe.startswith(b'<svg') or (probe.startswith(b'<?xml') and b'<svg' in content[:4096].lower())
    if not looks_svg:
        return None
    try:
        if b'<!DOCTYPE' in content.upper() or b'<!ENTITY' in content.upper():
            raise ValueError('XML declarations forbidden')
        root = ElementTree.fromstring(content)
        if root.tag.split('}')[-1].lower() != 'svg':
            raise ValueError('Not SVG')
        if any(node.tag.split('}')[-1].lower() in {'script', 'foreignobject'} or
               any(key.lower().startswith('on') for key in node.attrib) for node in root.iter()):
            raise ValueError('Active SVG')
        view = root.get('viewBox', '').replace(',', ' ').split()
        def number(value):
            text = str(value or '').strip().lower()
            for unit in ('px', 'pt', 'em', 'rem', 'cm', 'mm', 'in'):
                if text.endswith(unit): text = text[:-len(unit)]
            try: return float(text)
            except ValueError: return 0.0
        width = number(root.get('width')) or (number(view[2]) if len(view) == 4 else 0)
        height = number(root.get('height')) or (number(view[3]) if len(view) == 4 else 0)
        return True, {'mime': 'image/svg+xml', 'width': width, 'height': height, 'ext': '.svg'}
    except (ValueError, ElementTree.ParseError):
        return False, {'reason': 'invalid_svg', 'mime': hinted_mime}


def validate_image(content: bytes, content_type: str, min_width=400, min_height=400):
    """Validate from actual bytes, using HTTP MIME only as a hint.

    A surprising number of CDNs serve images as application/octet-stream. Rejecting
    those before decoding makes a general scraper brittle, so raster format detection
    is authoritative. HTML/error bodies still fail Pillow/XML validation.
    """
    mime_hint = (content_type or '').split(';')[0].strip().lower()
    svg = _svg(content, mime_hint)
    if svg is not None:
        ok, info = svg
        if not ok:
            return ok, info
        # SVG is resolution-independent. A valid vector is accepted even when its
        # natural viewBox is smaller than the raster minimums.
        return True, info

    try:
        with Image.open(BytesIO(content)) as image:
            image.verify()
        with Image.open(BytesIO(content)) as image:
            image.load()
            width, height = image.size
            actual = FORMATS.get(image.format)
            if not actual:
                return False, {'reason': 'unsupported_format', 'mime': mime_hint}
            mime, ext = actual
    except (OSError, ValueError, Image.DecompressionBombError, UnidentifiedImageError):
        reason = 'invalid_mime' if mime_hint and mime_hint not in ALLOWED else 'decode_failed'
        return False, {'reason': reason, 'mime': mime_hint}

    if width < min_width or height < min_height:
        return False, {'reason': 'low_resolution', 'mime': mime, 'width': width, 'height': height}
    return True, {'mime': mime, 'width': width, 'height': height, 'ext': ext}
