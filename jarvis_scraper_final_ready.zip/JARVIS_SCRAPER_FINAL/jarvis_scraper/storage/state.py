import json
import os
from pathlib import Path


class State:
    """Small atomic JSON checkpoint store."""

    def __init__(self, path):
        self.path = Path(path)

    def save(self, data):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_name(self.path.name + '.tmp')
        with temporary.open('w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, indent=2)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, self.path)

    def load(self):
        if not self.path.exists():
            return {}
        try:
            with self.path.open(encoding='utf-8') as stream:
                value = json.load(stream)
            return value if isinstance(value, dict) else {}
        except (OSError, json.JSONDecodeError):
            return {}
