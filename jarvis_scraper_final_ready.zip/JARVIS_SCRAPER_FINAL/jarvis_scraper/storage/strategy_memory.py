from __future__ import annotations

import json
from pathlib import Path
from datetime import datetime, timezone


class StrategyMemory:
    """Small persistent routing memory.

    It remembers which strategy succeeded for a domain, but never disables runtime
    detection or fallback. The file contains no credentials or page content.
    """
    def __init__(self, path):
        self.path = Path(path)
        self.data = {}
        try:
            raw = json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(raw, dict):
                self.data = raw
        except (OSError, ValueError, TypeError):
            self.data = {}

    def get(self, domain: str):
        value = self.data.get(domain)
        return value if isinstance(value, dict) else None

    def remember(self, domain: str, strategy: str, platform: str, site_type: str) -> None:
        self.data[domain] = {
            'strategy': strategy,
            'platform': platform,
            'site_type': site_type,
            'updated_at': datetime.now(timezone.utc).isoformat(),
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(self.path.suffix + '.tmp')
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(self.path)
