import hashlib
import json
import logging
import os
from pathlib import Path

class Manifest:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.touch(exist_ok=True)

    def append(self, obj):
        # Preserve complete previous rows after a process interruption mid-write.
        with self.path.open('ab+') as stream:
            stream.seek(0, 2)
            if stream.tell():
                stream.seek(-1, 2)
                if stream.read(1) != b'\n':
                    stream.write(b'\n')
            stream.write((json.dumps(obj, ensure_ascii=False) + '\n').encode('utf-8'))
            stream.flush()
            os.fsync(stream.fileno())

    def records(self):
        for line in self.path.read_text(encoding='utf-8').splitlines():
            try:
                row = json.loads(line)
                if isinstance(row, dict):
                    yield row
            except json.JSONDecodeError:
                logging.getLogger(__name__).warning('Ignoring incomplete manifest row')

    def successful(self):
        for row in self.records():
            if row.get('download_status') != 'downloaded' or not row.get('local_path'):
                continue
            path = Path(row['local_path'])
            if not path.is_absolute():
                path = self.path.parent / path
            try:
                if path.is_file() and row.get('sha256') == hashlib.sha256(path.read_bytes()).hexdigest():
                    yield {**row, 'local_path': str(path)}
            except OSError:
                continue

    def loaded_urls(self):
        return {row['image_url'] for row in self.successful()}
