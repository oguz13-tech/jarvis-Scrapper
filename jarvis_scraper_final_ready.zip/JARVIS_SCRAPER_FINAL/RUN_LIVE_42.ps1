$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

Write-Host "=== JARVIS SCRAPER LIVE 42 ===" -ForegroundColor Cyan

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "Creating virtual environment..."
    python -m venv .venv
}

$py = ".\.venv\Scripts\python.exe"

Write-Host "Installing/updating project dependencies..."
& $py -m pip install --upgrade pip
& $py -m pip install -e ".[browser,dev]"

Write-Host "Ensuring Chromium is installed..."
& $py -m playwright install chromium

Write-Host "Starting live corpus. You can leave this window open." -ForegroundColor Green
& $py .\scripts\live_test.py --file .\urls.txt --max-items 3 --max-pages 3 --max-scrolls 8 --output .\live_42 --resume

Write-Host ""
Write-Host "DONE. Send these files to ChatGPT:" -ForegroundColor Yellow
Write-Host "  live_42\summary.json"
Write-Host "  live_42\diagnostics.json"
Write-Host "  live_42\REPORT.md"
Read-Host "Press Enter to close"
